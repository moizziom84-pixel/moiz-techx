-- Verification only: every fixture and change is rolled back.
BEGIN;
SELECT set_config('request.jwt.claims','{"sub":"9a7774b0-248b-497c-9976-068e81f798ed","role":"authenticated","app_metadata":{"role":"super_admin"}}',true);
DO $$
DECLARE uid uuid:=auth.uid(); shop uuid; payment uuid; account uuid; denied boolean; result jsonb; product public.products; remaining integer;
BEGIN
 INSERT INTO public.mb_shops(owner_id,owner_name,email,phone,name,slug,category,city,address,status,verified) VALUES(uid,'Test fixture','test@example.invalid','03001234567','TEST ROLLBACK',gen_random_uuid()::text,'General','Karachi','Test fixture address','approved',false) RETURNING id INTO shop;
 SELECT id INTO account FROM public.mb_payment_accounts WHERE active ORDER BY method LIMIT 1;
 IF account IS NULL THEN RAISE EXCEPTION 'FAIL: receiving account is missing'; END IF;
 INSERT INTO public.mb_payment_requests(shop_id,owner_id,plan_code,amount_pkr,duration_days,account_id,method,transaction_id,transaction_normalized,sender_name,paid_at,receipt_path) VALUES(shop,uid,'business',1500,30,account,'easypaisa','TEST-'||gen_random_uuid()::text,'TEST-'||gen_random_uuid()::text,'TEST ROLLBACK',now(),uid::text||'/test-fixture.webp') RETURNING id INTO payment;
 denied:=false;
 BEGIN PERFORM public.mb_review_payment(payment,'approved','test',false); EXCEPTION WHEN OTHERS THEN denied:=position('Confirm received funds' in SQLERRM)>0; END;
 IF NOT denied THEN RAISE EXCEPTION 'FAIL: approval must require confirmation of received funds'; END IF;
 PERFORM set_config('request.jwt.claims',jsonb_build_object('sub',uid,'role','authenticated','app_metadata','{}'::jsonb)::text,true);
 denied:=false;
 BEGIN PERFORM public.mb_review_payment(payment,'approved','test',true); EXCEPTION WHEN OTHERS THEN denied:=position('Owner access required' in SQLERRM)>0; END;
 IF NOT denied THEN RAISE EXCEPTION 'FAIL: ordinary account could review a payment'; END IF;
 denied:=false;
 BEGIN PERFORM public.mb_submit_payment('business',account,'NO-RECEIPT-TEST','Test fixture',now(),uid::text||'/missing.webp'); EXCEPTION WHEN OTHERS THEN denied:=position('receipt ownership' in SQLERRM)>0 OR position('already awaiting' in SQLERRM)>0; END;
 IF NOT denied THEN RAISE EXCEPTION 'FAIL: payment submission accepted an invalid receipt'; END IF;
 PERFORM set_config('request.jwt.claims',jsonb_build_object('sub',uid,'role','authenticated','app_metadata',jsonb_build_object('role','super_admin'))::text,true);
 PERFORM public.mb_review_payment(payment,'approved','TEST ROLLBACK',true);
 IF NOT EXISTS(SELECT 1 FROM public.mb_subscriptions WHERE shop_id=shop AND plan_code='business' AND expires_at>now()+interval '29 days') OR public.mb_product_limit()<>250 THEN RAISE EXCEPTION 'FAIL: approval did not activate the correct plan'; END IF;
 PERFORM set_config('request.jwt.claims',jsonb_build_object('sub',uid,'role','authenticated','app_metadata','{}'::jsonb)::text,true);
 SELECT * INTO product FROM public.products WHERE status='active' AND stock>0 ORDER BY id LIMIT 1;
 IF NOT FOUND THEN RAISE EXCEPTION 'FAIL: no available product for atomic order test'; END IF;
 result:=public.mb_place_order(jsonb_build_object('customerName','TEST ROLLBACK','phone','03001234567','shippingAddress',jsonb_build_object('address','Test rollback address','city','Karachi'),'paymentMethod','cod','grandTotal',1,'items',jsonb_build_array(jsonb_build_object('productId',product.id,'quantity',1,'price',1))));
 IF (result->'order'->>'subtotal')::numeric<>product.price THEN RAISE EXCEPTION 'FAIL: order trusted the client price'; END IF;
 SELECT stock INTO remaining FROM public.products WHERE id=product.id;
 IF remaining<>product.stock-1 OR jsonb_array_length(result->'items')<>1 THEN RAISE EXCEPTION 'FAIL: stock and order items were not saved atomically'; END IF;
END $$;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-000000000001","role":"authenticated","app_metadata":{}}',true);
DO $$
BEGIN
 IF EXISTS(SELECT 1 FROM public.mb_payment_requests WHERE owner_id='9a7774b0-248b-497c-9976-068e81f798ed') THEN RAISE EXCEPTION 'FAIL: another user can read private payments'; END IF;
 IF EXISTS(SELECT 1 FROM public.mb_notifications WHERE recipient_id='9a7774b0-248b-497c-9976-068e81f798ed') THEN RAISE EXCEPTION 'FAIL: another user can read private notifications'; END IF;
END $$;
RESET ROLE;
SELECT 'PASS: manual confirmation, owner-only approval, receipt validation, plan activation, authoritative order pricing, atomic stock/items, private payment and notification access. All test changes rolled back.' AS verification;
ROLLBACK;
