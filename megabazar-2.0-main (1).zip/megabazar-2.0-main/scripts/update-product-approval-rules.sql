-- =========================================================================
-- MEGA BAZAR 2.0 — DIRECT SELLER PRODUCT PUBLISHING MIGRATION
-- =========================================================================
-- 1. Only Super Admin approves/rejects new shops (mb_review_shop).
-- 2. Once a shop is approved, its owner can publish products directly.
-- 3. Newly inserted products for approved shops are set to status='approved' immediately.
-- 4. When an existing product is updated:
--    - If status was 'suspended' or 'rejected' by admin, it remains so.
--    - If status was 'approved' or 'paused', it updates directly and remains 'approved' (or paused).
-- 5. Sellers cannot approve their own shops or bypass restrictions.
-- =========================================================================

ALTER TABLE public.mb_products DROP CONSTRAINT IF EXISTS mb_products_status_check;
ALTER TABLE public.mb_products ADD CONSTRAINT mb_products_status_check CHECK (status IN ('pending', 'approved', 'rejected', 'paused', 'suspended'));

CREATE OR REPLACE FUNCTION public.mb_save_product(details jsonb, image_paths text[], product_id uuid DEFAULT NULL)
RETURNS public.mb_products
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  s public.mb_shops;
  p public.mb_products;
  existing public.mb_products;
  path text;
  uid uuid := auth.uid();
  new_status text := 'approved';
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Sign in required'; END IF;

  -- Ensure the seller owns an approved shop
  SELECT * INTO s FROM public.mb_shops WHERE owner_id = uid AND status = 'approved' FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'An approved shop is required to publish products'; END IF;

  -- Validation
  IF octet_length(details::text) > 50000 THEN RAISE EXCEPTION 'Product data too large'; END IF;
  IF jsonb_typeof(details) IS DISTINCT FROM 'object'
     OR coalesce(length(trim(details->>'name')), 0) NOT BETWEEN 2 AND 180
     OR coalesce(length(details->>'description'), 0) NOT BETWEEN 20 AND 5000
     OR coalesce(length(details->>'category'), 0) < 2
     OR coalesce(length(details->>'contents'), 0) < 2
     OR (details->>'condition') NOT IN ('new', 'used', 'refurbished')
     OR coalesce(details->>'condition', '') = '' THEN
    RAISE EXCEPTION 'Invalid product details. Check name, category, condition and description.';
  END IF;

  IF coalesce(details->>'price', '') !~ '^[0-9]+(\.[0-9]{1,2})?$'
     OR (details->>'price')::numeric <= 0
     OR (details->>'price')::numeric > 100000000
     OR coalesce(details->>'stock', '') !~ '^[0-9]+$'
     OR (details->>'stock')::numeric > 10000000
     OR coalesce(details->>'dispatch', '') !~ '^[0-9]+$'
     OR (details->>'dispatch')::numeric NOT BETWEEN 1 AND 90 THEN
    RAISE EXCEPTION 'Invalid price, stock, or dispatch days';
  END IF;

  IF coalesce(details->>'salePrice', '') <> '' AND (
    details->>'salePrice' !~ '^[0-9]+(\.[0-9]{1,2})?$'
    OR (details->>'salePrice')::numeric <= 0
    OR (details->>'salePrice')::numeric >= (details->>'price')::numeric
  ) THEN
    RAISE EXCEPTION 'Discount price must be positive and lower than regular price';
  END IF;

  IF details->>'enableWhatsapp' = 'true' AND (
    details->>'whatsappConsent' IS DISTINCT FROM 'true'
    OR coalesce(details->>'whatsapp', '') !~ '^(\+92|92|0)3[0-9]{9}$'
  ) THEN
    RAISE EXCEPTION 'Invalid WhatsApp number or consent';
  END IF;

  IF coalesce(cardinality(image_paths), 0) NOT BETWEEN 3 AND 8
     OR (SELECT count(DISTINCT x) FROM unnest(image_paths) AS x) <> cardinality(image_paths) THEN
    RAISE EXCEPTION 'Between 3 and 8 unique product images are required';
  END IF;

  FOREACH path IN ARRAY image_paths LOOP
    IF split_part(path, '/', 1) <> uid::text
       OR NOT EXISTS (SELECT 1 FROM storage.objects WHERE bucket_id = 'mb-product-images' AND name = path) THEN
      RAISE EXCEPTION 'Invalid image ownership or image missing';
    END IF;
  END LOOP;

  -- Whitelist public fields; never allow injection of arbitrary administrative attributes
  details := (
    SELECT coalesce(jsonb_object_agg(key, value), '{}')
    FROM jsonb_each(details)
    WHERE key = ANY(ARRAY[
      'name', 'category', 'subcategory', 'otherCategory', 'brand', 'condition',
      'description', 'contents', 'price', 'salePrice', 'stock', 'unit', 'sku',
      'size', 'colour', 'material', 'model', 'capacity', 'ingredients', 'expiry',
      'variants', 'weight', 'dimensions', 'dispatch', 'warranty', 'whatsapp',
      'enableWhatsapp', 'whatsappConsent'
    ])
  );

  IF details->>'enableWhatsapp' IS DISTINCT FROM 'true' THEN
    details := details - 'whatsapp';
  END IF;

  IF product_id IS NULL THEN
    -- New product for approved shop: directly published and approved
    INSERT INTO public.mb_products(shop_id, owner_id, details, images, status, reason)
    VALUES(s.id, uid, details, image_paths, 'approved', '')
    RETURNING * INTO p;
  ELSE
    SELECT * INTO existing FROM public.mb_products WHERE id = product_id AND owner_id = uid;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product unavailable'; END IF;

    -- Admin-suspended or rejected products MUST remain hidden unless reviewed by admin
    IF existing.status IN ('suspended', 'rejected') THEN
      new_status := existing.status;
    ELSE
      new_status := 'approved';
    END IF;

    UPDATE public.mb_products
    SET details = mb_save_product.details,
        images = image_paths,
        status = new_status,
        reason = CASE WHEN new_status = 'approved' THEN '' ELSE existing.reason END,
        updated_at = now()
    WHERE id = product_id AND owner_id = uid
    RETURNING * INTO p;
  END IF;

  RETURN p;
END;
$$;

REVOKE ALL ON FUNCTION public.mb_save_product(jsonb, text[], uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_save_product(jsonb, text[], uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.mb_review_product(product_id uuid, decision text, review_reason text DEFAULT '')
RETURNS public.mb_products
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  p public.mb_products;
BEGIN
  IF NOT public.mb_is_admin() OR decision NOT IN ('approved', 'rejected', 'suspended') THEN
    RAISE EXCEPTION 'Permission denied';
  END IF;
  IF decision IN ('rejected', 'suspended') AND length(trim(coalesce(review_reason, ''))) < 5 THEN
    RAISE EXCEPTION 'A reason is required';
  END IF;

  UPDATE public.mb_products
  SET status = decision,
      reason = left(coalesce(review_reason, ''), 1000),
      updated_at = now()
  WHERE id = product_id
  RETURNING * INTO p;

  IF NOT FOUND THEN RAISE EXCEPTION 'Product unavailable'; END IF;

  INSERT INTO public.mb_admin_events(actor_id, shop_id, action, reason)
  VALUES(auth.uid(), p.shop_id, 'product_' || decision, product_id::text || ' ' || coalesce(review_reason, ''));

  RETURN p;
END;
$$;

REVOKE ALL ON FUNCTION public.mb_review_product(uuid, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_review_product(uuid, text, text) TO authenticated;

