BEGIN;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS client_data jsonb NOT NULL DEFAULT '{}';
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS settings jsonb NOT NULL DEFAULT '{}';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS details jsonb NOT NULL DEFAULT '{}', ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
CREATE TABLE IF NOT EXISTS public.complaints(id text PRIMARY KEY DEFAULT gen_random_uuid()::text,customer_id uuid NOT NULL REFERENCES auth.users(id),data jsonb NOT NULL,status text NOT NULL DEFAULT 'Open',resolution_notes text NOT NULL DEFAULT '',created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
GRANT SELECT,INSERT,UPDATE ON public.complaints TO authenticated;
CREATE POLICY mb_complaints_read ON public.complaints FOR SELECT TO authenticated USING(customer_id=auth.uid() OR public.mb_is_admin());
CREATE POLICY mb_complaints_create ON public.complaints FOR INSERT TO authenticated WITH CHECK(customer_id=auth.uid() AND status='Open');
CREATE POLICY mb_complaints_moderate ON public.complaints FOR UPDATE TO authenticated USING(public.mb_is_admin()) WITH CHECK(public.mb_is_admin());
CREATE POLICY mb_customers_owner_read ON public.customers FOR SELECT TO authenticated USING(public.mb_is_admin() OR id=auth.uid()::text);
GRANT SELECT ON public.customers TO authenticated;
CREATE OR REPLACE FUNCTION public.mb_place_order(payload jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE uid uuid:=auth.uid(); ident text:=gen_random_uuid()::text; email_address text; entry jsonb; p public.products; cfg public.store_settings; coupon public.coupons; q integer; item_rows jsonb:='[]'; subtotal numeric:=0; delivery numeric; discount numeric:=0; tax numeric:=0; total numeric; row_order public.orders; destination jsonb; item_id text;
BEGIN
 IF uid IS NULL THEN RAISE EXCEPTION 'Sign in before placing an order'; END IF;
 IF jsonb_typeof(payload) IS DISTINCT FROM 'object' OR octet_length(payload::text)>100000 OR jsonb_typeof(payload->'items') IS DISTINCT FROM 'array' OR jsonb_array_length(payload->'items') NOT BETWEEN 1 AND 100 THEN RAISE EXCEPTION 'Invalid cart'; END IF;
 destination:=payload->'shippingAddress';
 IF coalesce(length(trim(payload->>'customerName')),0) NOT BETWEEN 2 AND 150 OR coalesce(length(trim(payload->>'phone')),0) NOT BETWEEN 10 AND 20 OR coalesce(length(trim(destination->>'address')),0) NOT BETWEEN 5 AND 1000 OR coalesce(length(trim(destination->>'city')),0) NOT BETWEEN 2 AND 100 THEN RAISE EXCEPTION 'Check your name, phone and delivery address'; END IF;
 IF coalesce(payload->>'paymentMethod','') NOT IN ('cod','easypaisa','jazzcash') THEN RAISE EXCEPTION 'Choose COD, Easypaisa or JazzCash'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(uid::text,11));
 IF (SELECT count(*) FROM public.orders WHERE customer_id=uid::text AND created_at>now()-interval '1 day')>=20 THEN RAISE EXCEPTION 'Daily order limit reached'; END IF;
 SELECT email INTO email_address FROM auth.users WHERE id=uid;
 SELECT * INTO cfg FROM public.store_settings LIMIT 1;
 FOR entry IN SELECT value FROM jsonb_array_elements(payload->'items') ORDER BY value->>'productId' LOOP
  IF coalesce(entry->>'quantity','') !~ '^[1-9][0-9]{0,3}$' THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
  q:=(entry->>'quantity')::integer;
  SELECT * INTO p FROM public.products WHERE id=entry->>'productId' AND status='active' FOR UPDATE;
  IF NOT FOUND OR p.stock<q OR p.price<0 THEN RAISE EXCEPTION 'A product is unavailable or has insufficient stock'; END IF;
  subtotal:=subtotal+p.price*q;
  item_rows:=item_rows||jsonb_build_array(jsonb_build_object('id',gen_random_uuid()::text,'order_id',ident,'product_id',p.id,'product_name',p.name,'product_image',coalesce(p.images->>0,''),'price',p.price,'quantity',q,'subtotal',p.price*q));
  UPDATE public.products SET stock=stock-q,updated_at=now() WHERE id=p.id;
 END LOOP;
 IF coalesce(payload->>'appliedCoupon','')<>'' THEN
  SELECT * INTO coupon FROM public.coupons WHERE upper(code)=upper(payload->>'appliedCoupon') AND status='active' FOR UPDATE;
  IF NOT FOUND OR subtotal<coalesce(coupon.min_order,0) OR (coupon.usage_limit>0 AND coupon.usage_count>=coupon.usage_limit) OR (coalesce(coupon.expiry_date,'')<>'' AND coupon.expiry_date::date<current_date) THEN RAISE EXCEPTION 'Coupon is invalid or expired'; END IF;
  discount:=CASE WHEN coupon.discount_type IN ('percentage','percent') THEN round(subtotal*coupon.value/100,2) ELSE coupon.value END;
  IF coupon.max_discount>0 THEN discount:=least(discount,coupon.max_discount); END IF;
  discount:=greatest(0,least(discount,subtotal));
  UPDATE public.coupons SET usage_count=coalesce(usage_count,0)+1 WHERE id=coupon.id;
 END IF;
 delivery:=CASE WHEN subtotal>=coalesce(cfg.free_shipping_threshold,5000) THEN 0 ELSE coalesce(cfg.standard_shipping_fee,250) END;
 tax:=round((subtotal-discount)*coalesce((cfg.settings->>'taxPercentage')::numeric,0)/100,2);
 total:=subtotal-discount+delivery+tax;
 INSERT INTO public.orders(id,order_number,customer_id,customer_name,customer_email,customer_phone,shipping_address,city,payment_method,payment_status,order_status,subtotal,shipping_fee,discount_amount,total_amount,notes,details)
 VALUES(ident,'MB-'||upper(left(replace(ident,'-',''),12)),uid::text,left(payload->>'customerName',150),email_address,left(payload->>'phone',20),destination->>'address',destination->>'city',payload->>'paymentMethod','pending','Pending',subtotal,delivery,discount,total,left(coalesce(payload->>'notes',''),2000),jsonb_build_object('shippingAddress',destination,'tax',tax,'transactionId',left(coalesce(payload->>'transactionId',''),100),'paymentProofUrl',left(coalesce(payload->>'paymentProofUrl',''),2000))) RETURNING * INTO row_order;
 FOR entry IN SELECT value FROM jsonb_array_elements(item_rows) LOOP
  INSERT INTO public.order_items(id,order_id,product_id,product_name,product_image,price,quantity,subtotal) VALUES(entry->>'id',ident,entry->>'product_id',entry->>'product_name',entry->>'product_image',(entry->>'price')::numeric,(entry->>'quantity')::integer,(entry->>'subtotal')::numeric);
 END LOOP;
 INSERT INTO public.mb_notifications(recipient_id,title,message,link) SELECT id,'New order','Order '||row_order.order_number||' has been saved.','/admin' FROM auth.users WHERE raw_app_meta_data->>'role'='super_admin';
 INSERT INTO public.mb_notifications(recipient_id,title,message,link) VALUES(uid,'Order received','Your order '||row_order.order_number||' is pending confirmation.','/account/orders');
 RETURN jsonb_build_object('order',to_jsonb(row_order),'items',item_rows);
END $$;
REVOKE ALL ON FUNCTION public.mb_place_order(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_place_order(jsonb) TO authenticated;
CREATE OR REPLACE FUNCTION public.mb_submit_review(target_product text,stars integer,review_comment text) RETURNS public.reviews LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE uid uuid:=auth.uid(); r public.reviews; product_name text; buyer_name text; email_address text;
BEGIN
 IF uid IS NULL OR stars NOT BETWEEN 1 AND 5 OR length(trim(coalesce(review_comment,''))) NOT BETWEEN 3 AND 2000 THEN RAISE EXCEPTION 'Check review details and sign in'; END IF;
 SELECT name INTO product_name FROM public.products WHERE id=target_product AND status='active';
 IF NOT FOUND THEN RAISE EXCEPTION 'Product unavailable'; END IF;
 IF EXISTS(SELECT 1 FROM public.reviews WHERE product_id=target_product AND customer_id=uid::text) THEN RAISE EXCEPTION 'You already submitted a review for this product'; END IF;
 SELECT email,coalesce(raw_user_meta_data->>'display_name',split_part(email,'@',1)) INTO email_address,buyer_name FROM auth.users WHERE id=uid;
 INSERT INTO public.reviews(id,product_id,product_name,customer_id,customer_name,customer_email,rating,comment,is_verified_purchase,status)
 VALUES(gen_random_uuid()::text,target_product,product_name,uid::text,buyer_name,email_address,stars,trim(review_comment),EXISTS(SELECT 1 FROM public.orders o JOIN public.order_items i ON i.order_id=o.id WHERE o.customer_id=uid::text AND i.product_id=target_product AND o.order_status='Delivered'),'pending') RETURNING * INTO r;
 RETURN r;
END $$;
REVOKE ALL ON FUNCTION public.mb_submit_review(text,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_submit_review(text,integer,text) TO authenticated;
CREATE POLICY mb_reviews_owner_manage ON public.reviews FOR ALL TO authenticated USING(public.mb_is_admin()) WITH CHECK(public.mb_is_admin());
COMMIT;
