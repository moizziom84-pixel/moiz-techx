BEGIN;
CREATE TABLE IF NOT EXISTS public.mb_newsletter_subscribers(email text PRIMARY KEY,created_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE public.mb_newsletter_subscribers ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.mb_newsletter_subscribers TO authenticated;
CREATE POLICY newsletter_owner_read ON public.mb_newsletter_subscribers FOR SELECT TO authenticated USING(public.mb_is_admin());
CREATE OR REPLACE FUNCTION public.mb_subscribe(email_address text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF email_address IS NULL OR length(email_address)>254 OR email_address !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' THEN RAISE EXCEPTION 'Enter a valid email address'; END IF;
 INSERT INTO public.mb_newsletter_subscribers(email) VALUES(lower(trim(email_address))) ON CONFLICT DO NOTHING;
 RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.mb_subscribe(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_subscribe(text) TO anon,authenticated;
CREATE TABLE IF NOT EXISTS public.mb_support_messages(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),sender_id uuid NOT NULL REFERENCES auth.users(id),name text NOT NULL,body text NOT NULL,created_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE public.mb_support_messages ENABLE ROW LEVEL SECURITY;
GRANT SELECT,INSERT ON public.mb_support_messages TO authenticated;
CREATE POLICY support_read ON public.mb_support_messages FOR SELECT TO authenticated USING(sender_id=auth.uid() OR public.mb_is_admin());
CREATE POLICY support_insert ON public.mb_support_messages FOR INSERT TO authenticated WITH CHECK(sender_id=auth.uid() AND length(body) BETWEEN 3 AND 2000 AND length(name) BETWEEN 2 AND 150);
CREATE OR REPLACE VIEW public.mb_public_reviews WITH(security_barrier=true) AS SELECT id,product_id,product_name,customer_name,rating,comment,is_verified_purchase,status,created_at FROM public.reviews WHERE status='approved';
GRANT SELECT ON public.mb_public_reviews TO anon,authenticated;
DROP POLICY IF EXISTS "Public reviews read" ON public.reviews;
CREATE POLICY mb_private_reviews_read ON public.reviews FOR SELECT TO authenticated USING(customer_id=auth.uid()::text OR public.mb_is_admin());
CREATE OR REPLACE FUNCTION public.mb_notify_support() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 INSERT INTO public.mb_notifications(recipient_id,title,message,link) SELECT id,'New customer message','A customer message or complaint is waiting in the owner panel.','/admin' FROM auth.users WHERE raw_app_meta_data->>'role'='super_admin';
 RETURN NEW;
END $$;
CREATE TRIGGER support_notify_owner AFTER INSERT ON public.mb_support_messages FOR EACH ROW EXECUTE FUNCTION public.mb_notify_support();
CREATE TRIGGER complaint_notify_owner AFTER INSERT ON public.complaints FOR EACH ROW EXECUTE FUNCTION public.mb_notify_support();
COMMIT;
