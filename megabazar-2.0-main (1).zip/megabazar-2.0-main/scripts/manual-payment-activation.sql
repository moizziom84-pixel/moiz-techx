BEGIN;
UPDATE public.mb_plans SET duration_days=30 WHERE code IN ('business','premium') AND duration_days IS NULL;
INSERT INTO public.mb_payment_accounts(method,account_title,account_number,instructions,active)
VALUES ('easypaisa','Muhammad Moiz','03182204441','Upload the transfer receipt and Transaction ID for owner review.',true),
('jazzcash','MOIZ.S','984488781','Use this JazzCash Till ID. Upload the receipt and Transaction ID for owner review.',true)
ON CONFLICT(method) DO UPDATE SET account_title=EXCLUDED.account_title,account_number=EXCLUDED.account_number,instructions=EXCLUDED.instructions,active=true;
UPDATE public.mb_billing_settings SET collection_enabled=true,updated_at=now() WHERE id=1;
CREATE OR REPLACE FUNCTION public.mb_product_limit() RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $$
 SELECT coalesce((SELECT p.product_limit FROM public.mb_subscriptions s JOIN public.mb_plans p ON p.code=s.plan_code WHERE s.owner_id=auth.uid() AND s.expires_at>now() LIMIT 1),(SELECT product_limit FROM public.mb_plans WHERE code='free'),25);
$$;
REVOKE ALL ON FUNCTION public.mb_product_limit() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_product_limit() TO authenticated;
CREATE OR REPLACE FUNCTION public.mb_notify_payment() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  INSERT INTO public.mb_notifications(recipient_id,title,message,link) SELECT id,'Payment receipt awaiting review','A seller submitted a receipt for '||NEW.plan_code||' (PKR '||NEW.amount_pkr||'). Check the receiving account before approving.','/admin' FROM auth.users WHERE raw_app_meta_data->>'role'='super_admin';
 ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
  INSERT INTO public.mb_notifications(recipient_id,title,message,link) VALUES(NEW.owner_id,'Payment '||NEW.status,CASE WHEN NEW.status='approved' THEN 'Your '||NEW.plan_code||' plan is active. Open payment history for expiry details.' ELSE coalesce(nullif(NEW.reason,''),'Your payment request was reviewed.') END,'/subscriptions');
 END IF; RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS mb_payment_notifications ON public.mb_payment_requests;
CREATE TRIGGER mb_payment_notifications AFTER INSERT OR UPDATE ON public.mb_payment_requests FOR EACH ROW EXECUTE FUNCTION public.mb_notify_payment();
CREATE OR REPLACE FUNCTION public.mb_save_product(details jsonb,image_paths text[],product_id uuid DEFAULT NULL) RETURNS public.mb_products LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.mb_shops; p public.mb_products; path text; uid uuid:=auth.uid();
BEGIN
 IF uid IS NULL THEN RAISE EXCEPTION 'Sign in required'; END IF;
 SELECT * INTO s FROM public.mb_shops WHERE owner_id=uid AND status='approved' FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Approved shop required'; END IF;
 IF product_id IS NULL AND (SELECT count(*) FROM public.mb_products WHERE owner_id=uid AND status<>'paused')>=public.mb_product_limit() THEN RAISE EXCEPTION 'Product limit reached. Submit a plan payment for owner approval.'; END IF;
 IF octet_length(details::text)>50000 THEN RAISE EXCEPTION 'Product data too large'; END IF;
 IF jsonb_typeof(details) IS DISTINCT FROM 'object' OR coalesce(length(trim(details->>'name')),0) NOT BETWEEN 2 AND 180 OR coalesce(length(details->>'description'),0) NOT BETWEEN 20 AND 5000 OR coalesce(length(details->>'category'),0)<2 OR coalesce(length(details->>'contents'),0)<2 OR (details->>'condition') NOT IN ('new','used','refurbished') OR coalesce(details->>'condition','')='' THEN RAISE EXCEPTION 'Invalid details'; END IF;
 IF coalesce(details->>'price','') !~ '^[0-9]+(\.[0-9]{1,2})?$' OR (details->>'price')::numeric<=0 OR (details->>'price')::numeric>100000000 OR coalesce(details->>'stock','') !~ '^[0-9]+$' OR (details->>'stock')::numeric>10000000 OR coalesce(details->>'dispatch','') !~ '^[0-9]+$' OR (details->>'dispatch')::numeric NOT BETWEEN 1 AND 90 THEN RAISE EXCEPTION 'Invalid price/stock/dispatch'; END IF;
 IF coalesce(details->>'salePrice','')<>'' AND (details->>'salePrice' !~ '^[0-9]+(\.[0-9]{1,2})?$' OR (details->>'salePrice')::numeric<=0 OR (details->>'salePrice')::numeric>=(details->>'price')::numeric) THEN RAISE EXCEPTION 'Invalid discount'; END IF;
 IF details->>'enableWhatsapp'='true' AND (details->>'whatsappConsent' IS DISTINCT FROM 'true' OR coalesce(details->>'whatsapp','') !~ '^(\+92|92|0)3[0-9]{9}$') THEN RAISE EXCEPTION 'WhatsApp consent/number invalid'; END IF;
 IF coalesce(cardinality(image_paths),0) NOT BETWEEN 3 AND 8 OR (SELECT count(DISTINCT x) FROM unnest(image_paths) AS x)<>cardinality(image_paths) THEN RAISE EXCEPTION '3-8 images required'; END IF;
 FOREACH path IN ARRAY image_paths LOOP
  IF split_part(path,'/',1)<>uid::text OR NOT EXISTS(SELECT 1 FROM storage.objects WHERE bucket_id='mb-product-images' AND name=path) THEN RAISE EXCEPTION 'Invalid image ownership'; END IF;
 END LOOP;
 -- Whitelist public fields; never publish arbitrary private keys supplied by clients.
 details:=(SELECT coalesce(jsonb_object_agg(key,value),'{}') FROM jsonb_each(details) WHERE key=ANY(ARRAY['name','category','subcategory','otherCategory','brand','condition','description','contents','price','salePrice','stock','unit','sku','size','colour','material','model','capacity','ingredients','expiry','variants','weight','dimensions','dispatch','warranty','whatsapp','enableWhatsapp','whatsappConsent']));
 IF details->>'enableWhatsapp' IS DISTINCT FROM 'true' THEN details:=details-'whatsapp'; END IF;
 IF product_id IS NULL THEN INSERT INTO public.mb_products(shop_id,owner_id,details,images) VALUES(s.id,uid,details,image_paths) RETURNING * INTO p;
 ELSE UPDATE public.mb_products SET details=mb_save_product.details,images=image_paths,status='pending',reason='',updated_at=now() WHERE id=product_id AND owner_id=uid RETURNING * INTO p;IF NOT FOUND THEN RAISE EXCEPTION 'Product unavailable'; END IF;END IF;
 RETURN p;
END $$;

COMMIT;
