BEGIN;
ALTER TABLE public.mb_shops ADD COLUMN IF NOT EXISTS logo_path text, ADD COLUMN IF NOT EXISTS banner_path text, ADD COLUMN IF NOT EXISTS plan text NOT NULL DEFAULT 'free';
CREATE TABLE IF NOT EXISTS public.mb_notifications(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),recipient_id uuid NOT NULL REFERENCES auth.users(id),title text NOT NULL,message text NOT NULL,link text NOT NULL DEFAULT '/account',read_at timestamptz,created_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE public.mb_notifications ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.mb_notifications TO authenticated;
GRANT UPDATE(read_at) ON public.mb_notifications TO authenticated;
CREATE POLICY mb_notifications_read ON public.mb_notifications FOR SELECT TO authenticated USING(recipient_id=auth.uid());
CREATE POLICY mb_notifications_read_state ON public.mb_notifications FOR UPDATE TO authenticated USING(recipient_id=auth.uid()) WITH CHECK(recipient_id=auth.uid());
CREATE INDEX IF NOT EXISTS mb_notifications_recipient ON public.mb_notifications(recipient_id,created_at DESC);
CREATE OR REPLACE FUNCTION public.mb_submit_shop(details jsonb) RETURNS public.mb_shops LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE uid uuid:=auth.uid(); s public.mb_shops; email_address text; slug_base text;
BEGIN
 IF uid IS NULL THEN RAISE EXCEPTION 'Sign in first'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(uid::text,7));
 SELECT email INTO email_address FROM auth.users WHERE id=uid;
 IF coalesce(length(trim(coalesce(details->>'name',details->>'shopName'))),0) NOT BETWEEN 2 AND 150 OR coalesce(length(trim(coalesce(details->>'owner',details->>'ownerName'))),0) NOT BETWEEN 2 AND 150 OR coalesce(length(trim(details->>'city')),0)<2 OR coalesce(length(trim(details->>'address')),0)<5 OR coalesce(details->>'phone','') !~ '^(\+92|92|0)3[0-9]{9}$' THEN RAISE EXCEPTION 'Check shop name, owner, phone, city and address'; END IF;
 SELECT * INTO s FROM public.mb_shops WHERE owner_id=uid ORDER BY created_at LIMIT 1 FOR UPDATE;
 IF FOUND THEN
  IF s.status NOT IN ('rejected','pending') THEN RETURN s; END IF;
  UPDATE public.mb_shops SET name=trim(coalesce(details->>'name',details->>'shopName')),owner_name=trim(coalesce(details->>'owner',details->>'ownerName')),email=email_address,phone=details->>'phone',city=details->>'city',address=details->>'address',description=left(coalesce(details->>'description',''),5000),status='pending',updated_at=now() WHERE id=s.id RETURNING * INTO s;
 ELSE
  slug_base:=left(trim(both '-' from regexp_replace(lower(details->>'name'),'[^a-z0-9]+','-','g')),55);
  IF slug_base='' THEN slug_base:='shop'; END IF;
  INSERT INTO public.mb_shops(owner_id,owner_name,email,phone,name,slug,category,city,address,description,status)
  VALUES(uid,trim(coalesce(details->>'owner',details->>'ownerName')),email_address,details->>'phone',trim(details->>'name'),slug_base||'-'||left(replace(uid::text,'-',''),8),coalesce(nullif(details->>'category',''),'General'),details->>'city',details->>'address',left(coalesce(details->>'description',''),5000),'pending') RETURNING * INTO s;
 END IF;
 RETURN s;
END $$;
CREATE OR REPLACE FUNCTION public.mb_review_shop(shop_id uuid,decision text,review_reason text DEFAULT '',mark_verified boolean DEFAULT false) RETURNS public.mb_shops LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.mb_shops;
BEGIN
 IF NOT public.mb_is_admin() THEN RAISE EXCEPTION 'Owner access required'; END IF;
 IF decision NOT IN ('approved','rejected','suspended') THEN RAISE EXCEPTION 'Invalid decision'; END IF;
 IF decision IN ('rejected','suspended') AND length(trim(coalesce(review_reason,'')))<5 THEN RAISE EXCEPTION 'A reason is required'; END IF;
 UPDATE public.mb_shops SET status=decision,reason=left(coalesce(review_reason,''),1000),verified=(decision='approved' AND mark_verified),reviewed_at=now(),updated_at=now() WHERE id=shop_id RETURNING * INTO s;
 IF NOT FOUND THEN RAISE EXCEPTION 'Shop not found'; END IF;
 INSERT INTO public.mb_admin_events(actor_id,shop_id,action,reason) VALUES(auth.uid(),s.id,'shop_'||decision,review_reason);
 RETURN s;
END $$;
REVOKE ALL ON FUNCTION public.mb_submit_shop(jsonb),public.mb_review_shop(uuid,text,text,boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_submit_shop(jsonb),public.mb_review_shop(uuid,text,text,boolean) TO authenticated;
CREATE OR REPLACE FUNCTION public.mb_notify_shop() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF TG_OP='INSERT' OR (NEW.status='pending' AND NEW.status IS DISTINCT FROM OLD.status) THEN
  INSERT INTO public.mb_notifications(recipient_id,title,message,link) SELECT id,'New shop application',NEW.name||' is waiting for your approval.','/admin' FROM auth.users WHERE raw_app_meta_data->>'role'='super_admin';
 ELSIF NEW.status IS DISTINCT FROM OLD.status AND NEW.owner_id IS NOT NULL THEN
  INSERT INTO public.mb_notifications(recipient_id,title,message,link) VALUES(NEW.owner_id,'Shop '||NEW.status,NEW.name||': '||NEW.status||CASE WHEN coalesce(NEW.reason,'')<>'' THEN ' — '||NEW.reason ELSE '' END,'/seller/dashboard');
 END IF; RETURN NEW;
END $$;
CREATE TRIGGER mb_notify_shop_change AFTER INSERT OR UPDATE ON public.mb_shops FOR EACH ROW EXECUTE FUNCTION public.mb_notify_shop();
CREATE TABLE IF NOT EXISTS public.mb_plans(code text PRIMARY KEY,name text NOT NULL,price_pkr numeric NOT NULL DEFAULT 0,product_limit integer NOT NULL DEFAULT 25,billing_period text NOT NULL DEFAULT 'monthly',enabled boolean NOT NULL DEFAULT true);
INSERT INTO public.mb_plans(code,name,price_pkr,product_limit) VALUES('free','Free',0,25),('business','Business',1500,250),('premium','Premium',3000,1000) ON CONFLICT DO NOTHING;
ALTER TABLE public.mb_plans ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.mb_plans TO anon,authenticated;
CREATE POLICY mb_plans_read ON public.mb_plans FOR SELECT TO anon,authenticated USING(enabled OR public.mb_is_admin());
COMMIT;
