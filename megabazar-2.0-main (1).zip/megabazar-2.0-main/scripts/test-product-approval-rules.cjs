const { PGlite } = require('@electric-sql/pglite');
const fs = require('fs');
const path = require('path');
const assert = require('assert');

(async () => {
  console.log('Testing Product Approval Rules with PGlite...');
  const db = new PGlite();
  await db.exec(`
    CREATE ROLE anon;
    CREATE ROLE authenticated;
    CREATE ROLE service_role;
    CREATE SCHEMA auth;
    CREATE SCHEMA storage;
    CREATE TABLE auth.users(id uuid PRIMARY KEY, email text, raw_app_meta_data jsonb DEFAULT '{}');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    CREATE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $$ SELECT coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb $$;
    CREATE TABLE storage.buckets(id text PRIMARY KEY, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
    CREATE TABLE storage.objects(id uuid DEFAULT gen_random_uuid(), bucket_id text, name text, PRIMARY KEY(bucket_id, name));
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
    GRANT USAGE ON SCHEMA auth,storage TO anon,authenticated;
    GRANT SELECT,INSERT ON storage.objects TO anon,authenticated;
    CREATE FUNCTION storage.foldername(text) RETURNS text[] LANGUAGE sql IMMUTABLE AS $$ SELECT string_to_array($1,'/') $$;
  `);

  // Load migrations in order
  for (const p of [
    'scripts/marketplace-setup-review.sql',
    'scripts/complete-marketplace.sql',
    'scripts/marketplace-products-chat-review.sql',
    'scripts/marketplace-subscriptions-review.sql',
    'scripts/update-product-approval-rules.sql',
  ]) {
    const fullPath = path.join(__dirname, '..', p);
    if (fs.existsSync(fullPath)) {
      console.log(`Applying ${p}...`);
      await db.exec(fs.readFileSync(fullPath, 'utf8'));
    }
  }

  const seller = '11111111-1111-4111-8111-111111111111';
  const owner = '33333333-3333-4333-8333-333333333333';
  await db.query('INSERT INTO auth.users VALUES ($1,$2),($3,$4)', [
    seller, 'seller@example.com',
    owner, 'owner@example.com',
  ]);

  async function as(id, admin = false) {
    await db.exec('RESET ROLE');
    await db.query(
      "SELECT set_config('request.jwt.claim.sub',$1,false),set_config('request.jwt.claims',$2,false)",
      [id || '', JSON.stringify({ app_metadata: admin ? { role: 'super_admin' } : {} })]
    );
    await db.exec('SET ROLE ' + (id ? 'authenticated' : 'anon'));
  }

  // Submit shop by seller
  await as(seller);
  const shopDetails = {
    owner: 'Test Seller',
    email: 'seller@example.com',
    phone: '923001234567',
    name: 'Test Approved Shop',
    category: 'Fashion & Apparel',
    city: 'Lahore',
    area: 'Gulberg',
    address: 'Gulberg III, Lahore',
    sameReturn: true,
    description: 'A verified fashion outlet in Lahore.',
    acceptedTerms: true,
  };
  const shop = (await db.query('SELECT * FROM public.mb_submit_shop($1::jsonb)', [JSON.stringify(shopDetails)])).rows[0];
  assert.equal(shop.status, 'pending', 'Newly submitted shop must be pending');

  // Owner approves shop
  await as(owner, true);
  await db.query("SELECT public.mb_review_shop($1,'approved','',true)", [shop.id]);

  // Seller creates product - Since shop is approved, product should automatically be approved!
  await db.exec('RESET ROLE');
  const imgPaths = [1, 2, 3].map(i => `${seller}/test-prod-${i}.webp`);
  for (const img of imgPaths) {
    await db.query("INSERT INTO storage.objects(bucket_id, name) VALUES('mb-product-images', $1)", [img]);
  }

  await as(seller);
  const productData = {
    name: 'Silk Embroidered Kurti',
    category: 'Fashion & Apparel',
    description: 'Handcrafted premium silk kurti with delicate embroidery.',
    contents: '1x Stitched Kurti',
    condition: 'new',
    price: '3499',
    salePrice: '2999',
    stock: '15',
    dispatch: '2',
    enableWhatsapp: false,
    unit: 'piece',
  };

  const saved = (await db.query('SELECT * FROM public.mb_save_product($1::jsonb, $2::text[], null)', [
    JSON.stringify(productData),
    imgPaths,
  ])).rows[0];

  console.log('Saved product status:', saved.status);
  assert.equal(saved.status, 'approved', 'Product must be automatically approved when shop is approved!');

  // Verify public visibility
  await as(null); // anonymous customer
  const publicProducts = (await db.query('SELECT * FROM public.mb_public_products WHERE id = $1', [saved.id])).rows;
  assert.equal(publicProducts.length, 1, 'Product must be immediately visible to public customers');
  console.log('Verified public visibility: Product visible in public catalogue');

  // Verify that an admin can still suspend a product and it hides from public
  await as(owner, true);
  await db.query("SELECT public.mb_review_product($1, 'suspended', 'Policy violation')", [saved.id]);
  
  await as(null);
  const hiddenProducts = (await db.query('SELECT * FROM public.mb_public_products WHERE id = $1', [saved.id])).rows;
  assert.equal(hiddenProducts.length, 0, 'Admin-suspended product must not be publicly visible');
  console.log('Verified moderation: Admin-suspended product is hidden from public');

  console.log('PASS: All Product Approval Rules verified successfully!');
  await db.close();
})().catch(e => {
  console.error('Test failed:', e);
  process.exit(1);
});
