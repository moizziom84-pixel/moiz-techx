# Mega Bazar release checks

Completed: restored missing source/router/pages, Supabase-backed manual payment requests with private receipts, owner approval and expiring plan limits, persistent catalogue/settings/orders/banners/reviews/support/complaints, owner-scoped server routes, authoritative order pricing and atomic stock updates, and authenticated image uploads.

Verification: TypeScript and Vite production build pass. Ten local HTTP checks pass, including denied anonymous order/admin writes. Database rollback tests pass for manual-payment confirmation, owner-only review, invalid receipts, plan activation, authoritative order prices, atomic stock/items and private payment/notification access.

The configured receiving accounts are the owner's existing Easypaisa account and JazzCash Till ID. Receipts stay private in mb-payment-receipts. Approval requires the owner to confirm actual received funds.

Applied one-time migrations: complete-marketplace.sql, complete-products-chat.sql, marketplace-subscriptions-review.sql, manual-payment-activation.sql, persistent-store-api.sql and store-feedback.sql. Do not rerun these unchanged. verify-store-transactions.sql is a rollback-only verification script.

Deployment: use Node 22, npm and server.js. npm postinstall builds dist with the hosting environment variables. NEXT_PUBLIC_SUPABASE_URL must be the project root URL, not /rest/v1. Secrets belong in hosting environment variables, never frontend source.

Deployment completed on Hostinger using Node 22 and server.js. megabazar.live now points to the repaired GitHub app. The previous manual ZIP app remains at megabazar-live-991081.hostingersite.com as a rollback copy. Hostinger confirms commit 81b58e7d completed; this fixes Vite browser access to public Supabase configuration. Live product API returns persisted catalogue data; anonymous orders and super-admin access are denied. Login reaches Supabase but the supplied owner password is rejected. Recovery request accepted; the owner must open the latest reset email and enter the new password. Added the exact production reset-password redirect URL.

Still to verify: successful owner login, real browser image/receipt upload, owner payment queue. Resend SMTP/API delivery and the requested password change are not confirmed. Do not describe the full marketplace as completely verified yet.
