import { supabase } from './supabase/client';
export async function apiFetch(input: string, options: RequestInit = {}): Promise<Response> {
  const { data: { session } } = await supabase.auth.getSession();
  const headers = new Headers(options.headers);
  if (session) headers.set('Authorization', `Bearer ${session.access_token}`);
  const response = await fetch(input, { ...options, headers });
  if (!response.ok) {
    const detail = await response.clone().json().catch(() => ({}));
    throw new Error(detail.message || detail.error || `Request failed (${response.status}). Nothing was confirmed saved.`);
  }
  return response;
}
