import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';

export async function uploadShopImage(file: File, bucket = 'mb-product-images') {
  if (!['mb-product-images', 'mb-payment-receipts'].includes(bucket)) throw new Error('Invalid image destination.');
  if (!isSupabaseConfigured) throw new Error('Database is not configured.');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
    throw new Error('Use a JPG, PNG or WebP image smaller than 5 MB.');
  }
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) throw new Error('Sign in before uploading.');
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement('canvas');
  const scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d');
  if (!context) { bitmap.close(); throw new Error('Image processing unavailable.'); }
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('Image conversion failed.')), 'image/webp', .85));
  if (blob.type !== 'image/webp' || blob.size > 5 * 1024 * 1024) throw new Error('Could not prepare a WebP image.');
  const imagePath = `${user.id}/${crypto.randomUUID()}.webp`;
  const { error } = await supabase.storage.from(bucket).upload(imagePath, blob, { contentType: 'image/webp', upsert: false });
  if (error) throw new Error(`Image was not uploaded: ${error.message}`);
  return imagePath;
}

