import { supabase } from '@/lib/supabase/client';
import type { SellerShop, NotificationItem } from '@/lib/types';

export function mapShop(row: any): SellerShop {
  const getUrl = (p?: string) => {
    if (!p) return undefined;
    if (p.startsWith('http://') || p.startsWith('https://')) return p;
    return supabase.storage.from('mb-product-images').getPublicUrl(p).data.publicUrl;
  };

  return {
    id: row.id,
    ownerId: row.owner_id || '',
    ownerName: row.owner_name || 'Verified Merchant',
    email: row.email || '',
    phone: row.phone || '',
    name: row.name || 'Shop',
    slug: row.slug || row.id,
    category: row.category || 'Multi-Vendor Retail',
    city: row.city || 'Pakistan',
    area: row.area || row.city || '',
    address: row.address || '',
    description: row.description || '',
    rejectionReason: row.reason || '',
    status: ({ approved: 'Approved', rejected: 'Rejected', suspended: 'Suspended' } as Record<string, SellerShop['status']>)[row.status] || 'Pending',
    isVerified: !!row.verified,
    commissionRate: row.commission_rate || '5%',
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: row.updated_at || new Date().toISOString(),
    logoUrl: row.logo_url || getUrl(row.logo_path) || (row.name ? undefined : undefined),
    logoPath: row.logo_path,
    bannerUrl: row.banner_url || getUrl(row.banner_path),
    bannerPath: row.banner_path,
    ownerAvatarUrl: row.owner_avatar_url || getUrl(row.owner_avatar_path),
    rating: Number(row.rating || 5),
    reviewCount: Number(row.review_count || 0),
  };
}

// Never supply client-generated IDs or accept a successful local-only submission.
// The existing SQL function verifies the auth user and always starts in pending.
export async function submitShop(details: Record<string, unknown>, client = supabase) {
  const { data: { user }, error: authError } = await client.auth.getUser();
  if (authError || !user) throw new Error('Sign in and verify your email before submitting your shop.');
  const { data, error } = await client.rpc('mb_submit_shop', {
    details: { ...details, email: user.email },
  });
  if (error) throw new Error(`Shop was not saved: ${error.message}`);
  if (!data?.id) throw new Error('Database did not confirm the saved shop.');
  return data;
}

export async function reviewShop(shopId: string, decision: string, reason = '', client = supabase) {
  const { data, error } = await client.rpc('mb_review_shop', {
    shop_id: shopId, decision, review_reason: reason, mark_verified: decision === 'approved',
  });
  if (error) throw new Error(`Shop review was not saved: ${error.message}`);
  if (!data?.id) throw new Error('Database did not confirm this review.');
  return data;
}

// A saved shop row is the durable event: owners see pending applications even
// after being offline. Stable IDs prevent duplicate alerts on each poll.
export function shopAlerts(shops: SellerShop[], owner: boolean, uid: string): NotificationItem[] {
  return shops.filter(s => owner ? s.status === 'Pending' : s.ownerId === uid).map(s => ({
    id: `db-shop-${uid}-${s.id}-${s.status}-${s.updatedAt}`,
    title: owner ? 'New shop application' : `Shop ${s.status.toLowerCase()}`,
    message: owner ? `${s.name} is waiting for your approval.` : `${s.name}: ${s.status}${s.rejectionReason ? ' — ' + s.rejectionReason : ''}`,
    type: 'system', read: false, createdAt: s.updatedAt || s.createdAt,
    link: owner ? '/admin' : '/seller/dashboard',
  }));
}

export function mergeShopAlerts(existing: NotificationItem[], incoming: NotificationItem[]) {
  const known = new Map(existing.map(n => [n.id, n]));
  return [...incoming.map(n => known.get(n.id) || n), ...existing.filter(n => !n.id.startsWith('db-shop-'))];
}

