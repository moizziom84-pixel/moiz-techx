import { supabase } from '@/lib/supabase/client';

function value<T>(result: { data: T; error: { message: string } | null }): T {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}

export async function billingRequest(url: URL, method: string, body: any, uid: string, owner: boolean): Promise<any> {
  if (url.pathname === '/api/marketplace/receipt' && method === 'GET') {
    const id = url.searchParams.get('id');
    if (!id) throw new Error('Choose a payment request.');
    const payment = value(await supabase.from('mb_payment_requests').select('receipt_path').eq('id', id).single());
    if (!payment) throw new Error('Payment request unavailable.');
    const signed = value(await supabase.storage.from('mb-payment-receipts').createSignedUrl(payment.receipt_path, 60));
    if (!signed?.signedUrl) throw new Error('Receipt link unavailable.');
    return { url: signed.signedUrl };
  }
  if (url.pathname === '/api/marketplace/subscriptions') {
    if (method === 'GET') {
      const admin = owner && url.searchParams.get('admin') === 'true';
      const paymentQuery = supabase.from('mb_payment_requests').select('*').order('created_at', { ascending: false }).limit(200);
      const subscriptionQuery = supabase.from('mb_subscriptions').select('*');
      const results = await Promise.all([
        supabase.from('mb_billing_settings').select('*').eq('id', 1).single(),
        supabase.from('mb_plans').select('*').order('price_pkr'),
        supabase.from('mb_payment_accounts').select('*').order('method'),
        admin ? paymentQuery : paymentQuery.eq('owner_id', uid),
        admin ? subscriptionQuery : subscriptionQuery.eq('owner_id', uid),
      ]);
      const [settings, plans, accounts, payments, subscriptions] = results.map(value);
      return { settings, plans, accounts, payments, subscriptions };
    }
    if (method === 'POST') {
      const payment = value(await supabase.rpc('mb_submit_payment', {
        requested_plan: body.plan, payment_account: body.accountId,
        txn: body.transactionId, sender: body.sender, payment_date: body.paidAt, receipt: body.receipt,
      }));
      if (!payment?.id) throw new Error('Database did not confirm the payment request.');
      return { payment };
    }
    if (method === 'PATCH') {
      if (!owner) throw new Error('Super Admin access required.');
      const payment = value(await supabase.rpc('mb_review_payment', {
        payment_id: body.id, decision: body.status, review_reason: body.reason || '', received_confirmed: body.confirmed === true,
      }));
      if (!payment?.id) throw new Error('Database did not confirm the review.');
      return { payment };
    }
  }
  if (url.pathname === '/api/marketplace/billing' && method === 'PATCH') {
    if (!owner) throw new Error('Super Admin access required.');
    if (body.type === 'settings') {
      const freeUntil = body.freeUntil ? new Date(body.freeUntil) : null;
      if (freeUntil && !Number.isFinite(freeUntil.getTime())) throw new Error('Choose a valid date.');
      return { settings: value(await supabase.from('mb_billing_settings').update({ collection_enabled: body.enabled === true, free_until: freeUntil?.toISOString() || null, updated_at: new Date().toISOString() }).eq('id', 1).select().single()) };
    }
    if (body.type === 'plan') {
      const price = Number(body.price), days = Number(body.days);
      if (!['business', 'premium'].includes(body.code) || !Number.isFinite(price) || price <= 0 || price > 1000000 || !Number.isInteger(days) || days < 1 || days > 3660) throw new Error('Check plan price and duration.');
      return { plan: value(await supabase.from('mb_plans').update({ price_pkr: price, duration_days: days, enabled: body.enabled === true }).eq('code', body.code).select().single()) };
    }
    if (body.type === 'account') {
      const title = String(body.title || '').trim(), number = String(body.number || '').trim();
      if (!['easypaisa', 'jazzcash', 'bank'].includes(body.method) || title.length < 2 || title.length > 150 || number.length < 3 || number.length > 100) throw new Error('Check account title and number.');
      return { account: value(await supabase.from('mb_payment_accounts').upsert({ method: body.method, account_title: title, account_number: number, instructions: String(body.instructions || '').slice(0, 1000), active: body.active === true }, { onConflict: 'method' }).select().single()) };
    }
  }
  throw new Error('Unsupported payment operation. Nothing was saved.');
}
