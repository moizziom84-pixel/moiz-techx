import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { submitShop, reviewShop } from './shops';
import { billingRequest } from './billing';

export const marketplaceEnabled = isSupabaseConfigured;

function unwrap(result: any) {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}

// The archived Vite app has no marketplace API server. Use its existing,
// permission-checked Supabase RPCs rather than calling nonexistent endpoints.
export async function marketplaceFetch(path: string, options: RequestInit = {}): Promise<any> {
  if (!isSupabaseConfigured) throw new Error('Live database is not configured.');
  const url = new URL(path, window.location.origin);
  const method = (options.method || 'GET').toUpperCase();
  const body = typeof options.body === 'string' ? JSON.parse(options.body) : {};
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) throw new Error('Sign in with a verified account first.');
  const isOwner = user.app_metadata?.role === 'super_admin';
  if (url.searchParams.get('admin') === 'true' && !isOwner) throw new Error('Owner access required.');
  if (['/api/marketplace/subscriptions', '/api/marketplace/billing', '/api/marketplace/receipt'].includes(url.pathname)) {
    return billingRequest(url, method, body, user.id, isOwner);
  }
  switch (url.pathname) {
    case '/api/marketplace/me':
      return { user, isOwner, id: user.id, email: user.email };
    case '/api/marketplace/shops':
      if (method === 'POST') return { shop: await submitShop(body) };
      if (method === 'PATCH') return { shop: await reviewShop(body.id, body.status || body.decision, body.reason) };
      if (method === 'GET') {
        const query = supabase.from('mb_shops').select('*');
        if (isOwner && url.searchParams.get('admin') === 'true') return { shops: unwrap(await query.order('created_at', { ascending: false })) };
        return { shop: unwrap(await query.eq('owner_id', user.id).maybeSingle()) };
      }
      break;
    case '/api/marketplace/shop-media':
      if (method === 'POST') return { shop: unwrap(await supabase.rpc('mb_set_shop_media', { logo_image: body.logo, banner_image: body.banner })) };
      break;
    case '/api/marketplace/products':
      if (method === 'GET') {
        let query = supabase.from('mb_products').select('*');
        if (!(isOwner && url.searchParams.get('admin') === 'true')) query = query.eq('owner_id', user.id);
        return { products: unwrap(await query.order('created_at', { ascending: false })) };
      }
      if (method === 'PATCH') {
        const product = body.action === 'review'
          ? unwrap(await supabase.rpc('mb_review_product', { product_id: body.id, decision: body.status, review_reason: body.reason || '' }))
          : unwrap(await supabase.rpc('mb_pause_product', { product_id: body.id }));
        return { product };
      }
      break;
    case '/api/marketplace/chat':
      if (method === 'POST') return { threadId: unwrap(await supabase.rpc('mb_open_chat', { target_shop: body.shopId })) };
      break;
  }
  throw new Error('This feature needs its database/backend integration. It has not been saved.');
}

