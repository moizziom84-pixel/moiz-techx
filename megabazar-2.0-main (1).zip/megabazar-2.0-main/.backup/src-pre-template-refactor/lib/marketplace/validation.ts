import { formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
export function validateProduct(p:any){
 if(!p||typeof p!=='object'||Array.isArray(p))return 'Invalid product.';
 for(const value of Object.values(p))if(typeof value==='string'&&value.length>5000)return 'A product field is too long.';
 for(const k of ['name','category','description','contents'])if(typeof p[k]!=='string'||p[k].trim().length<(k==='description'?20:2)||p[k].length>5000)return `Please check ${k}.`;
 const price=Number(p.price),stock=Number(p.stock),sale=p.salePrice?Number(p.salePrice):null;
 if(!Number.isFinite(price)||price<=0||price>100000000||!Number.isInteger(stock)||stock<0||stock>10000000)return 'Check price and stock.';
 if(sale!==null&&(!Number.isFinite(sale)||sale<=0||sale>=price))return 'Discount price must be lower than regular price.';
 if(!['new','used','refurbished'].includes(p.condition))return 'Choose a valid condition.';
 if(!Number.isInteger(Number(p.dispatch))||Number(p.dispatch)<1||Number(p.dispatch)>90)return 'Check order preparation days.';
 if(p.enableWhatsapp&&(!p.whatsappConsent||!formatPakistaniWhatsAppNumber(p.whatsapp||'').isValid))return 'Check WhatsApp number and consent.';
 return null;
}
