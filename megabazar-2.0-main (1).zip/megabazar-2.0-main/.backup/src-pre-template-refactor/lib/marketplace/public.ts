import { supabase } from '@/lib/supabase/client';
export function publicImage(path:string){const base=typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_SUPABASE_URL||'' : '';return `${base}/storage/v1/object/public/mb-product-images/${path.split('/').map(encodeURIComponent).join('/')}`;}
export async function publicListing(id:string){try{const {data,error}=await supabase.from('mb_public_products').select('*').eq('id',id).maybeSingle();return error?null:data;}catch{return null;}}
