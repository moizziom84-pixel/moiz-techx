import { supabase } from '@/lib/supabase/client';

export const MIN_PASSWORD_LENGTH = 8;
export function passwordProblem(password: string, confirmation: string) {
  if (password.length < MIN_PASSWORD_LENGTH) return 'Use at least 8 characters for your password.';
  if (password.length > 128) return 'Use no more than 128 characters.';
  if (password !== confirmation) return 'Passwords do not match. Please enter the same password twice.';
  return '';
}

export function accountError(error: unknown) {
  const e = error as { message?: string; code?: string; status?: number };
  const message = e?.message || 'Could not complete this request. Please try again.';
  if (e?.status === 429 || /rate.limit|too many|over_email_send_rate_limit/i.test(`${e?.code} ${message}`)) {
    return 'Too many reset or verification emails were requested. Check your inbox and spam for the last email, or try again later.';
  }
  if (/invalid.login.credentials/i.test(message)) return 'Email or password is incorrect. Check your details or choose Forgot password.';
  if (/expired|otp_expired|invalid.*token|session.*missing/i.test(`${e?.code} ${message}`)) return 'This reset link is invalid or expired. Request a new link from Sign in → Forgot password.';
  return message;
}

export async function createAccount(input: { email: string; password: string; confirmation: string; name: string; phone?: string; origin: string }, client = supabase) {
  const problem = passwordProblem(input.password, input.confirmation);
  if (problem) throw new Error(problem);
  const { data, error } = await client.auth.signUp({
    email: input.email.trim(), password: input.password,
    options: { emailRedirectTo: `${input.origin}/login`, data: { display_name: input.name.trim(), phone: input.phone?.trim() || undefined } },
  });
  if (error) throw error;
  return data;
}

export async function requestRecovery(email: string, origin: string, client = supabase) {
  if (!email.trim()) throw new Error('Enter the email used for your account.');
  const { error } = await client.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${origin}/reset-password` });
  if (error) throw error;
}

export async function saveOwnPassword(password: string, confirmation: string, client = supabase) {
  const problem = passwordProblem(password, confirmation);
  if (problem) throw new Error(problem);
  // Identity comes only from the validated session, never an email typed into a form.
  const { data: { user }, error: sessionError } = await client.auth.getUser();
  if (sessionError || !user) throw new Error('Open the password reset link from your email first, or sign in to your account.');
  const { data, error } = await client.auth.updateUser({ password });
  if (error) throw error;
  if (!data.user || data.user.id !== user.id) throw new Error('The password update was not confirmed for your account.');
  return data.user;
}

