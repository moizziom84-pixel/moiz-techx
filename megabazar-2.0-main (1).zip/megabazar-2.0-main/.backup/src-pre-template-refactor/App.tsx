import { PaymentsPage } from '@/pages/PaymentsPage';
import { SellerProductPage } from '@/pages/SellerProductPage';
import { MessagesPage } from '@/pages/MessagesPage';
import { LiveShopPage } from '@/pages/LiveShopPage';
import { ListingPage } from '@/pages/ListingPage';
import React, { useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import { RouterProvider, useRouterContext } from '@/router/router-context';
import { ClientLayout } from '@/components/ClientLayout';
import { HomePage } from '@/pages/HomePage';
import { ProductsPage } from '@/pages/ProductsPage';
import { CategoriesPage } from '@/pages/CategoriesPage';
import { CategoryPage } from '@/pages/CategoryPage';
import { ProductDetailPage } from '@/pages/ProductDetailPage';
import { CartPage } from '@/pages/CartPage';
import { CheckoutPage } from '@/pages/CheckoutPage';
import { OrderConfirmationPage } from '@/pages/OrderConfirmationPage';
import { DemoShopsPage } from '@/pages/DemoShopsPage';
import { DemoShopDetailPage } from '@/pages/DemoShopDetailPage';
import { OpenShopPage } from '@/pages/OpenShopPage';
import { SellerDashboardPage } from '@/pages/SellerDashboardPage';
import { AdminDashboard } from '@/pages/AdminDashboard';
import { WishlistPage } from '@/pages/WishlistPage';
import { OrdersPage } from '@/pages/OrdersPage';
import { AboutPage, ContactPage, PrivacyTermsPage, AuthPage, ResetPasswordPage } from '@/pages/InfoPages';

function RecoveryRedirect() {
  const { navigate } = useRouterContext();
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY' && !window.location.pathname.includes('reset-password')) navigate('/reset-password');
    });
    return () => data.subscription.unsubscribe();
  }, []);
  return null;
}

function AppRoutes() {
  const { pathname } = useRouterContext();

  // Normalize path
  const path = pathname.toLowerCase().replace(/\/$/, '') || '/';

  if (path === '/subscriptions') return <PaymentsPage />;
  if (path === '/seller/products/new') return <SellerProductPage />;
  if (path === '/messages') return <MessagesPage />;
  if (path.startsWith('/listing/')) return <ListingPage />;
  if (path.startsWith('/shop/') && path !== '/shop/preview') return <LiveShopPage />;

  if (path === '/') {
    return <HomePage />;
  }

  if (path === '/products' || path === '/search' || path === '/deals') {
    return <ProductsPage />;
  }

  if (path === '/categories') {
    return <CategoriesPage />;
  }

  if (path.startsWith('/category/')) {
    return <CategoryPage />;
  }

  if (path.startsWith('/product/')) {
    return <ProductDetailPage />;
  }

  if (path === '/cart') {
    return <CartPage />;
  }

  if (path === '/checkout') {
    return <CheckoutPage />;
  }

  if (path.startsWith('/order-confirmation')) {
    return <OrderConfirmationPage />;
  }

  if (path === '/shop/preview' || path === '/shops') {
    return <DemoShopsPage />;
  }

  if (path.startsWith('/demo-shops/') || (path.startsWith('/shop/') && path !== '/shop/preview')) {
    return <DemoShopDetailPage />;
  }

  if (path === '/open-shop' || path === '/seller/products/new') {
    return <OpenShopPage />;
  }

  if (path === '/seller/dashboard') {
    return <SellerDashboardPage />;
  }

  if (path.startsWith('/admin')) {
    return <AdminDashboard />;
  }

  if (path === '/account/wishlist') {
    return <WishlistPage />;
  }

  if (path === '/account/orders' || path === '/account') {
    return <OrdersPage />;
  }

  if (path === '/about') {
    return <AboutPage />;
  }

  if (path === '/contact') {
    return <ContactPage />;
  }

  if (path === '/privacy') {
    return <PrivacyTermsPage type="privacy" />;
  }

  if (path === '/terms') {
    return <PrivacyTermsPage type="terms" />;
  }

  if (path === '/login' || path === '/seller/auth') {
    return <AuthPage mode="login" />;
  }

  if (path === '/register') {
    return <AuthPage mode="register" />;
  }

  if (path === '/reset-password' || path === '/auth/reset-password') {
    return <ResetPasswordPage />;
  }

  // Fallback to Home
  return <HomePage />;
}

export default function App() {
  return (
    <RouterProvider>
      <RecoveryRedirect />
      <ClientLayout>
        <AppRoutes />
      </ClientLayout>
    </RouterProvider>
  );
}

