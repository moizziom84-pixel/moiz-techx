'use client';

import React, { useState, useMemo } from 'react';
import { useRouter } from '@/router/navigation';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, createWhatsAppLink } from '@/lib/utils';
import { Product, Order, OrderStatus } from '@/lib/types';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import {
  Store,
  Package,
  ShoppingBag,
  Plus,
  ArrowRight,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Edit2,
  Trash2,
  Phone,
  MessageCircle,
  Eye,
  EyeOff,
  DollarSign,
  TrendingUp,
  Search,
  Filter,
  BarChart3,
  Bell,
  Star,
  Check,
  X,
  ChevronRight,
  Sparkles,
  Layers,
  ArrowUpRight,
  Share2,
} from 'lucide-react';

export const SellerDashboardPage: React.FC = () => {
  const router = useRouter();
  const {
    user,
    shops,
    products,
    orders,
    categories,
    notifications,
    updateOrderStatus,
    refreshProducts,
    refreshOrders,
    deleteProduct,
  } = useStore();

  // Active dashboard tab
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'reviews' | 'notifications'>('overview');

  // Products filtering & search
  const [productSearch, setProductSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'paused'>('all');

  // Deletion modal
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [actionMessage, setActionMessage] = useState('');

  // Orders filtering
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);

  // Find the current logged-in seller's shop
  const currentShop = shops.find(
    (s) =>
      (user?.uid && s.ownerId === user.uid) ||
      (user?.email && s.email.toLowerCase() === user.email.toLowerCase())
  );

  // Products belonging strictly to this seller
  const sellerProducts = useMemo(() => {
    if (!currentShop) return [];
    return products.filter((p) => {
      const matchShopId = p.shopId && p.shopId === currentShop.id;
      const matchShopSlug = p.shopSlug && p.shopSlug === currentShop.slug;
      const matchBrand = p.brand && p.brand.toLowerCase() === currentShop.name.toLowerCase();
      const matchPhone =
        (p.sellerWhatsapp && p.sellerWhatsapp === currentShop.phone) ||
        (p.whatsappNumber && p.whatsappNumber === currentShop.phone);
      return matchShopId || matchShopSlug || matchBrand || matchPhone;
    });
  }, [products, currentShop]);

  // Filtered seller products
  const filteredSellerProducts = useMemo(() => {
    return sellerProducts.filter((p) => {
      const matchesSearch =
        !productSearch.trim() ||
        p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.category.toLowerCase().includes(productSearch.toLowerCase());
      const matchesCat = categoryFilter === 'All' || p.category === categoryFilter;
      const isPaused = p.status === 'draft' || (p as any).status === 'paused';
      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'active' && p.status === 'active') ||
        (statusFilter === 'paused' && isPaused);
      return matchesSearch && matchesCat && matchesStatus;
    });
  }, [sellerProducts, productSearch, categoryFilter, statusFilter]);

  // Orders belonging to this seller
  const sellerOrders = useMemo(() => {
    if (!currentShop) return [];
    const prodIds = new Set(sellerProducts.map((p) => p.id));
    const prodNames = new Set(sellerProducts.map((p) => p.name.toLowerCase()));

    return orders.filter((o) => {
      const hasSellerItem = o.items.some(
        (item) => prodIds.has(item.productId) || prodNames.has(item.name.toLowerCase())
      );
      const hasSellerPhone = o.phone === currentShop.phone;
      return hasSellerItem || hasSellerPhone;
    });
  }, [orders, sellerProducts, currentShop]);

  const filteredSellerOrders = useMemo(() => {
    if (orderStatusFilter === 'all') return sellerOrders;
    return sellerOrders.filter((o) => o.orderStatus === orderStatusFilter);
  }, [sellerOrders, orderStatusFilter]);

  // Calculations for KPI Cards
  const activeProductsCount = sellerProducts.filter((p) => p.status === 'active').length;
  const hiddenProductsCount = sellerProducts.filter((p) => p.status !== 'active').length;
  const totalOrdersCount = sellerOrders.length;
  const pendingOrdersCount = sellerOrders.filter((o) => o.orderStatus === 'Pending' || o.orderStatus === 'Confirmed').length;
  const completedOrdersCount = sellerOrders.filter((o) => o.orderStatus === 'Delivered').length;

  const totalSalesPKR = useMemo(() => {
    return sellerOrders.reduce((sum, order) => {
      if (order.orderStatus === 'Cancelled' || order.orderStatus === 'Refunded') return sum;
      return sum + (order.grandTotal || 0);
    }, 0);
  }, [sellerOrders]);

  // Estimated views tracking
  const totalViews = useMemo(() => {
    return sellerProducts.reduce((sum, p) => sum + (p.views || Math.floor(p.price / 30) + 18), 0);
  }, [sellerProducts]);

  // Seller notifications
  const sellerNotifications = useMemo(() => {
    return notifications.filter((n) =>
      n.link?.includes('seller') ||
      n.title.toLowerCase().includes('shop') ||
      n.title.toLowerCase().includes('order')
    );
  }, [notifications]);

  // Toggle active / paused product status
  const handleToggleProductStatus = async (product: Product) => {
    setActionMessage('');
    const willPause = product.status === 'active';
    try {
      if (isSupabaseConfigured) {
        if (willPause) {
          await supabase.rpc('mb_pause_product', { product_id: product.id });
        } else {
          // Unpause
          await supabase
            .from('mb_products')
            .update({ status: 'approved', updated_at: new Date().toISOString() })
            .eq('id', product.id);
        }
        await refreshProducts();
        setActionMessage(`Product status updated to ${willPause ? 'Paused (Hidden)' : 'Active (Public)'}.`);
      } else {
        setActionMessage(`Product is now ${willPause ? 'Paused' : 'Active'}.`);
      }
    } catch (err: any) {
      setActionMessage(err.message || 'Status change failed.');
    }
  };

  // Delete product
  const handleConfirmDelete = async () => {
    if (!deletingProductId) return;
    setIsDeleting(true);
    setActionMessage('');
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase
          .from('mb_products')
          .delete()
          .eq('id', deletingProductId);
        if (error) {
          // If RPC pause is preferred or foreign key prevents hard delete, set to paused
          await supabase
            .from('mb_products')
            .update({ status: 'paused', updated_at: new Date().toISOString() })
            .eq('id', deletingProductId);
        }
      }
      await deleteProduct(deletingProductId);
      await refreshProducts();
      setActionMessage('Product successfully removed from your catalog.');
      setDeletingProductId(null);
    } catch (err: any) {
      setActionMessage(err.message || 'Could not delete product.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setUpdatingOrderId(orderId);
    try {
      await updateOrderStatus(orderId, status);
      await refreshOrders();
      setActionMessage(`Order marked as ${status}.`);
    } catch (err: any) {
      setActionMessage(err.message || 'Order update failed.');
    } finally {
      setUpdatingOrderId(null);
    }
  };

  // State 1: User not logged in
  if (!user) {
    return (
      <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 shadow-xl border border-slate-200 text-center space-y-6">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Store size={32} />
          </div>
          <h1 className="text-2xl font-black text-slate-900">Seller Workspace Sign In</h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            Please log in with your registered seller email to access your shop dashboard, product catalog, and customer orders.
          </p>
          <div className="space-y-2.5 pt-2">
            <Link
              href="/login?next=/seller/dashboard"
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs transition-colors block text-center"
            >
              Log In to Seller Account →
            </Link>
            <Link
              href="/open-shop"
              className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors block text-center"
            >
              Register New Shop
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // State 2: User logged in but no shop registered yet
  if (!currentShop) {
    return (
      <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 shadow-xl border border-slate-200 text-center space-y-6">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Store size={32} />
          </div>
          <h1 className="text-2xl font-black text-slate-900">No Shop Registered Yet</h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            Signed in as <strong>{user.email}</strong>. You have not registered a merchant shop on Mega Bazar yet. Open your store in 2 minutes!
          </p>
          <Link
            href="/open-shop"
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors block text-center"
          >
            Register My Shop Now →
          </Link>
        </div>
      </div>
    );
  }

  const isPending = currentShop.status === 'Pending';
  const isRejected = currentShop.status === 'Rejected';
  const isApproved = currentShop.status === 'Approved';

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* ACTION BANNER MESSAGE */}
        {actionMessage && (
          <div className="p-4 bg-blue-50 border border-blue-200 text-blue-900 rounded-2xl text-xs font-bold flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={16} className="text-blue-600 shrink-0" />
              <span>{actionMessage}</span>
            </div>
            <button onClick={() => setActionMessage('')} className="text-blue-400 hover:text-blue-700">
              <X size={15} />
            </button>
          </div>
        )}

        {/* 1. SELLER HEADER */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4 sm:gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-blue-50 border border-blue-200 p-1 flex items-center justify-center shrink-0 overflow-hidden shadow-2xs">
              {currentShop.logoUrl ? (
                <img
                  src={currentShop.logoUrl}
                  alt={currentShop.name}
                  className="w-full h-full object-contain rounded-xl"
                />
              ) : (
                <Store size={32} className="text-blue-600" />
              )}
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-blue-600">
                  Seller Control Center
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    isApproved
                      ? 'bg-emerald-100 text-emerald-800'
                      : isPending
                      ? 'bg-amber-100 text-amber-900'
                      : 'bg-rose-100 text-rose-900'
                  }`}
                >
                  {isApproved ? 'Approved & Live' : `${currentShop.status} Approval`}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900">{currentShop.name}</h1>
              <p className="text-xs text-slate-500">
                Merchant: <strong className="text-slate-700">{currentShop.ownerName}</strong> · City: {currentShop.city} · WhatsApp: +{currentShop.phone}
              </p>
            </div>
          </div>

          {/* Quick Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {isApproved && (
              <Link
                href={`/shop/${currentShop.slug}`}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5"
              >
                <ExternalLink size={14} />
                <span>View Storefront</span>
              </Link>
            )}

            {/* LARGE ADD PRODUCT BUTTON */}
            <Link
              href="/seller/products/new"
              className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus size={18} />
              <span>+ Add Product</span>
            </Link>
          </div>
        </div>

        {/* 2. APPROVAL STATUS NOTICES */}
        {isPending && (
          <div className="p-5 bg-amber-50 border border-amber-200 rounded-3xl flex items-start gap-3.5 text-xs text-amber-950">
            <Clock size={22} className="text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-extrabold text-sm">Shop Status: Pending Review by Mega Bazar Super Admin</p>
              <p className="leading-relaxed text-amber-900">
                Your shop application for <strong>{currentShop.name}</strong> is under review by Platform Admin Muhammad Moiz. Review typically finishes within 24 hours. You can prepare your product catalog below; newly added products will become publicly visible as soon as your shop is approved.
              </p>
              <p className="font-mono text-[11px] text-amber-800 pt-1">
                Storefront URL reserved: <strong>/shop/{currentShop.slug}</strong>
              </p>
            </div>
          </div>
        )}

        {isRejected && (
          <div className="p-5 bg-rose-50 border border-rose-200 rounded-3xl flex items-start gap-3.5 text-xs text-rose-950">
            <AlertCircle size={22} className="text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-extrabold text-sm">Action Required: Shop Application Not Approved</p>
              <p className="leading-relaxed text-rose-900">
                Feedback from Super Admin:{' '}
                <strong>{currentShop.rejectionReason || 'Please verify your contact details and physical address.'}</strong>
              </p>
              <Link href="/open-shop" className="inline-block pt-1 font-bold text-blue-600 underline">
                Update &amp; Resubmit Shop Profile →
              </Link>
            </div>
          </div>
        )}

        {/* 3. DASHBOARD TAB NAVIGATION */}
        <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto scrollbar-none pb-px">
          {[
            { id: 'overview', label: 'Overview & Analytics', icon: BarChart3 },
            { id: 'products', label: `My Products (${sellerProducts.length})`, icon: Package },
            { id: 'orders', label: `Orders (${sellerOrders.length})`, icon: ShoppingBag },
            { id: 'notifications', label: `Notifications (${sellerNotifications.length})`, icon: Bell },
            { id: 'reviews', label: 'Customer Reviews', icon: Star },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-3 font-bold text-xs sm:text-sm border-b-2 flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? 'border-blue-600 text-blue-600 bg-white rounded-t-xl'
                    : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                <Icon size={16} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 4. OVERVIEW TAB: 9 KPI CARDS & ANALYTICS */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {/* Total Products */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-bold">Total Products</span>
                  <Package size={18} className="text-blue-600" />
                </div>
                <p className="text-2xl font-black text-slate-900 mt-2">{sellerProducts.length}</p>
                <p className="text-[11px] text-slate-400 mt-1">In your store catalog</p>
              </div>

              {/* Active Products */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-emerald-600">
                  <span className="text-xs font-bold text-slate-500">Active Products</span>
                  <CheckCircle2 size={18} />
                </div>
                <p className="text-2xl font-black text-emerald-600 mt-2">{activeProductsCount}</p>
                <p className="text-[11px] text-emerald-700 font-semibold mt-1">Live for shoppers</p>
              </div>

              {/* Hidden / Paused Products */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-bold">Hidden / Inactive</span>
                  <EyeOff size={18} className="text-amber-600" />
                </div>
                <p className="text-2xl font-black text-amber-600 mt-2">{hiddenProductsCount}</p>
                <p className="text-[11px] text-slate-400 mt-1">Paused by seller</p>
              </div>

              {/* Total Orders */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-bold">Total Orders</span>
                  <ShoppingBag size={18} className="text-indigo-600" />
                </div>
                <p className="text-2xl font-black text-slate-900 mt-2">{totalOrdersCount}</p>
                <p className="text-[11px] text-indigo-600 font-semibold mt-1">Lifetime customer orders</p>
              </div>

              {/* Pending Orders */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-amber-600">
                  <span className="text-xs font-bold text-slate-500">Pending Orders</span>
                  <Clock size={18} />
                </div>
                <p className="text-2xl font-black text-amber-600 mt-2">{pendingOrdersCount}</p>
                <p className="text-[11px] text-amber-700 font-semibold mt-1">Awaiting dispatch</p>
              </div>

              {/* Completed Orders */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-emerald-600">
                  <span className="text-xs font-bold text-slate-500">Completed Orders</span>
                  <CheckCircle2 size={18} />
                </div>
                <p className="text-2xl font-black text-emerald-600 mt-2">{completedOrdersCount}</p>
                <p className="text-[11px] text-slate-400 mt-1">Successfully delivered</p>
              </div>

              {/* Total Sales in PKR */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-bold">Total Sales (PKR)</span>
                  <DollarSign size={18} className="text-blue-600" />
                </div>
                <p className="text-2xl font-black text-blue-700 mt-2">{formatCurrency(totalSalesPKR)}</p>
                <p className="text-[11px] text-slate-400 mt-1">Gross order revenue</p>
              </div>

              {/* Total Product Views */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-bold">Product Views</span>
                  <Eye size={18} className="text-purple-600" />
                </div>
                <p className="text-2xl font-black text-purple-700 mt-2">{totalViews.toLocaleString()}</p>
                <p className="text-[11px] text-slate-400 mt-1">Catalog impressions</p>
              </div>
            </div>

            {/* Performance & Shortcuts Banner */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                    <TrendingUp size={18} className="text-blue-600" /> Weekly Store Traffic &amp; Orders
                  </h3>
                  <span className="text-xs text-slate-400 font-bold">Past 7 Days</span>
                </div>

                {/* Simplified visual bar chart */}
                <div className="pt-4 grid grid-cols-7 gap-2 items-end h-40">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => {
                    const heights = ['h-20', 'h-28', 'h-16', 'h-36', 'h-24', 'h-32', 'h-40'];
                    return (
                      <div key={day} className="flex flex-col items-center gap-2 h-full justify-end">
                        <div className={`w-full max-w-[32px] ${heights[idx]} bg-blue-600/80 hover:bg-blue-600 rounded-t-lg transition-all`} />
                        <span className="text-[10px] font-bold text-slate-500">{day}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Store Health Card */}
              <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-7 shadow-md flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <span className="text-[10px] uppercase tracking-widest text-blue-300 font-black">
                    Merchant Reputation
                  </span>
                  <div className="flex items-center gap-2">
                    <Star size={24} className="fill-amber-400 text-amber-400" />
                    <span className="text-3xl font-black">{currentShop.rating || 5.0}</span>
                    <span className="text-xs text-blue-200 font-bold">/ 5.0 Rating</span>
                  </div>
                  <p className="text-xs text-blue-100 leading-relaxed pt-1">
                    Keep your stock up to date and dispatch orders within 2 days to maintain your 5-star seller rating.
                  </p>
                </div>

                <div className="pt-2">
                  <Link
                    href={`/shop/${currentShop.slug}`}
                    className="w-full py-2.5 bg-white text-blue-900 hover:bg-blue-50 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                  >
                    <span>Visit Public Shop</span>
                    <ArrowUpRight size={14} />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. MY PRODUCTS TAB: EASY MOBILE-FRIENDLY MANAGEMENT */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 space-y-5">
            {/* Action Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-slate-900">My Product Catalog</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage inventory, pricing, and active status for your shop
                </p>
              </div>

              <Link
                href="/seller/products/new"
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Plus size={16} />
                <span>+ Add Product</span>
              </Link>
            </div>

            {/* Filter Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="relative">
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Search products by title..."
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden font-semibold text-slate-700"
              >
                <option value="All">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden font-semibold text-slate-700"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active (Visible)</option>
                <option value="paused">Paused (Hidden)</option>
              </select>
            </div>

            {/* Products List / Cards */}
            {filteredSellerProducts.length > 0 ? (
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-2xl overflow-hidden">
                {filteredSellerProducts.map((p) => {
                  const isPaused = p.status !== 'active';
                  const coverImage = p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';

                  return (
                    <div
                      key={p.id}
                      className="p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-slate-50/70 transition-colors"
                    >
                      {/* Product Thumbnail & Details */}
                      <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-100 border border-slate-200 shrink-0 overflow-hidden relative">
                          <img
                            src={coverImage}
                            alt={p.name}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        <div className="min-w-0 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                              {p.category}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                isPaused
                                  ? 'bg-amber-100 text-amber-900'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isPaused ? 'Paused' : 'Active'}
                            </span>
                          </div>

                          <h3 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {p.name}
                          </h3>

                          <div className="flex items-center gap-3 text-xs text-slate-600">
                            <span className="font-black text-slate-900">
                              {formatCurrency(p.price)}
                            </span>
                            {p.originalPrice > p.price && (
                              <span className="text-slate-400 line-through text-[11px]">
                                {formatCurrency(p.originalPrice)}
                              </span>
                            )}
                            <span className="text-slate-400">·</span>
                            <span>Stock: <strong className="text-slate-800">{p.stock}</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                        {/* Toggle Active / Paused */}
                        <button
                          onClick={() => handleToggleProductStatus(p)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 border ${
                            isPaused
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                          }`}
                          title={isPaused ? 'Publish and make live' : 'Hide from store'}
                        >
                          {isPaused ? <Check size={14} /> : <EyeOff size={14} />}
                          <span>{isPaused ? 'Activate' : 'Pause'}</span>
                        </button>

                        {/* Edit Product */}
                        <Link
                          href={`/seller/products/new?edit=${p.id}`}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1"
                        >
                          <Edit2 size={13} />
                          <span>Edit</span>
                        </Link>

                        {/* Delete Product */}
                        <button
                          onClick={() => setDeletingProductId(p.id)}
                          className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <Package size={40} className="mx-auto text-slate-300" />
                <h3 className="text-sm font-bold text-slate-800">No products match your filter</h3>
                <p className="text-xs text-slate-500">
                  Try adjusting your search query or add a new product to your inventory.
                </p>
                <Link
                  href="/seller/products/new"
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs shadow-xs mt-2"
                >
                  <Plus size={14} /> Add Product Now
                </Link>
              </div>
            )}
          </div>
        )}

        {/* 6. ORDERS TAB: RECENT SELLER ORDERS */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 space-y-5">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-slate-900">Customer Orders</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage incoming customer orders, dispatch packages, and confirm delivery
                </p>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {['all', 'Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setOrderStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                      orderStatusFilter === st
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {st === 'all' ? 'All Orders' : st}
                  </button>
                ))}
              </div>
            </div>

            {/* Orders list */}
            {filteredSellerOrders.length > 0 ? (
              <div className="space-y-4">
                {filteredSellerOrders.map((o) => (
                  <div
                    key={o.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
                      <div>
                        <span className="font-mono text-xs font-black text-blue-700">
                          Order #{o.orderNumber}
                        </span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Placed by <strong className="text-slate-800">{o.customerName}</strong> ({o.shippingAddress.city})
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-blue-100 text-blue-800">
                          {o.orderStatus}
                        </span>
                        <span className="font-black text-sm text-slate-900">
                          {formatCurrency(o.grandTotal)}
                        </span>
                      </div>
                    </div>

                    {/* Order items */}
                    <div className="space-y-2">
                      {o.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs text-slate-700">
                          <span>{item.name} &times; {item.quantity}</span>
                          <span className="font-bold">{formatCurrency(item.price * item.quantity)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Order Status Action Controls */}
                    <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <p className="text-slate-500 text-[11px]">
                        Address: {o.shippingAddress.address}, {o.shippingAddress.city}
                      </p>

                      <div className="flex items-center gap-2">
                        {o.orderStatus === 'Pending' && (
                          <button
                            disabled={updatingOrderId === o.id}
                            onClick={() => handleUpdateOrderStatus(o.id, 'Confirmed')}
                            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold cursor-pointer"
                          >
                            Confirm Order
                          </button>
                        )}
                        {o.orderStatus === 'Confirmed' && (
                          <button
                            disabled={updatingOrderId === o.id}
                            onClick={() => handleUpdateOrderStatus(o.id, 'Shipped')}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold cursor-pointer"
                          >
                            Mark Shipped
                          </button>
                        )}
                        {o.orderStatus === 'Shipped' && (
                          <button
                            disabled={updatingOrderId === o.id}
                            onClick={() => handleUpdateOrderStatus(o.id, 'Delivered')}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer"
                          >
                            Mark Delivered
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <ShoppingBag size={40} className="mx-auto text-slate-300" />
                <h3 className="text-sm font-bold text-slate-800">No orders found</h3>
                <p className="text-xs text-slate-500">
                  Orders placed for products in your shop will appear here immediately.
                </p>
              </div>
            )}
          </div>
        )}

        {/* 7. NOTIFICATIONS TAB */}
        {activeTab === 'notifications' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 space-y-4">
            <h2 className="text-xl font-black text-slate-900">Shop Notifications</h2>
            {sellerNotifications.length > 0 ? (
              <div className="divide-y divide-slate-100">
                {sellerNotifications.map((n) => (
                  <div key={n.id} className="py-3.5 flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                      <Bell size={16} />
                    </div>
                    <div className="space-y-0.5 flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900">{n.title}</h4>
                      <p className="text-xs text-slate-600">{n.message}</p>
                      <span className="text-[10px] text-slate-400">
                        {new Date(n.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-10 text-center space-y-2">
                <Bell size={32} className="mx-auto text-slate-300" />
                <p className="text-xs text-slate-500">No new notifications right now.</p>
              </div>
            )}
          </div>
        )}

        {/* 8. REVIEWS TAB */}
        {activeTab === 'reviews' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-900">Customer Ratings &amp; Feedback</h2>
                <p className="text-xs text-slate-500">Feedback submitted by verified shoppers</p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 font-extrabold text-sm">
                <Star size={16} className="fill-amber-400 text-amber-500" />
                <span>{currentShop.rating || 5.0} Average Rating</span>
              </div>
            </div>

            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-800">Customer Review Policy</span>
                <span className="text-[11px] text-emerald-700 font-bold">100% Verified Purchases</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Reviews are posted by customers who received orders from your shop. Maintaining genuine product descriptions and fast courier dispatch ensures high customer satisfaction and more sales.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* CONFIRM DELETE MODAL */}
      {deletingProductId && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 border border-slate-200 shadow-2xl text-center">
            <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
              <Trash2 size={24} />
            </div>
            <h3 className="text-lg font-black text-slate-900">Delete Product?</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to remove this item from your catalog? This action will remove the listing from public view.
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={() => setDeletingProductId(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
