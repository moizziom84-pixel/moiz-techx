'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { demoShops } from '@/lib/demo-shops';
import {
  Store,
  ArrowRight,
  MapPin,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Star,
  ExternalLink,
} from 'lucide-react';

export const DemoShopsPage: React.FC = () => {
  const { shops } = useStore();
  const [selectedCity, setSelectedCity] = useState<string>('all');

  // Real approved shops from Supabase database
  const approvedShops = useMemo(() => {
    return shops.filter((s) => s.status === 'Approved');
  }, [shops]);

  // Combine real database shops and demo shops
  const allShops = useMemo(() => {
    const list: Array<{
      id: string;
      name: string;
      slug: string;
      category: string;
      city: string;
      description?: string;
      logoUrl?: string;
      bannerUrl?: string;
      isLive: boolean;
      rating: number;
    }> = [];

    // Real shops first
    approvedShops.forEach((s) => {
      list.push({
        id: s.id,
        name: s.name,
        slug: s.slug,
        category: s.category || 'Multi-Vendor Retail',
        city: s.city || 'Karachi',
        description: s.description || 'Verified merchant storefront on Mega Bazar Pakistan.',
        logoUrl: s.logoUrl,
        bannerUrl: s.bannerUrl,
        isLive: true,
        rating: s.rating || 5.0,
      });
    });

    // Demo shops
    demoShops.forEach((d) => {
      if (!list.some((existing) => existing.slug === d.slug)) {
        list.push({
          id: d.slug,
          name: d.name,
          slug: d.slug,
          category: d.category,
          city: d.city,
          description: d.description,
          logoUrl: undefined,
          bannerUrl: d.image,
          isLive: false,
          rating: 4.9,
        });
      }
    });

    return list;
  }, [approvedShops]);

  const filteredShops = useMemo(() => {
    if (selectedCity === 'all') return allShops;
    return allShops.filter((s) => s.city.toLowerCase() === selectedCity.toLowerCase());
  }, [allShops, selectedCity]);

  // Available unique cities
  const uniqueCities = useMemo(() => {
    const set = new Set<string>();
    allShops.forEach((s) => {
      if (s.city) set.add(s.city);
    });
    return Array.from(set);
  }, [allShops]);

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex flex-wrap justify-between items-end gap-4 pb-6 border-b border-slate-200">
          <div>
            <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
              <Link href="/" className="hover:text-blue-600">Home</Link>
              <span>/</span>
              <span className="text-slate-900 font-bold">Independent Shops</span>
            </nav>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-wider">
                COMMUNITY MARKETPLACE
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
              Verified Seller Storefronts
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
              Explore independent Pakistani brands with direct seller WhatsApp communication, verified local inventory and specialized collections.
            </p>
          </div>

          <Link
            href="/open-shop"
            className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-md shadow-blue-500/20 transition-colors"
          >
            <Store size={16} /> Open Your Shop on Mega Bazar
          </Link>
        </div>

        {/* City Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedCity('all')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              selectedCity === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            All Cities ({allShops.length})
          </button>
          {uniqueCities.map((city) => (
            <button
              key={city}
              onClick={() => setSelectedCity(city)}
              className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 cursor-pointer ${
                selectedCity === city
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <MapPin size={12} /> {city}
            </button>
          ))}
        </div>

        {/* Shops Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredShops.map((s) => (
            <div
              key={s.slug}
              className="group rounded-3xl border border-slate-200 bg-white overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Banner & Cover */}
                <div className="relative aspect-[16/9] bg-gradient-to-br from-blue-900 to-indigo-950 overflow-hidden">
                  {s.bannerUrl ? (
                    <img
                      src={s.bannerUrl}
                      alt={`${s.name} collection`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white/50">
                      <Store size={40} />
                    </div>
                  )}

                  {s.isLive && (
                    <span className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                      <CheckCircle2 size={12} /> Live Verified Store
                    </span>
                  )}
                </div>

                {/* Identity & Body */}
                <div className="p-6 space-y-4">
                  <div className="flex items-start justify-between gap-3 -mt-10 relative z-10">
                    <div className="w-16 h-16 rounded-2xl bg-white border-2 border-slate-200 shadow-md p-1 flex items-center justify-center shrink-0 overflow-hidden">
                      {s.logoUrl ? (
                        <img
                          src={s.logoUrl}
                          alt={s.name}
                          className="w-full h-full object-contain rounded-xl"
                        />
                      ) : (
                        <Store size={28} className="text-blue-600" />
                      )}
                    </div>
                    <span className="font-mono text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                      /shop/{s.slug}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-lg font-black text-slate-900 group-hover:text-blue-600 transition-colors">
                        {s.name}
                      </h3>
                      <CheckCircle2 size={15} className="text-blue-600 fill-blue-600 text-white shrink-0" />
                    </div>
                    <p className="text-xs text-blue-600 font-semibold">{s.category}</p>
                    <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin size={12} /> {s.city}
                    </p>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {s.description}
                  </p>
                </div>
              </div>

              {/* Action Footer */}
              <div className="p-6 pt-0 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <Star size={14} className="fill-amber-400 text-amber-500" />
                  {s.rating} Rating
                </span>

                <Link
                  href={`/shop/${s.slug}`}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <span>Visit Storefront</span>
                  <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
