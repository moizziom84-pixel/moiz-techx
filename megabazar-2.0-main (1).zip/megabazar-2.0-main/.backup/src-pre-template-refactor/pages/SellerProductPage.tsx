'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from '@/router/navigation';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { uploadShopImage } from '@/lib/marketplace/upload';
import { validateProduct } from '@/lib/marketplace/validation';
import { formatCurrency, formatPakistaniWhatsAppNumber } from '@/lib/utils';
import { useStore } from '@/context/StoreContext';
import {
  Package,
  ArrowLeft,
  Camera,
  Upload,
  CheckCircle2,
  AlertCircle,
  X,
  Trash2,
  Sparkles,
  Store,
  DollarSign,
  HelpCircle,
  Eye,
  Info,
  Check,
  Loader2,
  MessageCircle,
} from 'lucide-react';

export function SellerProductPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editId = searchParams.get('edit');

  const { categories, user, shops, refreshProducts } = useStore();

  const currentShop = shops.find(
    (s) =>
      (user?.uid && s.ownerId === user.uid) ||
      (user?.email && s.email.toLowerCase() === user.email.toLowerCase())
  );

  // Form fields
  const [name, setName] = useState('');
  const [category, setCategory] = useState(categories[0]?.name || 'Fashion & Apparel');
  const [condition, setCondition] = useState<'new' | 'used' | 'refurbished'>('new');
  const [price, setPrice] = useState('');
  const [salePrice, setSalePrice] = useState('');
  const [stock, setStock] = useState('10');
  const [dispatch, setDispatch] = useState('2');
  const [contents, setContents] = useState('1 item with standard protective packaging');
  const [description, setDescription] = useState('');
  const [enableWhatsapp, setEnableWhatsapp] = useState(true);
  const [whatsappNumber, setWhatsappNumber] = useState(currentShop?.phone || '03001234567');

  // Images state
  const [existingImagePaths, setExistingImagePaths] = useState<string[]>([]);
  const [newFiles, setNewFiles] = useState<File[]>([]);
  const [newFilePreviews, setNewFilePreviews] = useState<string[]>([]);

  // Submission & progress state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successProduct, setSuccessProduct] = useState<any>(null);

  // Auto-fill whatsapp from current shop
  useEffect(() => {
    if (currentShop?.phone) {
      setWhatsappNumber(currentShop.phone);
    }
  }, [currentShop]);

  // Load existing product if editing
  useEffect(() => {
    if (!editId) return;
    let active = true;

    async function loadProduct() {
      try {
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (!currentUser) throw new Error('Please sign in to edit your listing.');

        const { data, error } = await supabase
          .from('mb_products')
          .select('*')
          .eq('id', editId)
          .eq('owner_id', currentUser.id)
          .single();

        if (error || !data) throw new Error(error?.message || 'Product not found.');

        if (active) {
          const d = data.details || {};
          setName(d.name || '');
          setCategory(d.category || 'General');
          setCondition(d.condition || 'new');
          setPrice(String(d.price || ''));
          setSalePrice(String(d.salePrice || ''));
          setStock(String(d.stock ?? '10'));
          setDispatch(String(d.dispatch ?? '2'));
          setContents(d.contents || '1 item as described');
          setDescription(d.description || '');
          setEnableWhatsapp(d.enableWhatsapp === 'true' || d.enableWhatsapp === true);
          if (d.whatsapp) setWhatsappNumber(d.whatsapp);
          setExistingImagePaths(data.images || []);
        }
      } catch (err: any) {
        if (active) setErrorMessage(err.message || 'Could not load product details.');
      }
    }

    loadProduct();
    return () => {
      active = false;
    };
  }, [editId]);

  // Calculate discount percentage
  const numPrice = Number(price);
  const numSale = Number(salePrice);
  const discountPct =
    numPrice > 0 && numSale > 0 && numSale < numPrice
      ? Math.round(((numPrice - numSale) / numPrice) * 100)
      : 0;

  // Handle image files selection
  const handleSelectFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []);
    if (!selected.length) return;

    const totalAllowed = 8 - existingImagePaths.length;
    if (selected.length + newFiles.length > totalAllowed) {
      setErrorMessage(`You can upload a maximum of 8 pictures total. (${totalAllowed} slots remaining)`);
      return;
    }

    setErrorMessage('');
    const updatedFiles = [...newFiles, ...selected];
    setNewFiles(updatedFiles);

    // Create object URLs for previews
    const previews = selected.map((file) => URL.createObjectURL(file));
    setNewFilePreviews((prev) => [...prev, ...previews]);
  };

  const handleRemoveExistingPath = (pathToRemove: string) => {
    setExistingImagePaths((prev) => prev.filter((p) => p !== pathToRemove));
  };

  const handleRemoveNewFile = (index: number) => {
    setNewFiles((prev) => prev.filter((_, i) => i !== index));
    setNewFilePreviews((prev) => {
      URL.revokeObjectURL(prev[index]);
      return prev.filter((_, i) => i !== index);
    });
  };

  const getMediaUrl = (path: string) => {
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    return supabase.storage.from('mb-product-images').getPublicUrl(path).data.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessProduct(null);

    const totalImagesCount = existingImagePaths.length + newFiles.length;
    if (totalImagesCount < 3 || totalImagesCount > 8) {
      setErrorMessage('Please select between 3 and 8 clear product pictures (front, back, details).');
      return;
    }

    // Prepare payload for validation
    const payload: Record<string, any> = {
      name: name.trim(),
      category: category.trim(),
      condition,
      price: price.trim(),
      salePrice: salePrice.trim(),
      stock: stock.trim(),
      dispatch: dispatch.trim(),
      contents: contents.trim(),
      description: description.trim(),
      enableWhatsapp: String(enableWhatsapp),
      whatsappConsent: String(enableWhatsapp),
      whatsapp: enableWhatsapp ? whatsappNumber.trim() : undefined,
    };

    const validationError = validateProduct(payload);
    if (validationError) {
      setErrorMessage(validationError);
      return;
    }

    setIsSubmitting(true);
    setUploadProgress('Checking shop authorization...');

    try {
      if (!isSupabaseConfigured) {
        throw new Error('Database is not connected. Please check configuration.');
      }

      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) throw new Error('Please sign in to your seller account first.');

      // Check shop approval
      const shopRes = await supabase
        .from('mb_shops')
        .select('id, status, name, slug')
        .eq('owner_id', currentUser.id)
        .maybeSingle();

      if (shopRes.error) throw shopRes.error;
      if (!shopRes.data) throw new Error('You do not have a registered shop yet. Please open a shop first.');
      if (shopRes.data.status !== 'approved' && shopRes.data.status !== 'Approved') {
        throw new Error(
          `Your shop is currently in "${shopRes.data.status}" status. Only approved shops can publish products.`
        );
      }

      // Upload new images with progress
      const finalImagePaths: string[] = [...existingImagePaths];
      for (let i = 0; i < newFiles.length; i++) {
        const file = newFiles[i];
        setUploadProgress(`Optimizing & uploading picture ${i + 1} of ${newFiles.length}...`);
        const path = await uploadShopImage(file);
        finalImagePaths.push(path);
      }

      setUploadProgress('Saving product to database and publishing to storefront...');

      // Save via RPC
      const { data, error } = await supabase.rpc('mb_save_product', {
        details: payload,
        image_paths: finalImagePaths,
        product_id: editId || null,
      });

      if (error) throw error;
      if (!data?.id) throw new Error('Database did not return a confirmed product ID.');

      // Also ensure catalog table is kept in sync if needed
      await refreshProducts();

      setSuccessProduct({
        id: data.id,
        name: payload.name,
        shopSlug: shopRes.data.slug,
      });

      setNewFiles([]);
      setNewFilePreviews([]);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save product. Please try again.');
    } finally {
      setIsSubmitting(false);
      setUploadProgress('');
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-8 sm:py-12 pb-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Back Link & Header */}
        <div className="flex items-center justify-between gap-4">
          <Link
            href="/seller/dashboard"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-2xs transition-colors"
          >
            <ArrowLeft size={14} /> Back to Seller Dashboard
          </Link>

          {currentShop && (
            <span className="text-xs font-bold text-slate-500">
              Publishing as: <strong className="text-slate-900">{currentShop.name}</strong>
            </span>
          )}
        </div>

        {/* Success Card */}
        {successProduct ? (
          <div className="bg-white rounded-3xl p-8 border border-emerald-200 shadow-lg text-center space-y-5 animate-scale">
            <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 size={36} />
            </div>

            <div className="space-y-1">
              <h1 className="text-2xl font-black text-slate-900">
                {editId ? 'Product Updated Successfully!' : 'Product Published & Live!'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                <strong>{successProduct.name}</strong> is now saved in the database and visible to shoppers across Pakistan on your storefront.
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <Link
                href={`/product/${successProduct.id}`}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
              >
                View Live Product Page →
              </Link>
              <Link
                href="/seller/dashboard"
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors"
              >
                Return to Dashboard
              </Link>
              <button
                type="button"
                onClick={() => {
                  setSuccessProduct(null);
                  setName('');
                  setDescription('');
                  setPrice('');
                  setSalePrice('');
                  setExistingImagePaths([]);
                }}
                className="px-5 py-2.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 font-bold text-xs rounded-xl transition-colors"
              >
                + Add Another Product
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-6 sm:p-9 border border-slate-200 shadow-xs space-y-7">
            {/* Title */}
            <div className="border-b border-slate-100 pb-5">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
                  <Package size={20} />
                </span>
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                    {editId ? 'Edit Product Listing' : 'Add New Product'}
                  </h1>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Once saved, approved shop products become publicly visible across Pakistan immediately.
                  </p>
                </div>
              </div>
            </div>

            {/* Error Message Banner */}
            {errorMessage && (
              <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl text-xs font-bold flex items-start gap-3 shadow-xs">
                <AlertCircle size={18} className="text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1">
                  <p className="font-extrabold">Could not save product</p>
                  <p className="font-normal text-rose-700">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 1. PRODUCT TITLE & CATEGORY */}
              <div className="space-y-4">
                <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider text-[11px] text-blue-700">
                  1. Basic Information
                </h3>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    Product Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    minLength={2}
                    maxLength={180}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Wireless Noise-Cancelling Bluetooth Earbuds with Charging Case"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-blue-500 outline-hidden font-medium text-slate-900"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Clear, descriptive titles attract more customers ({name.length}/180 chars).
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Category <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-blue-500 outline-hidden font-bold text-slate-800"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Condition <span className="text-rose-500">*</span>
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'new', label: 'Brand New' },
                        { id: 'used', label: 'Like New / Used' },
                        { id: 'refurbished', label: 'Refurbished' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setCondition(item.id as any)}
                          className={`py-2.5 px-2 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                            condition === item.id
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. PRICING & INVENTORY */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider text-[11px] text-blue-700">
                  2. Pricing &amp; Stock
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Regular Price */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Regular Price (PKR) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                        Rs.
                      </span>
                      <input
                        type="number"
                        required
                        min="1"
                        step="1"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        placeholder="2500"
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-black focus:bg-white focus:border-blue-500 outline-hidden text-slate-900"
                      />
                    </div>
                  </div>

                  {/* Discount / Sale Price */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-800">
                        Discount / Sale Price (PKR)
                      </label>
                      {discountPct > 0 && (
                        <span className="text-[10px] font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                          -{discountPct}% OFF
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                        Rs.
                      </span>
                      <input
                        type="number"
                        min="1"
                        step="1"
                        value={salePrice}
                        onChange={(e) => setSalePrice(e.target.value)}
                        placeholder="Optional sale price"
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-black focus:bg-white focus:border-blue-500 outline-hidden text-slate-900"
                      />
                    </div>
                  </div>

                  {/* Stock Quantity */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Stock Quantity <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      min="0"
                      max="10000"
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      placeholder="10"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:bg-white focus:border-blue-500 outline-hidden text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Order Preparation Time (Days) <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={dispatch}
                      onChange={(e) => setDispatch(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-blue-500 outline-hidden font-bold text-slate-800"
                    >
                      <option value="1">1 Day (Same / Next day dispatch)</option>
                      <option value="2">2 Days (Standard)</option>
                      <option value="3">3 Days</option>
                      <option value="5">5 Days</option>
                      <option value="7">7 Days (Made to order)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      Package Contents / Inclusions <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={contents}
                      onChange={(e) => setContents(e.target.value)}
                      placeholder="e.g. 1 x Pair of Earbuds, 1 x USB-C Cable, User Manual"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-blue-500 outline-hidden font-medium text-slate-900"
                    />
                  </div>
                </div>
              </div>

              {/* 3. PRODUCT IMAGES (3 - 8 REQUIRED) */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div>
                    <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider text-[11px] text-blue-700">
                      3. Product Images (3 to 8 required) <span className="text-rose-500">*</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      Upload clear photos showing the product from different angles.
                    </p>
                  </div>
                  <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                    {existingImagePaths.length + newFiles.length} of 8 uploaded
                  </span>
                </div>

                {/* Upload Zone */}
                <div className="border-2 border-dashed border-slate-200 hover:border-blue-400 bg-slate-50/60 rounded-3xl p-6 text-center transition-colors">
                  <input
                    type="file"
                    id="product-images-input"
                    multiple
                    accept="image/png,image/jpeg,image/webp"
                    onChange={handleSelectFiles}
                    className="hidden"
                  />
                  <label
                    htmlFor="product-images-input"
                    className="cursor-pointer flex flex-col items-center justify-center space-y-2"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-slate-200 flex items-center justify-center text-blue-600">
                      <Camera size={22} />
                    </div>
                    <p className="text-xs sm:text-sm font-bold text-slate-800">
                      Tap to select images from your device or gallery
                    </p>
                    <p className="text-[11px] text-slate-400">
                      JPG, PNG, or WebP up to 5 MB each. Automatic WebP optimization.
                    </p>
                  </label>
                </div>

                {/* Image Previews Gallery */}
                {(existingImagePaths.length > 0 || newFilePreviews.length > 0) && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
                    {/* Existing Images from DB */}
                    {existingImagePaths.map((path) => (
                      <div
                        key={path}
                        className="relative aspect-square rounded-2xl bg-white border-2 border-slate-200 overflow-hidden group shadow-2xs"
                      >
                        <img
                          src={getMediaUrl(path)}
                          alt="Product"
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveExistingPath(path)}
                          className="absolute top-1.5 right-1.5 p-1 bg-black/70 hover:bg-rose-600 text-white rounded-lg transition-colors cursor-pointer"
                          title="Remove image"
                        >
                          <X size={13} />
                        </button>
                      </div>
                    ))}

                    {/* Newly Selected Images */}
                    {newFilePreviews.map((previewUrl, index) => (
                      <div
                        key={previewUrl}
                        className="relative aspect-square rounded-2xl bg-white border-2 border-blue-400 overflow-hidden group shadow-xs"
                      >
                        <img
                          src={previewUrl}
                          alt="New preview"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-1.5 left-1.5 bg-blue-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs">
                          New
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveNewFile(index)}
                          className="absolute top-1.5 right-1.5 p-1 bg-black/70 hover:bg-rose-600 text-white rounded-lg transition-colors cursor-pointer"
                          title="Remove image"
                        >
                          <X size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 4. DESCRIPTION & WHATSAPP SETTINGS */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider text-[11px] text-blue-700">
                  4. Description &amp; Customer Inquiries
                </h3>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      Product Description <span className="text-rose-500">*</span>
                    </label>
                    <span className="text-[11px] text-slate-400">
                      {description.length}/5000 characters (min. 20)
                    </span>
                  </div>
                  <textarea
                    required
                    minLength={20}
                    maxLength={5000}
                    rows={6}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Provide full details: materials, dimensions, features, instructions, warranty, and why customers will love this product..."
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-blue-500 outline-hidden text-slate-900 leading-relaxed font-normal"
                  />
                </div>

                {/* WhatsApp Chat Toggle */}
                <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <MessageCircle size={18} className="text-emerald-600 fill-emerald-600 text-white" />
                      <span className="text-xs font-bold text-emerald-950">
                        Enable Direct WhatsApp Inquiries for this Product
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={enableWhatsapp}
                        onChange={(e) => setEnableWhatsapp(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>

                  {enableWhatsapp && (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        Seller WhatsApp Number (Pakistan Format: 03XXXXXXXXX)
                      </label>
                      <input
                        type="tel"
                        value={whatsappNumber}
                        onChange={(e) => setWhatsappNumber(e.target.value)}
                        placeholder="03001234567"
                        className="w-full px-3.5 py-2.5 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-slate-800 focus:border-emerald-500 outline-hidden"
                      />
                      <p className="text-[10px] text-emerald-800 mt-1">
                        Shoppers on your product page can click to chat with you directly regarding questions.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* SUBMIT BUTTON & PROGRESS */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <Link
                  href="/seller/dashboard"
                  className="px-5 py-3 text-slate-600 hover:text-slate-900 text-xs font-bold transition-colors"
                >
                  Cancel
                </Link>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {isSubmitting && uploadProgress && (
                    <span className="text-xs font-bold text-blue-600 flex items-center gap-1.5 animate-pulse">
                      <Loader2 size={14} className="animate-spin" />
                      {uploadProgress}
                    </span>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto px-7 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-xs sm:text-sm shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        <span>Saving &amp; Publishing...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={16} />
                        <span>{editId ? 'Save Changes' : 'Publish Product to Store'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
