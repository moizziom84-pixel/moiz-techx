import { useEffect,useState } from 'react';
import { usePathname } from '@/router/navigation';
import { supabase } from '@/lib/supabase/client';
import { ChatButton } from '@/components/ChatButton';
export function ListingPage(){
 const path=usePathname(),id=path.split('/')[2];const [item,setItem]=useState<any>(null),[error,setError]=useState('Loading product…');
 useEffect(()=>{let active=true;supabase.from('mb_public_products').select('*').eq('id',id).maybeSingle().then(r=>{if(active){if(r.error||!r.data)setError(r.error?.message||'Product not found.');else{setItem(r.data);setError('');}}});return()=>{active=false;};},[id]);
 return <section className="max-w-5xl mx-auto p-5 space-y-5"><p role="status">{error}</p>{item&&<><h1 className="text-3xl font-bold">{item.details.name}</h1><p>{item.shop_name}</p><div className="flex gap-3 overflow-auto">{item.images.map((p:string)=><img key={p} src={supabase.storage.from('mb-product-images').getPublicUrl(p).data.publicUrl} alt={item.details.name} className="w-64 h-64 object-contain bg-white rounded-xl"/>)}</div><p className="text-xl font-bold">PKR {item.details.salePrice||item.details.price}</p><p className="whitespace-pre-wrap">{item.details.description}</p><ChatButton shopId={item.shop_id}/></>}</section>;
}

