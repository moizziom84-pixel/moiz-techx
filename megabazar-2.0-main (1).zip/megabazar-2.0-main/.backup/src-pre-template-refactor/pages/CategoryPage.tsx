import React from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { ProductCard } from '@/components/ProductCard';
import { ArrowLeft, Sparkles, Package } from 'lucide-react';
import { useParams } from '@/router/navigation';

export const CategoryPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { categories, products } = useStore();

  const currentSlug = slug || 'fashion';
  const category = categories.find((c) => c.slug.toLowerCase() === currentSlug.toLowerCase()) || {
    id: currentSlug,
    name: currentSlug.charAt(0).toUpperCase() + currentSlug.slice(1).replace(/-/g, ' '),
    description: `Browse authentic ${currentSlug.replace(/-/g, ' ')} items with fast nationwide delivery across Pakistan.`,
    image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=1200&q=80',
    count: 1000,
  };

  const categoryProducts = products.filter(
    (p) =>
      p.status === 'active' &&
      (p.category.toLowerCase() === category.name.toLowerCase() ||
        p.category.toLowerCase().replace(/\s+/g, '-') === currentSlug.toLowerCase() ||
        p.category.toLowerCase().includes(currentSlug.toLowerCase()))
  );

  return (
    <div className="py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <Link href="/" className="hover:text-blue-600 transition-colors">Home</Link>
          <span>/</span>
          <Link href="/categories" className="hover:text-blue-600 transition-colors">Categories</Link>
          <span>/</span>
          <span className="text-slate-900 font-bold">{category.name}</span>
        </nav>

        {/* Category Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white min-h-[160px] sm:min-h-[200px] flex items-center p-6 sm:p-10 shadow-md">
          <img
            src={category.image}
            alt={category.name}
            className="absolute inset-0 w-full h-full object-cover opacity-35"
          />
          <div className="relative z-10 max-w-xl space-y-2">
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-600 text-white text-[10px] font-black uppercase tracking-wider rounded-full">
              <Sparkles className="w-3 h-3" /> Mega Bazar Collection
            </span>
            <h1 className="text-3xl sm:text-4xl font-black">{category.name}</h1>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {category.description}
            </p>
          </div>
        </div>

        {/* Products Grid */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              Products in {category.name} ({categoryProducts.length})
            </h2>
            <Link href="/products" className="text-xs font-bold text-blue-600 hover:text-blue-700">
              Browse All Products →
            </Link>
          </div>

          {categoryProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
              <Package size={48} className="mx-auto text-slate-300 mb-3" />
              <h3 className="text-base font-bold text-slate-800">No active products found in this category</h3>
              <p className="text-xs text-slate-500 mt-1">Check back soon or explore our other exciting departments!</p>
              <Link href="/products" className="mt-4 inline-block px-5 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold">
                View All Products
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
              {categoryProducts.map((p, i) => (
                <ProductCard key={p.id} product={p} priority={i < 4} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
