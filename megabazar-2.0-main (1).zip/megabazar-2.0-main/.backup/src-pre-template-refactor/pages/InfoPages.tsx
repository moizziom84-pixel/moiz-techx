import React, { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { createWhatsAppLink } from '@/lib/whatsapp';
import {
  Mail,
  Phone,
  MapPin,
  MessageCircle,
  ShieldCheck,
  HelpCircle,
  CheckCircle,
  Store,
  Send,
  Eye,
  EyeOff,
  Lock,
  KeyRound,
  X,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { marketplaceEnabled } from '@/lib/marketplace/browser';

export const AboutPage: React.FC = () => {
  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-black uppercase tracking-wider rounded-full">
            ABOUT MEGA BAZAR
          </span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Pakistan's Trusted Online Marketplace</h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Mega Bazar is an e-commerce platform built to connect Pakistani buyers and independent merchants. We provide access to high-quality fashion, latest electronics, lifestyle essentials, and specialty goods with nationwide courier fulfillment and Cash on Delivery (COD).
          </p>
          <div className="grid sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-center">
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-blue-600">100%</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Authentic Products</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-emerald-600">Nationwide</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Cash on Delivery</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-amber-600">7 Days</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Easy Return Guarantee</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  const { settings } = useStore();
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');
  const [sent, setSent] = useState(false);

  const waLink = createWhatsAppLink(settings.whatsappNumber || '923182204441', 'Hello! I would like to contact the Mega Bazar Help Desk.');

  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Contact & Support Desk</h1>
          <p className="text-xs sm:text-sm text-slate-500">We are here to assist you with orders, returns, and seller onboarding.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 items-start">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <h2 className="text-lg font-black text-slate-900">Direct Contact Information</h2>
            <div className="space-y-4 text-xs">
              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Phone size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">WhatsApp / Helpline</p>
                  <p className="text-slate-500">+92 318 2204441</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Mail size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">Official Email</p>
                  <p className="text-slate-500">{settings.contactEmail || 'moizziom84@gmail.com'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">Headquarters</p>
                  <p className="text-slate-500">Mega Bazar E-Commerce, Karachi, Pakistan</p>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
              >
                <MessageCircle size={17} className="fill-current" /> Open Instant WhatsApp Chat
              </a>
            </div>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {const {data:{user}}=await supabase.auth.getUser();if(!user)throw new Error('Sign in before sending a support message.');const {error}=await supabase.from('mb_support_messages').insert({sender_id:user.id,name:name.trim(),body:msg.trim()});if(error)throw error;setSent(true);}catch(error){alert(error instanceof Error?error.message:'Message was not saved.');}
            }}
            className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4 text-xs"
          >
            <h2 className="text-lg font-black text-slate-900">Send an Inquiry</h2>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Your Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Muhammad Ali"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Message</label>
              <textarea
                required
                rows={3}
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                placeholder="How can we help you?"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            {sent ? (
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl font-bold flex items-center gap-2">
                <CheckCircle size={16} /> Thank you! Your message has been sent to support.
              </div>
            ) : (
              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Send size={14} /> Send Message
              </button>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export const PrivacyTermsPage: React.FC<{ type: 'privacy' | 'terms' }> = ({ type }) => {
  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6 bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-xs">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
          {type === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions of Service'}
        </h1>
        <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <p>
            Welcome to Mega Bazar Pakistan. We respect customer privacy and are dedicated to safeguarding all personal information collected during order fulfillment, merchant registration, and delivery tracking.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">1. Data Collection & Use</h2>
          <p>
            Customer names, contact numbers, and delivery addresses are utilized strictly for order verification, dispatch through verified courier services, and customer communication via WhatsApp.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">2. Returns & Refunds</h2>
          <p>
            Customers have up to 7 days from the receipt date to initiate an exchange or return for damaged or incorrect goods.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">3. Seller Responsibilities</h2>
          <p>
            Independent merchants on Mega Bazar guarantee genuine products, clear pricing in PKR, and timely order preparation.
          </p>
        </div>
      </div>
    </div>
  );
};

export { AuthPage, ResetPasswordPage } from '@/components/AccountAuth';

