'use client';

import React, { useState } from 'react';
import Link from '@/router/link';
import { useRouter } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { CategoryShortcuts } from '@/components/CategoryShortcuts';
import { ProductCard } from '@/components/ProductCard';
import { InstallAppButton } from '@/components/InstallAppButton';
import { formatCurrency } from '@/lib/utils';
import {
  ArrowRight,
  Store,
  ShoppingBag,
  ShieldCheck,
  Search,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  MapPin,
  Star,
  Package,
  ExternalLink,
  Smartphone,
  Truck,
  RotateCcw,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const router = useRouter();
  const { products, shops } = useStore();
  const [heroSearch, setHeroSearch] = useState('');

  // Active products
  const activeProducts = products.filter((p) => p.status === 'active');
  const featuredProducts = activeProducts.filter((p) => p.isFeatured || p.isFlashDeal || p.discountPercentage > 0).slice(0, 8);
  const latestProducts = activeProducts.slice(0, 8);

  // Approved shops
  const approvedShops = shops.filter((s) => s.status === 'Approved');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!heroSearch.trim()) return;
    router.push(`/search?q=${encodeURIComponent(heroSearch.trim())}`);
  };

  return (
    <main className="pb-20 space-y-10 sm:space-y-12 bg-white">
      {/* 1. CLEAN HERO BANNER WITH SEARCH BAR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 sm:pt-6">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 text-white p-7 sm:p-12 shadow-xl">
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none opacity-40" />
          
          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-700/60 border border-blue-400/30 text-blue-200 text-xs font-bold">
              <Sparkles size={14} className="text-amber-300" />
              <span>Pakistan&apos;s Multi-Vendor Marketplace</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black leading-tight tracking-tight text-white">
              Shop Quality. <br />
              <span className="text-blue-200">Support Local Sellers.</span>
            </h1>

            <p className="text-sm sm:text-base text-blue-100/90 leading-relaxed max-w-xl">
              Discover verified shops from Karachi, Lahore, Islamabad and across Pakistan. Enjoy Cash on Delivery and direct seller inquiries.
            </p>

            {/* In-Hero Search Bar */}
            <form onSubmit={handleSearchSubmit} className="pt-2 flex items-center max-w-lg relative">
              <div className="relative w-full">
                <input
                  type="text"
                  value={heroSearch}
                  onChange={(e) => setHeroSearch(e.target.value)}
                  placeholder="Search for clothes, gadgets, shoes, cosmetics..."
                  className="w-full pl-11 pr-28 py-3.5 bg-white text-slate-900 rounded-2xl text-xs sm:text-sm font-medium focus:ring-4 focus:ring-blue-400/30 outline-hidden shadow-lg placeholder:text-slate-400"
                />
                <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <Link
                href="/products"
                className="inline-flex items-center gap-2 rounded-xl bg-white text-blue-900 px-5 py-3 font-bold text-xs sm:text-sm hover:bg-blue-50 transition-colors shadow-xs"
              >
                <span>Browse Products</span>
                <ArrowRight size={15} />
              </Link>
              <Link
                href="/open-shop"
                className="inline-flex items-center gap-2 rounded-xl bg-blue-800/80 hover:bg-blue-700 border border-blue-400/40 text-white px-5 py-3 font-bold text-xs sm:text-sm transition-colors"
              >
                <Store size={16} />
                <span>Open Your Shop</span>
              </Link>
              <InstallAppButton />
            </div>
          </div>
        </div>
      </section>

      {/* 2. CATEGORY SHORTCUTS */}
      <CategoryShortcuts />

      {/* 3. VALUE PROPOSITIONS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/50 border border-blue-100/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Truck size={18} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Nationwide Delivery</h4>
              <p className="text-[11px] text-slate-500">Fast dispatch to your doorstep</p>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/50 border border-blue-100/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <ShieldCheck size={18} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Cash on Delivery</h4>
              <p className="text-[11px] text-slate-500">Pay when you receive your order</p>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/50 border border-blue-100/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Store size={18} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Verified Sellers</h4>
              <p className="text-[11px] text-slate-500">Quality-checked shop merchants</p>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/50 border border-blue-100/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
              <RotateCcw size={18} />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Easy Returns</h4>
              <p className="text-[11px] text-slate-500">7-day replacement guarantee</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. FEATURED DEALS & POPULAR PRODUCTS */}
      {featuredProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-3 mb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-rose-600">
                  TOP OFFERS
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-0.5">
                Featured Marketplace Deals
              </h2>
            </div>
            <Link
              href="/deals"
              className="inline-flex items-center gap-1 text-blue-600 text-xs sm:text-sm font-bold hover:underline"
            >
              <span>View all deals</span>
              <ArrowRight size={15} />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {featuredProducts.map((product, idx) => (
              <ProductCard key={product.id} product={product} priority={idx < 4} />
            ))}
          </div>
        </section>
      )}

      {/* 5. VERIFIED APPROVED SHOPS SHOWCASE */}
      {approvedShops.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200/80 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-blue-600">
                  LOCAL MERCHANTS
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-0.5">
                  Verified Seller Shops
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Browse independent storefronts approved by Mega Bazar Super Admin
                </p>
              </div>

              <Link
                href="/shops"
                className="inline-flex items-center gap-1 text-blue-600 text-xs sm:text-sm font-bold hover:underline self-start sm:self-center"
              >
                <span>View all shops</span>
                <ArrowRight size={15} />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {approvedShops.slice(0, 6).map((shop) => (
                <Link
                  key={shop.id}
                  href={`/shop/${shop.slug}`}
                  className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between group space-y-4"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-slate-200 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                      {shop.logoUrl ? (
                        <img
                          src={shop.logoUrl}
                          alt={shop.name}
                          className="w-full h-full object-contain rounded-xl"
                        />
                      ) : (
                        <Store size={26} className="text-blue-600" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-black text-slate-900 text-sm truncate group-hover:text-blue-600 transition-colors">
                          {shop.name}
                        </h3>
                        {shop.isVerified && (
                          <CheckCircle2 size={14} className="text-blue-600 fill-blue-600 text-white shrink-0" />
                        )}
                      </div>
                      <p className="text-[11px] text-blue-600 font-semibold">{shop.category}</p>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin size={11} /> {shop.city}
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {shop.description || 'Verified merchant storefront offering nationwide Cash on Delivery dispatch across Pakistan.'}
                  </p>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700 flex items-center gap-1">
                      <Star size={13} className="fill-amber-400 text-amber-500" />
                      {shop.rating || 5.0} Rating
                    </span>
                    <span className="font-bold text-blue-600 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                      <span>Visit Store</span>
                      <ArrowRight size={13} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 6. LATEST MARKETPLACE PRODUCTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3 mb-5">
          <div>
            <span className="text-xs font-black uppercase tracking-wider text-blue-600">
              FRESH ARRIVALS
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-0.5">
              Latest Products
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Newly published items from our community of Pakistan merchants
            </p>
          </div>
          <Link
            href="/products"
            className="inline-flex items-center gap-1 text-blue-600 text-xs sm:text-sm font-bold hover:underline"
          >
            <span>View all products</span>
            <ArrowRight size={15} />
          </Link>
        </div>

        {latestProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {latestProducts.map((product, idx) => (
              <ProductCard key={product.id} product={product} priority={idx < 4} />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-slate-200 bg-slate-50/50 p-12 text-center text-slate-500">
            <Package size={36} className="mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-sm text-slate-700">Products are loading</p>
            <p className="text-xs mt-1">Check back shortly or open a shop to publish the first listing.</p>
          </div>
        )}
      </section>

      {/* 7. OPEN SHOP CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white p-7 sm:p-11 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold">
              <Store size={14} /> Sell Nationwide
            </span>
            <h2 className="text-2xl sm:text-3xl font-black">
              Start Your Online Business in Pakistan
            </h2>
            <p className="text-blue-100 text-xs sm:text-sm leading-relaxed">
              Open your free shop on Mega Bazar in under 2 minutes. Once approved by the Super Admin, publish your products and start receiving customer orders.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Link
              href="/open-shop"
              className="px-6 py-3.5 bg-white text-blue-900 hover:bg-blue-50 font-black text-xs sm:text-sm rounded-xl shadow-md transition-colors inline-flex items-center gap-2"
            >
              <span>Open My Shop Free</span>
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
};
