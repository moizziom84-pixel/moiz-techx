import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { useSearchParams } from '@/router/navigation';

export function MessagesPage() {
 const params = useSearchParams();
 const [thread, setThread] = useState(params.get('thread') || '');
 const [threads, setThreads] = useState<any[]>([]), [messages,setMessages]=useState<any[]>([]);
 const [text,setText]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 useEffect(()=>{
  if(!isSupabaseConfigured){setError('Database is not configured.');return;}
  let active=true;
  async function load(){
   const {data:{user}}=await supabase.auth.getUser();
   if(!user){if(active)setError('Sign in to read or send messages.');return;}
   const t=await supabase.from('mb_threads').select('*').order('created_at',{ascending:false});
   if(t.error){if(active)setError(t.error.message);return;}
   if(active)setThreads(t.data||[]);
   if(thread){
    const r=await supabase.from('mb_messages').select('*').eq('thread_id',thread).order('created_at',{ascending:true}).limit(500);
    if(active){if(r.error)setError(r.error.message);else {setMessages(r.data||[]);setError('');}}
   }
  }
  void load().catch(e=>{if(active)setError(e.message);});
  const timer=setInterval(()=>void load().catch(e=>{if(active)setError(e.message);}),5000);
  return()=>{active=false;clearInterval(timer);};
 },[thread]);
 async function send(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{
  const {data,error}=await supabase.rpc('mb_send_message',{target_thread:thread,message_body:text});
  if(error)throw error;if(!data?.id)throw new Error('Message was not saved.');
  setMessages(prev=>[...prev.filter(m=>m.id!==data.id),data]);setText('');
 }catch(e){setError(e instanceof Error?e.message:'Message was not saved.');}finally{setBusy(false);}}
 return <section className="max-w-5xl mx-auto p-5 space-y-5"><h1 className="text-2xl font-bold">Messages</h1><Link href="/login" className="text-blue-600 underline">Sign in</Link><p role="alert" className="text-rose-700">{error}</p><div className="grid md:grid-cols-[220px_1fr] gap-5"><aside className="space-y-2">{threads.map(t=><button key={t.id} onClick={()=>{setThread(t.id);setMessages([]);}} className="block w-full border rounded-xl p-3 bg-white text-left">Conversation {t.id.slice(0,8)}</button>)}</aside><div className="rounded-2xl bg-white border p-5 space-y-4"><div aria-live="polite" className="space-y-3 max-h-96 overflow-auto">{messages.map(m=><div key={m.id} className="rounded-xl bg-slate-50 p-3"><p className="whitespace-pre-wrap">{m.body}</p><small>{new Date(m.created_at).toLocaleString()}</small></div>)}</div>{thread&&<form onSubmit={send} className="flex gap-2"><input aria-label="Message" value={text} onChange={e=>setText(e.target.value)} maxLength={2000} required className="border rounded-xl p-3 flex-1 min-w-0"/><button disabled={busy||!text.trim()} className="bg-blue-600 text-white rounded-xl px-4 disabled:opacity-50">{busy?'Saving…':'Send'}</button></form>}</div></div></section>;
}

