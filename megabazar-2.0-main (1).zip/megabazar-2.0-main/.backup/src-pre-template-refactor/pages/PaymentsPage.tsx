import Link from 'next/link';
import { SubscriptionPanel } from '@/components/SubscriptionPanel';
import { useStore } from '@/context/StoreContext';

export function PaymentsPage() {
  const { user } = useStore();
  return <main className="max-w-6xl mx-auto px-5 py-10 space-y-5">
    <h1 className="text-3xl font-black">Seller subscriptions</h1>
    <p className="text-slate-600">Choose a plan, pay to the receiving account shown below and upload your receipt. The owner reviews your payment before activating access.</p>
    <Link href="/seller/dashboard" className="text-blue-600 underline">Seller dashboard</Link>
    {user ? <SubscriptionPanel /> : <div className="rounded-2xl border bg-white p-6"><Link href="/login?next=/subscriptions" className="text-blue-600 font-bold">Sign in to see plans and upload your receipt</Link></div>}
  </main>;
}
