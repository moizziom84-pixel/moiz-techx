import React from 'react';
import Link from 'next/link';
import { useParams } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, createWhatsAppLink } from '@/lib/utils';
import { CheckCircle2, Package, MapPin, Truck, Phone, MessageCircle, ArrowRight, Home } from 'lucide-react';

export const OrderConfirmationPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { orders, settings } = useStore();

  const order = orders.find((o) => o.id === id || o.orderNumber === id) || orders[0];

  const orderNumber = order?.orderNumber || (id ? `MB-${id.slice(0, 6)}` : 'MB-CONFIRMED');

  const waMessage = `Hello! My order has been confirmed on Mega Bazar:\n\n🆔 *Order Number:* ${orderNumber}\n👤 *Name:* ${order?.customerName || 'Customer'}\n💰 *Total:* ${formatCurrency(order?.grandTotal || 0, settings.currency)}\n📦 *Status:* Pending Processing\n\nPlease share dispatch tracking and courier details. Thank you!`;

  const waLink = createWhatsAppLink(settings.whatsappNumber || '923182204441', waMessage);

  return (
    <div className="py-10 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Success Card */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 border border-emerald-100 shadow-md text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 size={36} />
          </div>

          <div>
            <span className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-black uppercase tracking-wider rounded-full">
              ORDER CONFIRMED
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-3">
              Shukriya! Your order has been placed.
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-md mx-auto leading-relaxed">
              We have received your order. Our team will verify your details and dispatch your package via express courier.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 inline-block text-left w-full max-w-md">
            <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Order Reference</span>
              <span className="font-mono font-extrabold text-blue-600 text-sm">{orderNumber}</span>
            </div>
            <div className="flex justify-between items-center text-xs py-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Payment Mode</span>
              <span className="font-bold text-slate-800 uppercase">{order?.paymentMethod || 'Cash on Delivery'}</span>
            </div>
            <div className="flex justify-between items-center text-xs pt-2">
              <span className="text-slate-500 font-medium">Amount to Pay</span>
              <span className="font-black text-slate-900 text-sm">{formatCurrency(order?.grandTotal || 0, settings.currency)}</span>
            </div>
          </div>

          {/* WhatsApp Direct Tracking Button */}
          <div className="pt-2">
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full max-w-md mx-auto py-3.5 px-6 bg-[#25D366] hover:bg-[#20ba5a] text-white font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20 transition-all"
            >
              <MessageCircle size={18} className="fill-current" /> Get Instant WhatsApp Order Updates
            </a>
            <p className="text-[11px] text-slate-400 mt-1.5">Official support: +92 318 2204441</p>
          </div>
        </div>

        {/* Order Details Breakdown */}
        {order && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-5">
            <h2 className="text-base font-black text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Package size={18} className="text-blue-600" /> Items in Your Package
            </h2>

            <div className="space-y-3 divide-y divide-slate-100">
              {order.items.map((item, idx) => (
                <div key={idx} className="pt-3 first:pt-0 flex items-center justify-between gap-4 text-xs">
                  <div className="flex items-center gap-3">
                    {item.image && (
                      <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover border border-slate-100 shrink-0" />
                    )}
                    <div>
                      <p className="font-bold text-slate-800 line-clamp-1">{item.name}</p>
                      <p className="text-slate-400">Qty: {item.quantity} {item.selectedSize ? `· Size ${item.selectedSize}` : ''}</p>
                    </div>
                  </div>
                  <span className="font-extrabold text-slate-900 shrink-0">
                    {formatCurrency(item.price * item.quantity, settings.currency)}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Delivery Address:</span>
                <span className="font-semibold text-slate-800 text-right">{order.shippingAddress.address}, {order.shippingAddress.city}</span>
              </div>
              <div className="flex justify-between">
                <span>Customer Contact:</span>
                <span className="font-semibold text-slate-800">{order.phone}</span>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-center gap-3">
          <Link
            href="/"
            className="px-6 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-2xs"
          >
            <Home size={15} /> Return Home
          </Link>
          <Link
            href="/products"
            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs"
          >
            Continue Shopping <ArrowRight size={15} />
          </Link>
        </div>
      </div>
    </div>
  );
};
