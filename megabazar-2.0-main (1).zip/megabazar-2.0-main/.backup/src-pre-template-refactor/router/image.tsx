import React, { ImgHTMLAttributes, forwardRef, useState } from 'react';

export interface ImageProps extends Omit<ImgHTMLAttributes<HTMLImageElement>, 'src'> {
  src: string;
  alt: string;
  width?: number | `${number}`;
  height?: number | `${number}`;
  fill?: boolean;
  priority?: boolean;
  unoptimized?: boolean;
  fallbackSrc?: string;
  sizes?: string;
}

export const Image = forwardRef<HTMLImageElement, ImageProps>(
  ({ src, alt, width, height, fill, priority, unoptimized, fallbackSrc, className = '', style, onError, ...rest }, ref) => {
    const [currentSrc, setCurrentSrc] = useState(src);
    const [hasError, setHasError] = useState(false);

    const handleError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
      if (!hasError && fallbackSrc && fallbackSrc !== currentSrc) {
        setHasError(true);
        setCurrentSrc(fallbackSrc);
      }
      if (onError) {
        onError(e);
      }
    };

    const combinedStyle: React.CSSProperties = {
      ...(fill
        ? {
            position: 'absolute',
            height: '100%',
            width: '100%',
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
            objectFit: 'cover',
          }
        : {}),
      ...style,
    };

    return (
      <img
        ref={ref}
        src={currentSrc}
        alt={alt}
        width={fill ? undefined : width}
        height={fill ? undefined : height}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        className={className}
        style={combinedStyle}
        onError={handleError}
        {...rest}
      />
    );
  }
);

Image.displayName = 'Image';
export default Image;
