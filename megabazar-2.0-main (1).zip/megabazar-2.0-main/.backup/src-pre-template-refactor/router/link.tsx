import React, { AnchorHTMLAttributes, forwardRef, MouseEvent } from 'react';
import { useRouterContext } from './router-context';

export interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  replace?: boolean;
  scroll?: boolean;
  prefetch?: boolean;
}

export const Link = forwardRef<HTMLAnchorElement, LinkProps>(
  ({ href, onClick, children, replace, scroll, prefetch, ...rest }, ref) => {
    const { navigate } = useRouterContext();

    const handleClick = (e: MouseEvent<HTMLAnchorElement>) => {
      if (onClick) {
        onClick(e);
      }
      // If default was prevented or user middle clicked / held cmd/ctrl, don't hijack
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) {
        return;
      }
      if (href && !href.startsWith('http://') && !href.startsWith('https://') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
        e.preventDefault();
        navigate(href);
      }
    };

    return (
      <a ref={ref} href={href} onClick={handleClick} {...rest}>
        {children}
      </a>
    );
  }
);

Link.displayName = 'Link';
export default Link;
