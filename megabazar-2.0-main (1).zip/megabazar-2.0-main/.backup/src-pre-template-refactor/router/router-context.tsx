import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface RouterContextType {
  pathname: string;
  searchParams: URLSearchParams;
  navigate: (href: string) => void;
}

const RouterContext = createContext<RouterContextType>({
  pathname: '/',
  searchParams: new URLSearchParams(),
  navigate: () => {},
});

export const RouterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const getInitialState = () => {
    if (typeof window === 'undefined') {
      return { pathname: '/', search: '' };
    }
    // Support hash router or pathname
    const hash = window.location.hash.slice(1);
    if (hash && hash.startsWith('/')) {
      const [path, search] = hash.split('?');
      return { pathname: path || '/', search: search ? `?${search}` : '' };
    }
    return {
      pathname: window.location.pathname || '/',
      search: window.location.search || '',
    };
  };

  const [locationState, setLocationState] = useState(getInitialState);

  useEffect(() => {
    const handlePopState = () => {
      setLocationState(getInitialState());
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  const navigate = (href: string) => {
    if (!href) return;
    if (href.startsWith('http://') || href.startsWith('https://') || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('//')) {
      window.location.href = href;
      return;
    }
    const [path, search] = href.split('?');
    const newPath = path || '/';
    const newSearch = search ? `?${search}` : '';

    // Update browser URL and state
    try {
      window.history.pushState({}, '', href);
    } catch {
      window.location.hash = href;
    }
    setLocationState({ pathname: newPath, search: newSearch });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const searchParams = new URLSearchParams(locationState.search);

  return (
    <RouterContext.Provider value={{ pathname: locationState.pathname, searchParams, navigate }}>
      {children}
    </RouterContext.Provider>
  );
};

export const useRouterContext = () => useContext(RouterContext);
