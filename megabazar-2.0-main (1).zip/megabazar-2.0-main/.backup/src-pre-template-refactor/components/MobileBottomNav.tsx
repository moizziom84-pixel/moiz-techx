'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, LayoutGrid, Flame, Heart, User } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export const MobileBottomNav: React.FC = () => {
  const pathname = usePathname();
  const { wishlist } = useStore();

  // Hide mobile bottom nav on admin routes
  if (pathname.startsWith('/admin')) {
    return null;
  }

  const navItems = [
    { label: 'Home', href: '/', icon: Home, active: pathname === '/' },
    {
      label: 'Categories',
      href: '/categories',
      icon: LayoutGrid,
      active: pathname.startsWith('/products') || pathname.startsWith('/category'),
    },
    { label: 'Shops', href: '/shops', icon: Flame, active: pathname === '/shops' },
    {
      label: 'Wishlist',
      href: '/account/wishlist',
      icon: Heart,
      badge: wishlist.length,
      active: pathname === '/account/wishlist',
    },
    {
      label: 'Account',
      href: '/account',
      icon: User,
      active: pathname.startsWith('/account') && pathname !== '/account/wishlist',
    },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 shadow-lg px-2 py-1.5 safe-area-pb">
      <div className="grid grid-cols-5 gap-1 items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.label}
              href={item.href}
              className={`relative flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                item.active ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    item.active ? 'scale-110 stroke-[2.5]' : 'stroke-[1.75]'
                  } ${item.label === 'Deals' && item.active ? 'fill-rose-500 text-rose-500' : ''}`}
                />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 bg-rose-500 text-white text-[9px] font-extrabold rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight leading-none">
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};
