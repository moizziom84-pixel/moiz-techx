import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { uploadImageToSupabase } from '@/lib/supabase/storage';
export function BannerManager() {
  const [rows,setRows]=useState<any[]>([]),[title,setTitle]=useState(''),[link,setLink]=useState('/products'),[file,setFile]=useState<File|null>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  async function load(){try{setRows((await (await apiFetch('/api/banners')).json()).banners||[]);}catch(e){setMessage(e instanceof Error?e.message:'Could not load banners.');}}
  useEffect(()=>{void load();},[]);
  async function save(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage('');try{
    if(!file)throw new Error('Choose a banner picture.');if(!link.startsWith('/')||link.startsWith('//'))throw new Error('Use an internal page link, such as /products.');
    const upload=await uploadImageToSupabase(file,{folder:'banners',maxSizeMB:8});if(!upload.success)throw new Error(upload.error||'Upload failed.');
    await apiFetch('/api/banners',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,image:upload.url,link,type:'promo',status:'active',displayOrder:rows.length,buttonText:'Shop now'})});
    setTitle('');setFile(null);await load();window.dispatchEvent(new Event('focus'));setMessage('Banner and picture saved to the database.');
  }catch(e){setMessage(e instanceof Error?e.message:'Banner was not saved.');}finally{setBusy(false);}}
  return <section className="rounded-2xl border bg-white p-5 space-y-4"><h2 className="text-xl font-bold">Banner pictures</h2><form onSubmit={save} className="space-y-3"><input aria-label="Banner title" required maxLength={150} placeholder="Banner title" value={title} onChange={e=>setTitle(e.target.value)} className="block w-full rounded-xl border p-3"/><input aria-label="Banner destination" required value={link} onChange={e=>setLink(e.target.value)} className="block w-full rounded-xl border p-3"/><input aria-label="Banner image" type="file" required accept="image/jpeg,image/png,image/webp" onChange={e=>setFile(e.target.files?.[0]||null)}/><button disabled={busy} className="rounded-xl bg-blue-600 px-5 py-3 text-white">{busy?'Saving…':'Upload and save banner'}</button></form><p role="status">{message}</p><div className="grid gap-3 sm:grid-cols-2">{rows.map(r=><div key={r.id} className="rounded-xl border p-3"><img alt={r.title} src={r.image} className="h-28 w-full object-cover rounded-lg"/><p>{r.title} · {r.status}</p><button disabled={busy} className="text-rose-700" onClick={async()=>{try{await apiFetch(`/api/banners/${r.id}`,{method:'DELETE'});await load();window.dispatchEvent(new Event('focus'));}catch(e){setMessage(e instanceof Error?e.message:'Could not archive banner.');}}}>Archive banner</button></div>)}</div></section>;
}
