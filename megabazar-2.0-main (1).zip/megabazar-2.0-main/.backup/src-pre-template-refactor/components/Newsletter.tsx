import { apiFetch } from '@/lib/api';
'use client';

import React, { useState } from 'react';
import { Mail, Check, AlertCircle } from 'lucide-react';
import { isValidEmail } from '@/lib/utils';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [feedback, setFeedback] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !isValidEmail(email)) {
      setStatus('error');
      setFeedback('Please enter a valid email address.');
      return;
    }

    try { await apiFetch('/api/newsletter',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})}); } catch(error) {setStatus('error');setFeedback(error instanceof Error?error.message:'Subscription was not saved.');return;}
    setStatus('success');
    setFeedback('Your subscription was saved. You can receive future Mega Bazar offers.');
    setEmail('');
  };

  return (
    <section className="py-8 sm:py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-blue-50 via-indigo-50/50 to-sky-50 rounded-3xl p-6 sm:p-10 border border-blue-100 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Text Info */}
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-blue-500/20">
              <Mail className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Get Exclusive Offers &amp; Updates
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Join our newsletter and save on your favorite products.
              </p>
            </div>
          </div>

          {/* Form */}
          <div className="w-full md:w-auto md:min-w-[380px]" suppressHydrationWarning>
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2" suppressHydrationWarning>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (status !== 'idle') setStatus('idle');
                }}
                placeholder="Enter your email address"
                suppressHydrationWarning
                className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:outline-hidden text-slate-800 font-medium"
              />
              <button
                type="submit"
                suppressHydrationWarning
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-md shadow-blue-500/20 whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>

            {status === 'error' && (
              <p className="flex items-center gap-1 text-xs text-rose-500 font-medium mt-2">
                <AlertCircle className="w-3.5 h-3.5" /> {feedback}
              </p>
            )}

            {status === 'success' && (
              <p className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-2">
                <Check className="w-3.5 h-3.5" /> {feedback}
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
