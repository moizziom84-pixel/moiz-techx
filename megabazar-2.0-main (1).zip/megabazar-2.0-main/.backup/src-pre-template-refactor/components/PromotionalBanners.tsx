import { useStore } from '@/context/StoreContext';
'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

export const PromotionalBanners: React.FC = () => {
  const { banners } = useStore();
  const active=banners.filter(b=>b.status==='active');
  if(active.length) return <section className="max-w-7xl mx-auto px-5 py-8 grid md:grid-cols-2 gap-5">{active.sort((a,b)=>a.displayOrder-b.displayOrder).map(b=><Link key={b.id} href={b.link.startsWith('/')&&!b.link.startsWith('//')?b.link:'/products'} className="relative overflow-hidden rounded-3xl border bg-white group"><img src={b.imageUrl} alt={b.title} className="h-64 w-full object-cover"/><div className="p-6"><h2 className="text-2xl font-black">{b.title}</h2><p>{b.subtitle}</p><span className="inline-block mt-3 text-blue-600 font-bold">{b.buttonText||'Shop now'} →</span></div></Link>)}</section>;
  return (
    <section className="py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">
          Trusted by Top Brands
        </h2>

        <div className="grid md:grid-cols-2 gap-4 sm:gap-6">
          {/* Banner 1: Summer Collection */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-200 p-6 sm:p-8 flex items-center justify-between shadow-sm group">
            <div className="space-y-2 z-10 max-w-[60%]">
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-950/70">
                Summer Collection
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                Up to 50% Off
              </h3>
              <p className="text-xs font-semibold text-slate-700">
                On Fashion &amp; Accessories
              </p>
              <div className="pt-2">
                <Link
                  href="/category/fashion"
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-950 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  Shop Now
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>

            {/* Model / Fashion Image */}
            <div className="relative w-36 h-40 sm:w-48 sm:h-48 shrink-0 -mr-2">
              <Image
                src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=500&q=80"
                alt="Summer Collection"
                fill
                sizes="192px"
                className="object-cover rounded-2xl group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Banner 2: Home Essentials */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-100 via-sky-100 to-indigo-100 p-6 sm:p-8 flex items-center justify-between shadow-sm group">
            <div className="space-y-2 z-10 max-w-[60%]">
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-900/70">
                Home Essentials
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                For Better Living
              </h3>
              <p className="text-xs font-semibold text-slate-700">
                Up to 40% Off on Home &amp; Kitchen
              </p>
              <div className="pt-2">
                <Link
                  href="/category/home-living"
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  Shop Now
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>

            {/* Home Furniture / Decor Image */}
            <div className="relative w-36 h-40 sm:w-48 sm:h-48 shrink-0 -mr-2">
              <Image
                src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=500&q=80"
                alt="Home Essentials"
                fill
                sizes="192px"
                className="object-cover rounded-2xl group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
