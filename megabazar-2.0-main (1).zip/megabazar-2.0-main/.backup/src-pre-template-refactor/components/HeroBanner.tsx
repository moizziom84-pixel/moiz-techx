'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Truck, RotateCcw, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { useStore } from '@/context/StoreContext';

export const HeroBanner: React.FC = () => {
  const { settings } = useStore();

  return (
    <section className="pt-2 pb-6 sm:pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Hero Card */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-50 via-slate-50 to-indigo-50/70 border border-blue-100/80 shadow-md">
          {/* Decorative glowing gradient orbs */}
          <div className="absolute top-0 right-0 -mt-16 -mr-16 w-80 h-80 rounded-full bg-blue-400/10 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-1/3 -mb-16 w-72 h-72 rounded-full bg-indigo-300/10 blur-3xl pointer-events-none" />

          {/* Promotional Discount Badge */}
          <div className="absolute top-4 right-4 sm:top-8 sm:right-8 z-20">
            <div className="relative w-18 h-18 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-slate-950 font-black flex flex-col items-center justify-center shadow-lg shadow-amber-500/30 transform rotate-12 hover:rotate-0 transition-transform duration-300 border-2 border-white">
              <span className="text-[10px] sm:text-xs uppercase font-extrabold tracking-tight">UP TO</span>
              <span className="text-xl sm:text-3xl font-black leading-none">60%</span>
              <span className="text-[9px] sm:text-[11px] font-bold">OFF</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 lg:p-14 relative z-10">
            {/* Left Content */}
            <div className="lg:col-span-6 space-y-4 sm:space-y-6 text-center lg:text-left">
              {/* Overline Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/80 text-blue-800 text-[11px] sm:text-xs font-bold tracking-wider uppercase">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                PREMIUM QUALITY. PREMIUM YOU.
              </div>

              {/* Headline */}
              <h1 className="text-3xl sm:text-5xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
                Everything You Need,<br />
                All in <span className="text-blue-600 underline decoration-blue-300 decoration-wavy decoration-2">One Place</span>
              </h1>

              {/* Description */}
              <p className="text-sm sm:text-base text-slate-600 max-w-lg mx-auto lg:mx-0 leading-relaxed">
                Discover amazing products from trusted brands with great prices, premium quality and reliable service across Pakistan.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
                <Link
                  href="/products"
                  className="px-6 py-3.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-blue-600/30 flex items-center gap-2 text-sm transition-all"
                >
                  Shop Now
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/deals"
                  className="px-6 py-3.5 bg-white hover:bg-slate-100 active:scale-95 text-slate-800 font-bold rounded-2xl border border-slate-200/90 shadow-xs text-sm transition-all"
                >
                  Explore Deals
                </Link>
              </div>
            </div>

            {/* Right Product Showcase Montage */}
            <div className="lg:col-span-6 relative flex items-center justify-center">
              <div className="relative w-full max-w-lg aspect-4/3 rounded-2xl overflow-hidden p-4">
                {/* Floating Product Montage Collage */}
                <div className="grid grid-cols-3 gap-3 h-full">
                  {/* Item 1: Smartphone */}
                  <div className="relative rounded-2xl overflow-hidden shadow-md group transform hover:scale-105 transition-transform bg-white">
                    <Image
                      src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=500&q=80"
                      alt="Smartphone Pro Max"
                      fill
                      sizes="200px"
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent flex items-end p-2.5">
                      <span className="text-[11px] font-bold text-white drop-shadow-sm">Mobiles</span>
                    </div>
                  </div>

                  {/* Item 2: Headphones (Center Top) */}
                  <div className="col-span-2 relative rounded-2xl overflow-hidden shadow-md group transform hover:scale-105 transition-transform bg-white">
                    <Image
                      src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"
                      alt="Wireless Headphones"
                      fill
                      sizes="350px"
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent flex items-end p-3">
                      <span className="text-xs font-bold text-white drop-shadow-sm">Hi-Fi Audio</span>
                    </div>
                  </div>

                  {/* Item 3: Luxury Handbag */}
                  <div className="col-span-2 relative rounded-2xl overflow-hidden shadow-md group transform hover:scale-105 transition-transform bg-white">
                    <Image
                      src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=80"
                      alt="Designer Handbag"
                      fill
                      sizes="350px"
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent flex items-end p-3">
                      <span className="text-xs font-bold text-white drop-shadow-sm">Fashion &amp; Bags</span>
                    </div>
                  </div>

                  {/* Item 4: Smartwatch */}
                  <div className="relative rounded-2xl overflow-hidden shadow-md group transform hover:scale-105 transition-transform bg-white">
                    <Image
                      src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80"
                      alt="Smartwatch Pro"
                      fill
                      sizes="200px"
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent flex items-end p-2.5">
                      <span className="text-[11px] font-bold text-white drop-shadow-sm">Wearables</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Trust Badges Below Hero */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-6 mt-4">
          {/* Badge 1: Free Shipping */}
          <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Free Shipping</h4>
              <p className="text-[11px] text-slate-500">
                On orders over {formatCurrency(settings.freeShippingThreshold || 5000, settings.currency)}
              </p>
            </div>
          </div>

          {/* Badge 2: Easy Returns */}
          <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Easy Returns</h4>
              <p className="text-[11px] text-slate-500">30-day hassle-free return policy</p>
            </div>
          </div>

          {/* Badge 3: Secure Payment */}
          <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">Secure Payment</h4>
              <p className="text-[11px] text-slate-500">100% protected &amp; verified transactions</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
