import { useState } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';

export function DatabaseStatus() {
  const [results, setResults] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  async function check() {
    setBusy(true); setResults([]);
    try {
      if (!isSupabaseConfigured) throw new Error('Supabase URL and public key are missing. Configure them before building.');
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error || !user) throw new Error('Sign in with your verified Supabase account first.');
      if (user.app_metadata?.role !== 'super_admin') throw new Error('Your server-assigned role is not super_admin.');
      const rows = await Promise.all(['mb_shops', 'mb_notifications', 'products', 'orders', 'mb_products', 'mb_threads', 'mb_messages', 'mb_plans', 'mb_payment_requests'].map(async table => {
        const { error } = await supabase.from(table).select('*', { head: true, count: 'exact' }).limit(1);
        return error ? `${table}: failed — ${error.message}` : `${table}: read request passed (write permissions not tested)`;
      }));
      const role = await supabase.rpc('mb_is_admin');
      setResults([role.error ? `Owner role check: ${role.error.message}` : `Database owner check: ${role.data === true ? 'passed' : 'denied'}`, ...rows]);
    } catch (error) { setResults([error instanceof Error ? error.message : 'Connection check failed.']); }
    finally { setBusy(false); }
  }
  return <div className="space-y-3"><p>Configuration: {isSupabaseConfigured ? 'URL/key supplied; live access requires a check.' : 'URL/key missing.'}</p><button type="button" onClick={check} disabled={busy} className="rounded-xl bg-blue-600 text-white px-4 py-2">{busy ? 'Checking…' : 'Check live database'}</button><ul role="status" className="space-y-2">{results.map(result => <li key={result}>{result}</li>)}</ul></div>;
}

