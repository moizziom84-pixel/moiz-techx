'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Star, ShieldCheck, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: 'Emily Johnson',
      role: 'Verified Buyer',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
      comment:
        'Great products, fast delivery, and excellent customer service. Mega Bazar is my go-to shopping destination!',
      rating: 5,
      location: 'Islamabad',
    },
    {
      name: 'Muhammad Hamza',
      role: 'Verified Buyer',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      comment:
        'I ordered the Smart Watch Pro and paid via JazzCash Till ID. Order arrived in 2 days and the quality is 100% genuine.',
      rating: 5,
      location: 'Karachi',
    },
    {
      name: 'Fatima Noor',
      role: 'Verified Buyer',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
      comment:
        'The best online bazaar in Pakistan. Authentic products in PKR prices, zero hidden fees, and hassle-free Cash on Delivery.',
      rating: 5,
      location: 'Lahore',
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const prev = () => {
    setCurrentIndex((c) => (c === 0 ? testimonials.length - 1 : c - 1));
  };

  const next = () => {
    setCurrentIndex((c) => (c === testimonials.length - 1 ? 0 : c + 1));
  };

  const current = testimonials[currentIndex];

  return (
    <section className="py-6 sm:py-10 bg-slate-50/70 border-y border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-6">
          <span className="text-xs font-black uppercase tracking-wider text-blue-600">
            Real Reviews From Real Shoppers
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            Loved by Customers Across Pakistan
          </h2>
        </div>

        <div className="relative bg-white rounded-3xl p-6 sm:p-10 shadow-sm border border-slate-200/60">
          <Quote className="w-10 h-10 text-blue-100 absolute top-6 right-6" />

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 relative z-10 text-center sm:text-left">
            {/* Customer Avatar */}
            <div className="relative w-20 h-20 rounded-full overflow-hidden border-3 border-blue-100 shadow-md shrink-0">
              <Image
                src={current.avatar}
                alt={current.name}
                fill
                sizes="80px"
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Testimonial Content */}
            <div className="flex-1 space-y-3">
              {/* Rating stars */}
              <div className="flex justify-center sm:justify-start text-amber-400 gap-1">
                {[...Array(current.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-sm sm:text-base text-slate-700 italic font-medium leading-relaxed">
                &ldquo;{current.comment}&rdquo;
              </p>

              {/* Buyer info */}
              <div className="flex items-center justify-center sm:justify-start gap-2 pt-1">
                <span className="font-bold text-slate-900 text-sm">{current.name}</span>
                <span className="text-slate-300">&bull;</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  {current.role}
                </span>
                <span className="text-xs text-slate-400">({current.location})</span>
              </div>
            </div>
          </div>

          {/* Dots & Nav controls */}
          <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-100" suppressHydrationWarning>
            <div className="flex gap-1.5" suppressHydrationWarning>
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  suppressHydrationWarning
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    idx === currentIndex ? 'w-6 bg-blue-600' : 'bg-slate-200'
                  }`}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

            <div className="flex gap-2" suppressHydrationWarning>
              <button
                onClick={prev}
                suppressHydrationWarning
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={next}
                suppressHydrationWarning
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
