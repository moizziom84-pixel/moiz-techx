'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { Logo } from '@/components/Logo';
import {
  LayoutDashboard,
  Package,
  Layers,
  ShoppingBag,
  Users,
  Tag,
  Image as ImageIcon,
  MessageSquare,
  Boxes,
  BarChart3,
  Settings,
  Store,
  Menu,
  X,
  RefreshCw,
  Trash2,
  Lock,
  KeyRound,
  Eye,
  EyeOff,
  AlertCircle,
  ShieldCheck,
  PlusCircle,
  Sparkles,
} from 'lucide-react';

export const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const pathname = usePathname();
  const router = useRouter();
  const {
    isAdminAuthenticated,
    verifyAdminCredentials,
    verifyAdminPassword,
    updateAdminCredentials,
    logoutAdmin,
    settings,
    resetDemoData,
    deleteDemoProducts,
    switchDemoAccount,
  } = useStore();

  const [idInput, setIdInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Quick Change Password Modal state
  const [isChangeModalOpen, setIsChangeModalOpen] = useState(false);
  const [modalNewEmail, setModalNewEmail] = useState(settings.adminEmail || 'admin@megabazar.pk');
  const [modalNewPass, setModalNewPass] = useState('');
  const [modalConfirmPass, setModalConfirmPass] = useState('');
  const [modalShowPass, setModalShowPass] = useState(false);
  const [modalError, setModalError] = useState('');
  const [modalSuccess, setModalSuccess] = useState('');
  const [modalSaving, setModalSaving] = useState(false);

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const navItems = [
    { label: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { label: 'Shops & Approvals', href: '/admin/marketplace', icon: Store },
    { label: 'Products', href: '/admin/products', icon: Package },
    { label: '✨ Add Product (+)', href: '/admin/products/new', icon: PlusCircle, isHighlight: true },
    { label: 'Categories', href: '/admin/categories', icon: Layers },
    { label: 'Orders', href: '/admin/orders', icon: ShoppingBag },
    { label: 'Customers', href: '/admin/customers', icon: Users },
    { label: 'Coupons', href: '/admin/coupons', icon: Tag },
    { label: 'Banners', href: '/admin/banners', icon: ImageIcon },
    { label: 'Reviews', href: '/admin/reviews', icon: MessageSquare },
    { label: 'Inventory', href: '/admin/inventory', icon: Boxes },
    { label: 'Reports', href: '/admin/reports', icon: BarChart3 },
    { label: 'Store Settings', href: '/admin/settings', icon: Settings },
  ];

  const handleLockAdmin = () => {
    logoutAdmin();
    router.push('/admin/login');
    router.refresh();
  };

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const targetId = idInput.trim();
    const targetPass = passwordInput.trim();
    if (!targetId && !targetPass) {
      setErrorMsg('Please enter both Admin ID and Password.');
      return;
    }
    if (!targetId) {
      setErrorMsg('Please enter Admin ID / Email.');
      return;
    }
    if (!targetPass) {
      setErrorMsg('Please enter Admin Password.');
      return;
    }
    setIsSubmitting(true);
    const valid = await verifyAdminCredentials(targetId, targetPass);
    if (!valid) {
      setErrorMsg('Invalid Admin ID or Password. Access denied.');
      setIsSubmitting(false);
    } else {
      setIsSubmitting(false);
      setIdInput('');
      setPasswordInput('');
    }
  };

  const handleQuickChangeCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    setModalSuccess('');

    const newEmail = modalNewEmail.trim();
    const newPass = modalNewPass.trim();
    const confirmPass = modalConfirmPass.trim();

    if (!newEmail) {
      setModalError('Admin ID / Email cannot be empty.');
      return;
    }

    if (newPass && newPass.length < 4) {
      setModalError('New password must be at least 4 characters long.');
      return;
    }

    if (newPass && newPass !== confirmPass) {
      setModalError('New passwords do not match. Please re-check.');
      return;
    }

    setModalSaving(true);
    try {
      await updateAdminCredentials(newEmail, newPass ? newPass : undefined);
      setModalSaving(false);
      setModalSuccess('Admin credentials updated successfully!');
      setTimeout(() => {
        setIsChangeModalOpen(false);
        setModalSuccess('');
        setModalNewPass('');
        setModalConfirmPass('');
      }, 1500);
    } catch {
      setModalSaving(false);
      setModalError('Failed to update credentials. Please try again.');
    }
  };

  // PASSWORD PROTECTION GATE
  if (!isAdminAuthenticated) {
    return <div className="max-w-md mx-auto p-8"><h1 className="text-xl font-bold">Sign in to continue</h1><p className="text-sm text-slate-500 mt-3">Use your normal Mega Bazar account. Owner access is assigned securely.</p><Link href="/login" className="inline-block mt-5 text-blue-600 font-bold">Sign in</Link></div>;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row font-sans">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-slate-300 border-r border-slate-800 shrink-0 select-none">
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <Logo size="sm" inverted={true} showTagline={false} href="/admin" />
          <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[10px] uppercase">
            Admin
          </span>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs font-semibold">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.href === '/admin'
                ? pathname === '/admin'
                : pathname.startsWith(item.href);

            return (
              <Link
                key={item.label}
                href={item.href}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Demo Controls & Storefront Return */}
        <div className="p-3 border-t border-slate-800 space-y-2">
          {/* Quick Demo Controls */}
          <div className="p-2.5 bg-slate-800/80 rounded-xl space-y-1.5 text-[11px]">
            <span className="font-bold text-slate-400 uppercase tracking-wider block text-[9px]">
              Demo Management
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => setShowConfirmReset(true)}
                className="p-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/30 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                title="Reset Demo Data"
              >
                <RefreshCw className="w-3 h-3" /> Reset
              </button>
              <button
                onClick={() => setShowConfirmDelete(true)}
                className="p-1.5 bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/30 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                title="Delete Demo Products"
              >
                <Trash2 className="w-3 h-3" /> Clear
              </button>
            </div>
          </div>

          <Link
            href="/"
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <Store className="w-4 h-4 text-emerald-400" />
            <span>View Customer Store</span>
          </Link>

          {/* Lock Admin Session Button */}
          <button
            onClick={handleLockAdmin}
            className="w-full flex items-center justify-center gap-2 px-3.5 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            title="Lock Admin Panel"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Admin Panel</span>
          </button>
        </div>
      </aside>

      {/* Main Content Layout */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Admin Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-2xs">
          {/* Left: Mobile hamburger & current route name */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="md:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 cursor-pointer"
              aria-label="Open Admin Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-800 hidden sm:inline">
                Mega Bazar Admin
              </span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {pathname.split('/')[2] || 'Dashboard'}
              </span>
            </div>
          </div>

          {/* Right: Quick Actions, Customer View & Lock Admin */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Glowing Prominent Add Product Button */}
            <Link
              href="/admin/products/new"
              className="relative group overflow-hidden px-3.5 sm:px-4 py-2 bg-gradient-to-r from-amber-500 via-pink-600 to-purple-600 hover:from-amber-600 hover:to-purple-700 text-white font-black text-xs rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 active:scale-95 transition-all flex items-center gap-1.5 border border-white/20 animate-pulse shrink-0"
              title="Click to Add New Product"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-200" />
              <span className="whitespace-nowrap font-black">
                + Add Product
              </span>
            </Link>

            {/* Quick switch to customer */}
            <button
              onClick={() => {
                switchDemoAccount('customer');
                router.push('/');
              }}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              <Store className="w-3.5 h-3.5" /> Customer View
            </button>

            {/* Lock Admin Header Button */}
            <button
              onClick={handleLockAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl text-xs border border-rose-200 transition-colors cursor-pointer"
              title="Lock Admin Session"
            >
              <Lock className="w-3.5 h-3.5" /> Lock Panel
            </button>

            {/* Admin Profile */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
                A
              </div>
              <div className="hidden lg:block text-left text-xs leading-tight">
                <p className="font-bold text-slate-900">Administrator</p>
                <p className="text-[10px] text-slate-400">admin@megabazar.pk</p>
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-4 sm:p-6 lg:p-8 flex-1 overflow-y-auto">
          {children}
        </main>
      </div>

      {/* Mobile Drawer */}
      {isMobileSidebarOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex">
          <div className="w-4/5 max-w-xs bg-slate-900 text-slate-300 h-full p-4 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <Logo size="sm" inverted={true} />
                <button
                  onClick={() => setIsMobileSidebarOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="space-y-1 text-xs font-semibold">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive =
                    item.href === '/admin'
                      ? pathname === '/admin'
                      : pathname.startsWith(item.href);

                  return (
                    <Link
                      key={item.label}
                      href={item.href}
                      onClick={() => setIsMobileSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
                        isActive
                          ? 'bg-blue-600 text-white font-bold'
                          : 'text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <Link
                href="/"
                onClick={() => setIsMobileSidebarOpen(false)}
                className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-xl text-xs font-bold text-emerald-400"
              >
                <Store className="w-4 h-4" /> View Customer Store
              </Link>

              <button
                onClick={() => {
                  setIsMobileSidebarOpen(false);
                  handleLockAdmin();
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded-xl text-xs font-bold cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" /> Lock Admin Panel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Reset Demo Data Modal */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Reset Demo Data?</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              This will restore the 20 official demo products, categories, demo orders, and default store settings. Real customer accounts will not be affected.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetDemoData();
                  setShowConfirmReset(false);
                }}
                className="flex-1 py-2.5 bg-blue-600 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Delete Demo Products Modal */}
      {showConfirmDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Delete Demo Products?</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              This will remove all demo products from the store so you can test adding real products from scratch. You can restore them anytime using &ldquo;Reset Demo Data&rdquo;.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowConfirmDelete(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteDemoProducts();
                  setShowConfirmDelete(false);
                }}
                className="flex-1 py-2.5 bg-rose-600 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Clear Products
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
