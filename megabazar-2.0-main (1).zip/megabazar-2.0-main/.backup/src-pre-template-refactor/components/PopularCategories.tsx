'use client';

import React from 'react';
import Link from 'next/link';
import SafeImage from '@/components/SafeImage';
import { useStore } from '@/context/StoreContext';
import { ArrowRight } from 'lucide-react';

export const PopularCategories: React.FC = () => {
  const { categories } = useStore();

  return (
    <section className="py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Popular Categories
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Explore our top trending shopping departments</p>
          </div>
          <Link
            href="/products"
            className="text-xs sm:text-sm font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 group transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-3 sm:gap-4">
          {categories.slice(0, 7).map((cat) => (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className="group p-3 sm:p-4 rounded-2xl bg-white border border-slate-200/70 hover:border-blue-300 hover:shadow-md transition-all duration-200 flex items-center gap-3.5"
            >
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-slate-50 shrink-0">
                <SafeImage
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="64px"
                  className="object-cover group-hover:scale-108 transition-transform duration-300"
                  fallbackSrc="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80"
                />
              </div>
              <div className="min-w-0">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                  {cat.name}
                </h3>
                <span className="text-[11px] font-medium text-slate-400 block mt-0.5">
                  {cat.count.toLocaleString()}+ items
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};
