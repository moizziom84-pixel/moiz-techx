import { useEffect,useState } from 'react';
import { supabase } from '@/lib/supabase/client';
export function SupportMessages(){
 const [rows,setRows]=useState<any[]>([]),[error,setError]=useState('');
 async function load(){const r=await supabase.from('mb_support_messages').select('*').order('created_at',{ascending:false}).limit(200);if(r.error)setError(r.error.message);else{setRows(r.data||[]);setError('');}}
 useEffect(()=>{void load();},[]);
 return <section className="rounded-2xl border bg-white p-5 space-y-4"><h2 className="text-xl font-bold">Customer support messages</h2><button onClick={load} className="text-blue-600">Refresh</button><p role="status">{error}</p>{rows.map(r=><article key={r.id} className="border-b pb-3"><b>{r.name}</b><p className="whitespace-pre-wrap">{r.body}</p><small>{new Date(r.created_at).toLocaleString()}</small></article>)}{!rows.length&&!error&&<p>No support messages.</p>}</section>;
}
