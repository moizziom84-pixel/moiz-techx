import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { Eye, EyeOff, Lock, X } from 'lucide-react';
import { useRouterContext } from '@/router/router-context';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { accountError, createAccount, requestRecovery, saveOwnPassword } from '@/lib/account-auth';

const field = 'w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden';
const action = 'w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold disabled:opacity-50';

export function PasswordField({ label, value, onChange, autoComplete = 'new-password', minLength = 8 }: { label: string; value: string; onChange: (value: string) => void; autoComplete?: string; minLength?: number }) {
  const [visible, setVisible] = useState(false);
  const id = React.useId();
  return <div><label htmlFor={id} className="font-bold block mb-2">{label}</label><div className="relative"><input id={id} type={visible ? 'text' : 'password'} required minLength={minLength} maxLength={128} value={value} autoComplete={autoComplete} onChange={e => onChange(e.target.value)} className={`${field} pr-12`} /><button type="button" onClick={() => setVisible(v => !v)} aria-label={`${visible ? 'Hide' : 'Show'} ${label.toLowerCase()}`} aria-pressed={visible} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 p-1">{visible ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></div>;
}

function Card({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
 return <section className="py-12 sm:py-20 px-4 min-h-[65vh] flex justify-center items-start"><div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 border border-slate-200 shadow-xl space-y-6 text-sm"><header className="text-center space-y-2"><Lock className="mx-auto text-blue-600" size={28} /><h1 className="text-2xl font-black text-slate-900">{title}</h1><p className="text-slate-500 text-sm">{subtitle}</p></header>{children}</div></section>;
}

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
 const { navigate, searchParams } = useRouterContext();
 const requestedNext = searchParams.get('next');
 const nextPage = requestedNext === '/open-shop' || requestedNext === '/subscriptions' ? requestedNext : null;
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[confirmation,setConfirmation]=useState('');
 const [name,setName]=useState(''),[phone,setPhone]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState('');
 const [forgot,setForgot]=useState(false),[resetEmail,setResetEmail]=useState(''),[resetBusy,setResetBusy]=useState(false),[resetError,setResetError]=useState(''),[resetSent,setResetSent]=useState(false),[cooldown,setCooldown]=useState(0);
 useEffect(()=>{setPassword('');setConfirmation('');setError('');setSuccess('');setForgot(false);},[mode]);
 useEffect(()=>{if(cooldown<=0)return;const timer=window.setTimeout(()=>setCooldown(c=>c-1),1000);return()=>clearTimeout(timer);},[cooldown]);
 async function submit(e:React.FormEvent){
  e.preventDefault();setBusy(true);setError('');setSuccess('');
  try {
   if(!isSupabaseConfigured)throw new Error('Account connection is not configured. Please contact the store owner.');
   if(mode==='register'){
    const data=await createAccount({email,password,confirmation,name,phone,origin:window.location.origin});
    setPassword('');setConfirmation('');
    if(!data.session){setSuccess('Check your email and click the confirmation link, then sign in. No OTP code is needed.');return;}
    setSuccess('Account created. You are signed in.');navigate(nextPage || '/');
   }else{
    const {data,error}=await supabase.auth.signInWithPassword({email:email.trim(),password});
    if(error)throw error;if(!data.session||!data.user)throw new Error('Sign in was not confirmed.');
    const role=data.user.app_metadata?.role;
    setPassword('');navigate(role==='super_admin'?'/admin':nextPage || (role==='seller'||data.user.user_metadata?.role==='seller'?'/seller/dashboard':'/'));
   }
  }catch(e){setError(accountError(e));}finally{setBusy(false);}
 }
 async function sendLink(e:React.FormEvent){
  e.preventDefault();if(resetBusy||cooldown)return;setResetBusy(true);setResetError('');
  try{
   if(!isSupabaseConfigured)throw new Error('Account connection is not configured. Please contact the store owner.');
   await requestRecovery(resetEmail,window.location.origin);setResetSent(true);setCooldown(60);
  }catch(e){setResetError(accountError(e));if((e as any)?.status===429||/rate.limit/i.test((e as any)?.message||''))setCooldown(60);}
  finally{setResetBusy(false);}
 }
 return <Card title={mode==='login'?'Sign in to Mega Bazar':'Create your account'} subtitle={mode==='login'?'Use your account email and password.':'Enter your email, choose a password and confirm it.'}>
  {success?<p role="status" className="rounded-xl bg-emerald-50 text-emerald-800 p-4">{success}</p>:<form onSubmit={submit} className="space-y-4">
   {mode==='register'&&<><label className="block font-bold">Full name<input required autoComplete="name" value={name} onChange={e=>setName(e.target.value)} className={`${field} mt-2`} /></label><label className="block font-bold">Mobile / WhatsApp (optional)<input type="tel" autoComplete="tel" value={phone} onChange={e=>setPhone(e.target.value)} className={`${field} mt-2`} /></label></>}
   <label className="block font-bold">Email address<input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com" className={`${field} mt-2`} /></label>
   <PasswordField label="Password" value={password} onChange={setPassword} autoComplete={mode==='login'?'current-password':'new-password'} minLength={mode==='login'?1:8} />
   {mode==='register'&&<><PasswordField label="Confirm password" value={confirmation} onChange={setConfirmation} /><p className="text-xs text-slate-500">Use at least 8 characters. Both passwords must match.</p></>}
   {mode==='login'&&<button type="button" onClick={()=>{setResetEmail(email);setForgot(true);setResetError('');setResetSent(false);}} className="text-blue-600 font-bold">Forgot password?</button>}
   {error&&<p role="alert" className="rounded-xl bg-rose-50 text-rose-700 p-3">{error}</p>}
   <button disabled={busy} className={action}>{busy?'Please wait…':mode==='login'?'Sign in':'Create account'}</button>
  </form>}
  <p className="text-center text-sm">{mode==='login'?"Don't have an account? ":'Already registered? '}<Link href={`${mode==='login'?'/register':'/login'}${nextPage?`?next=${encodeURIComponent(nextPage)}`:''}`} className="text-blue-600 font-bold underline">{mode==='login'?'Create account':'Sign in'}</Link></p>
  {forgot&&<div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center px-4"><section role="dialog" aria-modal="true" aria-labelledby="forgot-title" className="w-full max-w-md rounded-3xl bg-white p-7 space-y-5"><div className="flex items-center justify-between"><h2 id="forgot-title" className="text-xl font-bold">Forgot password</h2><button type="button" onClick={()=>setForgot(false)} aria-label="Close password recovery" disabled={resetBusy}><X /></button></div><p className="text-slate-600">1. Enter your account email.<br/>2. Open the reset link in your inbox or spam.<br/>3. Enter and confirm your new password. No OTP code is needed.</p>
   {resetSent&&<p role="status" className="bg-emerald-50 text-emerald-800 rounded-xl p-3">If an account uses this email, a reset link has been requested. Check your inbox and spam. Your password has not changed yet.</p>}
   <form onSubmit={sendLink} className="space-y-4"><label className="block font-bold">Account email<input required type="email" value={resetEmail} onChange={e=>setResetEmail(e.target.value)} className={`${field} mt-2`} /></label>{resetError&&<p role="alert" className="text-rose-700 bg-rose-50 p-3 rounded-xl">{resetError}</p>}<button disabled={resetBusy||cooldown>0} className={action}>{resetBusy?'Sending…':cooldown?`Try again in ${cooldown}s`:'Send reset link'}</button></form>
   <button type="button" onClick={()=>setForgot(false)} className="text-blue-600 font-bold">Back to sign in</button>
  </section></div>}
 </Card>;
}

export function ResetPasswordPage(){
 const [password,setPassword]=useState(''),[confirmation,setConfirmation]=useState(''),[ready,setReady]=useState(false),[checking,setChecking]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState(false);
 useEffect(()=>{
  let alive=true;
  if(!isSupabaseConfigured){setError('Account connection is not configured.');setChecking(false);return;}
  const {data}=supabase.auth.onAuthStateChange((event,session)=>{if(!alive)return;if(event==='PASSWORD_RECOVERY'||event==='SIGNED_IN'){setReady(!!session);setChecking(false);}if(event==='SIGNED_OUT')setReady(false);});
  void supabase.auth.getUser().then(({data:{user},error})=>{if(alive){setReady(!!user&&!error);setChecking(false);}}).catch(()=>{if(alive){setReady(false);setChecking(false);}});
  return()=>{alive=false;data.subscription.unsubscribe();};
 },[]);
 async function save(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{await saveOwnPassword(password,confirmation);setPassword('');setConfirmation('');setSuccess(true);await supabase.auth.signOut({scope:'local'});}catch(e){setError(accountError(e));}finally{setBusy(false);}}
 return <Card title="Set a new password" subtitle="Choose your new password and enter it again to confirm.">
  {checking?<p role="status">Checking your reset link…</p>:success?<p role="status" className="bg-emerald-50 text-emerald-800 p-4 rounded-xl">Your account password was saved. Sign in using your new password.</p>:<>
   {!ready&&<p role="alert" className="bg-amber-50 text-amber-900 p-4 rounded-xl">Open the reset link from your email first. If the link expired, go back to Sign in and request a new link. You can also change your own password here after signing in.</p>}
   <form onSubmit={save} className="space-y-4"><PasswordField label="New password" value={password} onChange={setPassword} /><PasswordField label="Confirm new password" value={confirmation} onChange={setConfirmation} />{error&&<p role="alert" className="text-rose-700 bg-rose-50 rounded-xl p-3">{error}</p>}<button disabled={!ready||busy} className={action}>{busy?'Saving…':'Save new password'}</button></form>
  </>}
  <Link href="/login" className="block text-center text-blue-600 underline font-bold">Back to sign in</Link>
 </Card>;
}

