'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import SafeImage from '@/components/SafeImage';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, calculateDiscount, createWhatsAppLink, formatDisplayPakistaniPhone } from '@/lib/utils';
import { formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
import { ProductCard } from '@/components/ProductCard';
import { Product } from '@/lib/types';
import {
  Star,
  Heart,
  ShoppingCart,
  Zap,
  Truck,
  RotateCcw,
  ShieldCheck,
  Check,
  Share2,
  Minus,
  Plus,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  X,
  Copy,
  MessageCircle,
  Facebook,
  Twitter,
  Mail,
  CheckCircle2,
  Package,
  Layers,
  Sparkles,
  Send,
  Globe,
  Loader2,
  Store,
  ArrowRight,
} from 'lucide-react';

interface ProductDetailClientProps {
  initialProductId: string;
  initialProduct?: Product;
}

export const ProductDetailClient: React.FC<ProductDetailClientProps> = ({
  initialProductId,
  initialProduct,
}) => {
  const router = useRouter();
  const {
    products,
    reviews,
    settings,
    addToCart,
    toggleWishlist,
    isInWishlist,
    createReview,
    user,
    shops,
  } = useStore();

  const inMemoryProduct =
    products.find(
      (p) => p.id === initialProductId || p.slug === initialProductId
    ) ||
    initialProduct ||
    null;

  const [remoteProduct, setRemoteProduct] = useState<Product | null>(null);
  const [isFetchingRemote, setIsFetchingRemote] = useState<boolean>(!inMemoryProduct);

  useEffect(() => {
    if (inMemoryProduct) {
      return;
    }

    let isMounted = true;
    fetch(`/api/products/${initialProductId}`, { cache: 'no-store' })
      .then((r) => r.json())
      .then((data) => {
        if (isMounted) {
          if (data.success && data.product) {
            setRemoteProduct(data.product);
          }
          setIsFetchingRemote(false);
        }
      })
      .catch(() => {
        if (isMounted) setIsFetchingRemote(false);
      });

    return () => {
      isMounted = false;
    };
  }, [initialProductId, inMemoryProduct]);

  const product = inMemoryProduct || remoteProduct;

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'specifications' | 'reviews'>('description');
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Available Sizes computation
  const availableSizes = React.useMemo(() => {
    if (!product) return [];
    if (product.sizes && product.sizes.length > 0) return product.sizes;
    const raw =
      product.size ||
      product.attributes?.size ||
      product.specifications?.Size ||
      product.specifications?.size;
    if (!raw) return [];
    if (raw.includes(',')) {
      return raw.split(',').map((s) => s.trim()).filter(Boolean);
    }
    return [raw.trim()];
  }, [product]);

  const [selectedSizeState, setSelectedSizeState] = useState<string>('');
  const selectedSize = selectedSizeState || (availableSizes.length > 0 ? availableSizes[0] : '');
  const setSelectedSize = setSelectedSizeState;

  // Review submission state
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  // Seller & Shop resolution for multi-vendor navigation
  const sellerShop = React.useMemo(() => {
    if (!product) return null;
    return shops.find(
      (s) =>
        (product.shopId && s.id === product.shopId) ||
        (product.shopSlug && s.slug === product.shopSlug) ||
        (product.brand && s.name.toLowerCase() === product.brand.toLowerCase())
    ) || null;
  }, [product, shops]);

  const targetShopSlug = product?.shopSlug || sellerShop?.slug || (product?.brand ? product.brand.toLowerCase().replace(/[^a-z0-9]+/g, '-') : 'megabazar');
  const targetShopName = product?.shopName || sellerShop?.name || product?.brand || 'Mega Bazar Store';

  if (isFetchingRemote && !product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-28 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-inner animate-pulse">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
        <h2 className="text-xl font-black text-slate-800">Loading Product Details...</h2>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Please wait while we load the latest product images and specifications.
        </p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Package className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-800">Product Not Found</h2>
        <p className="text-sm text-slate-500 max-w-md mx-auto">
          The product you are looking for does not exist or may have been removed from the catalog.
        </p>
        <Link
          href="/products"
          className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Store Catalog
        </Link>
      </div>
    );
  }

  const fallbackPlaceholder = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80';
  const images = product.images && product.images.length > 0 && product.images.some(img => img && img.trim().length > 0)
    ? product.images.filter(img => img && img.trim().length > 0)
    : [fallbackPlaceholder];

  const currentImage = images[selectedImageIndex] || images[0] || fallbackPlaceholder;
  const inWishlist = isInWishlist(product.id);
  const discount =
    product.discountPercentage ||
    calculateDiscount(product.originalPrice, product.price);
  const productReviews = reviews.filter(
    (r) => r.productId === product.id && r.status === 'approved'
  );

  // Related products in the same category
  const relatedProducts = products
    .filter(
      (p) =>
        p.category === product.category &&
        p.id !== product.id &&
        p.status === 'active'
    )
    .slice(0, 4);

  // Next / Previous Image Navigation
  const handlePrevImage = () => {
    setSelectedImageIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    setSelectedImageIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  // Canonical share URL using real production domain
  const shareUrl = `${((typeof window !== 'undefined' ? window.location.origin : 'https://megabazar.live')).replace(/\/$/, '')}/product/${product.id}`;
  const shareTitle = product.name;
  const formattedPrice = formatCurrency(product.price, settings.currency);
  const shareDescription =
    product.shortDescription ||
    (product.description
      ? product.description.replace(/<[^>]*>?/gm, '').slice(0, 140)
      : 'Shop premium quality at Mega Bazar Pakistan!');

  // Rich WhatsApp text template
  const whatsappShareText = `🛍️ ${product.name}\n\n💰 Price: ${formattedPrice}\n\n${shareDescription}\n\n🛒 Shop now at Mega Bazar:\n${shareUrl}`;

  // Dedicated WhatsApp Direct Order Link (Strict Pakistani international formatting: 923XXXXXXXXX)
  const targetWhatsApp = product.whatsappNumber || product.sellerWhatsapp || '';
  const currentSizeChoice = selectedSize || (availableSizes.length > 0 ? availableSizes[0] : '');
  const sizeLine = currentSizeChoice ? `\n📏 *Size:* ${currentSizeChoice}` : '';
  const whatsappOrderMessage = `Hello! I would like to order this item on Mega Bazar:\n\n📦 *${product.name}*${sizeLine}\n💰 *Price:* ${formattedPrice}\n🔢 *SKU:* ${product.sku}\n🔗 *Product Link:* ${shareUrl}\n\nPlease share delivery and cash on delivery details.`;
  const whatsappOrderUrl = createWhatsAppLink(targetWhatsApp, whatsappOrderMessage);
  const displayWhatsApp = formatDisplayPakistaniPhone(targetWhatsApp);

  // Native share text template
  const nativeShareText = `🛍️ ${product.name}\n💰 Price: ${formattedPrice}\n${shareDescription}\n\n🛒 Shop now at Mega Bazar:`;

  // Open professional share modal
  const handleShareClick = () => {
    setIsShareModalOpen(true);
  };

  // Native Web Share API trigger
  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: nativeShareText,
          url: shareUrl,
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.error('Native share error:', err);
        }
      }
    } else {
      handleCopyLink();
    }
  };

  const handleCopyLink = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 3000);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity, currentSizeChoice || undefined);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, currentSizeChoice || undefined);
    router.push('/checkout');
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    createReview({
      productId: product.id,
      productName: product.name,
      customerId: user?.uid || 'guest-reviewer',
      customerName: user?.displayName || 'Mega Bazar Customer',
      customerEmail: user?.email,
      rating: newRating,
      comment: newComment.trim(),
      isVerifiedPurchase: false,
      status: 'approved',
    });

    setNewComment('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 4000);
  };

  return (
    <div className="py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium overflow-x-auto whitespace-nowrap pb-1">
          <Link href="/" className="hover:text-blue-600 transition-colors">
            Home
          </Link>
          <span>/</span>
          <Link href="/products" className="hover:text-blue-600 transition-colors">
            Products
          </Link>
          <span>/</span>
          <Link
            href={`/category/${product.category.toLowerCase().replace(/\s+/g, '-')}`}
            className="hover:text-blue-600 transition-colors"
          >
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-slate-900 font-bold truncate max-w-xs">
            {product.name}
          </span>
        </nav>

        {/* Main Product Layout: Gallery (Left) & Purchasing Info (Right) */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
          {/* ========================================= */}
          {/* LEFT: Multi-Image Gallery with 3+ Views */}
          {/* ========================================= */}
          <div className="lg:col-span-7 space-y-4">
            {/* Primary Large Image Box */}
            <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-slate-50 border border-slate-200/90 shadow-xs group">
              <SafeImage
                src={currentImage}
                fallbackSrc={fallbackPlaceholder}
                alt={product.imageAltText || product.name}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 650px"
                className="object-contain p-4 transition-transform duration-300 group-hover:scale-105"
              />

              {/* Discount Tag */}
              {discount > 0 && (
                <div className="absolute top-4 left-4 z-10 bg-rose-600 text-white text-xs font-black px-3 py-1 rounded-xl shadow-md">
                  -{discount}% OFF
                </div>
              )}

              {/* Badges (Featured / Flash Deal) */}
              <div className="absolute top-4 right-4 z-10 flex flex-col gap-1.5 items-end">
                {product.isFlashDeal && (
                  <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-2.5 py-1 rounded-lg shadow-sm">
                    ⚡ FLASH DEAL
                  </span>
                )}
                {product.isBestSeller && (
                  <span className="bg-slate-900 text-white text-[10px] font-black px-2.5 py-1 rounded-lg shadow-sm">
                    ★ BEST SELLER
                  </span>
                )}
              </div>

              {/* Prev / Next Image Buttons */}
              {images.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={handlePrevImage}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-white text-slate-800 flex items-center justify-center shadow-md transition-all opacity-80 sm:opacity-0 group-hover:opacity-100 cursor-pointer"
                    aria-label="Previous photo"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    onClick={handleNextImage}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-white text-slate-800 flex items-center justify-center shadow-md transition-all opacity-80 sm:opacity-0 group-hover:opacity-100 cursor-pointer"
                    aria-label="Next photo"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Bottom Right Controls (Zoom + Count) */}
              <div className="absolute bottom-4 right-4 z-10 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-slate-900/60 backdrop-blur-xs text-white text-xs font-mono font-bold">
                  {selectedImageIndex + 1} / {images.length}
                </span>

                <button
                  type="button"
                  onClick={() => setIsZoomOpen(true)}
                  className="px-3 py-1 rounded-lg bg-white/90 hover:bg-white text-slate-800 text-xs font-bold flex items-center gap-1 shadow-sm transition-colors cursor-pointer"
                  title="Inspect Full Size Photo"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Zoom</span>
                </button>
              </div>
            </div>

            {/* Thumbnail Strip (Click to change main image) */}
            {images.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none pt-1">
                {images.map((imgUrl, idx) => {
                  const isSelected = idx === selectedImageIndex;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`relative w-20 h-20 sm:w-22 sm:h-22 rounded-2xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer bg-slate-50 ${
                        isSelected
                          ? 'border-blue-600 ring-2 ring-blue-500/30 scale-102 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 opacity-75 hover:opacity-100'
                      }`}
                    >
                      <SafeImage
                        src={imgUrl}
                        fallbackSrc={fallbackPlaceholder}
                        alt={`${product.name} view ${idx + 1}`}
                        fill
                        sizes="90px"
                        className="object-cover p-1"
                      />
                      {idx === 0 && (
                        <span className="absolute bottom-1 left-1 bg-amber-500 text-slate-950 text-[9px] font-black px-1 rounded shadow-xs">
                          Main
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* ========================================= */}
          {/* RIGHT: Product Details & Buying Actions   */}
          {/* ========================================= */}
          <div className="lg:col-span-5 space-y-6">
            {/* Header: Brand, Title, Rating */}
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                  {product.brand || 'Mega Brand'}
                </span>

                <span className="text-xs text-slate-400 font-mono">
                  SKU: {product.sku}
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-snug">
                {product.name}
              </h1>

              {/* Rating & Review summary */}
              <div className="flex items-center gap-3 pt-1">
                <div className="flex items-center gap-1 text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.round(product.reviewCount > 0 ? product.rating : 0)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-200'
                      }`}
                    />
                  ))}
                  <span className="text-xs font-bold text-slate-700 ml-1">
                    {product.reviewCount > 0 ? product.rating.toFixed(1) : 'No reviews yet'}
                  </span>
                </div>

                <span className="text-slate-300">•</span>

                <button
                  type="button"
                  onClick={() => setActiveTab('reviews')}
                  className="text-xs font-semibold text-blue-600 hover:underline"
                >
                  {productReviews.length} Reviews
                </button>
              </div>
            </div>

            {/* Short Tagline / Summary */}
            {product.shortDescription && (
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                {product.shortDescription}
              </p>
            )}

            {/* Pricing Area */}
            <div className="p-5 bg-blue-50/50 rounded-3xl border border-blue-100 space-y-2">
              <div className="flex items-baseline gap-3 flex-wrap">
                <span className="text-3xl sm:text-4xl font-black text-blue-700 tracking-tight">
                  {formatCurrency(product.price, settings.currency)}
                </span>

                {product.originalPrice > product.price && (
                  <span className="text-base text-slate-400 line-through font-medium">
                    {formatCurrency(product.originalPrice, settings.currency)}
                  </span>
                )}

                {discount > 0 && (
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-xs font-black">
                    Save {discount}%
                  </span>
                )}
              </div>

              {/* Stock status indicator */}
              <div className="flex items-center gap-2 pt-1 text-xs">
                {product.stock > 0 ? (
                  <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>In Stock — ({product.stock} available ready for dispatch)</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-rose-600 font-bold">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    <span>Currently Out of Stock</span>
                  </div>
                )}
              </div>
            </div>

            {/* SELLER STOREFRONT BANNER & VISIT SHOP BUTTON */}
            <div className="p-4 bg-gradient-to-r from-blue-50/80 via-white to-indigo-50/80 rounded-3xl border border-blue-200/80 shadow-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-12 h-12 rounded-2xl bg-white border border-blue-200 p-1 flex items-center justify-center shrink-0 shadow-2xs overflow-hidden">
                  {sellerShop?.logoUrl ? (
                    <img
                      src={sellerShop.logoUrl}
                      alt={targetShopName}
                      className="w-full h-full object-contain rounded-xl"
                    />
                  ) : (
                    <div className="w-full h-full bg-blue-100 text-blue-700 rounded-xl flex items-center justify-center font-black text-base">
                      {targetShopName.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs sm:text-sm font-black text-slate-900 truncate">
                      {targetShopName}
                    </span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 fill-blue-600 text-white shrink-0" />
                  </div>
                  <p className="text-[11px] text-slate-500 truncate">
                    {sellerShop?.city ? `Merchant in ${sellerShop.city}` : 'Mega Bazar Verified Merchant'}
                    {sellerShop?.ownerName ? ` · ${sellerShop.ownerName}` : ''}
                  </p>
                </div>
              </div>

              <Link
                href={`/shop/${targetShopSlug}`}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <span>Visit Shop</span>
                <ArrowRight size={14} />
              </Link>
            </div>

            {/* Key Specifications Highlights */}
            {product.specifications && (
              <div className="grid grid-cols-2 gap-2.5 text-xs">
                {product.specifications.Warranty && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-400 block text-[10px] font-bold uppercase">
                      Warranty
                    </span>
                    <span className="font-bold text-slate-800">
                      {product.specifications.Warranty}
                    </span>
                  </div>
                )}
                {product.specifications.Authenticity && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-400 block text-[10px] font-bold uppercase">
                      Guarantee
                    </span>
                    <span className="font-bold text-slate-800">
                      {product.specifications.Authenticity}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Size Selector / Available Size Badge */}
            {availableSizes.length > 0 && (
              <div className="space-y-2 pt-2 pb-1 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <span>Available Size:</span>
                  </span>
                  <span className="font-black text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-lg border border-blue-100 text-xs">
                    {selectedSize || availableSizes[0]}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2 pt-0.5">
                  {availableSizes.map((sz) => {
                    const isSelected = (selectedSize || availableSizes[0]) === sz;
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setSelectedSize(sz)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity Selector & Action Buttons */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3">
                <div className="flex items-center border border-slate-200 rounded-2xl bg-white p-1">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    disabled={quantity <= 1}
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>

                  <span className="w-12 text-center text-sm font-black text-slate-900">
                    {quantity}
                  </span>

                  <button
                    type="button"
                    onClick={() =>
                      setQuantity((q) => Math.min(product.stock || 99, q + 1))
                    }
                    disabled={quantity >= product.stock}
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Wishlist Button */}
                <button
                  type="button"
                  onClick={() => toggleWishlist(product.id)}
                  className={`w-12 h-12 rounded-2xl border flex items-center justify-center transition-all cursor-pointer ${
                    inWishlist
                      ? 'bg-rose-50 border-rose-200 text-rose-600'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-500'
                  }`}
                  title={inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
                >
                  <Heart
                    className={`w-5 h-5 ${inWishlist ? 'fill-rose-500' : ''}`}
                  />
                </button>

                {/* Professional Share Product Button */}
                <button
                  type="button"
                  onClick={handleShareClick}
                  className="flex-1 py-3 px-4 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
                  title="Share Product Link"
                >
                  <Share2 className="w-4 h-4 text-blue-600" />
                  <span>Share Product</span>
                </button>
              </div>

              {/* Purchase & Seller WhatsApp Action Area */}
              <div className="flex items-center gap-2.5 sm:gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  disabled={product.stock <= 0}
                  className="flex-1 py-3.5 px-4 sm:px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-98 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4 shrink-0" />
                  <span>Add to Cart</span>
                </button>

                <button
                  type="button"
                  onClick={handleBuyNow}
                  disabled={product.stock <= 0}
                  className="flex-1 py-3.5 px-4 sm:px-6 rounded-2xl bg-slate-900 hover:bg-black active:scale-98 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-slate-900/20 transition-all cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Buy Now</span>
                </button>

                {/* Compact, Icon-Only Official WhatsApp Button (Zero Text, Direct Seller Chat) */}
                {formatPakistaniWhatsAppNumber(targetWhatsApp).isValid && <a
                  href={whatsappOrderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Direct WhatsApp Order with Seller"
                  title={`Chat on WhatsApp with Seller (${displayWhatsApp})`}
                  className="h-12 w-12 sm:h-[50px] sm:w-[50px] shrink-0 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] active:scale-95 text-white flex items-center justify-center shadow-md shadow-[#25D366]/30 hover:shadow-lg hover:shadow-[#25D366]/40 transition-all cursor-pointer group"
                >
                  <MessageCircle className="w-6 h-6 sm:w-7 sm:h-7 text-white fill-current group-hover:scale-110 transition-transform" />
                </a>}
              </div>
            </div>

            {/* Confidence & Delivery Guarantees */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2.5 text-xs text-slate-600">
              <div className="flex items-center gap-2.5">
                <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  <strong>Delivery</strong> &bull; Check availability, charges and preparation time with the seller.
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Payment</strong> &bull; Confirm the available payment methods at checkout.
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <RotateCcw className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>Returns &amp; warranty</strong> &bull; Confirm the applicable terms before ordering.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabbed Content: Description, Specs, Reviews */}
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="flex border-b border-slate-200 overflow-x-auto scrollbar-none bg-slate-50/60">
            <button
              onClick={() => setActiveTab('description')}
              className={`px-6 py-4 font-bold text-xs sm:text-sm border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'description'
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              Product Description
            </button>

            <button
              onClick={() => setActiveTab('specifications')}
              className={`px-6 py-4 font-bold text-xs sm:text-sm border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'specifications'
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              Specifications &amp; Features
            </button>

            <button
              onClick={() => setActiveTab('reviews')}
              className={`px-6 py-4 font-bold text-xs sm:text-sm border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'reviews'
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              Customer Reviews ({productReviews.length})
            </button>
          </div>

          <div className="p-6 sm:p-8">
            {activeTab === 'description' && (
              <div className="space-y-4 max-w-3xl">
                <h3 className="text-base font-extrabold text-slate-900">
                  About this Product
                </h3>
                <div className="text-slate-700 text-xs sm:text-sm leading-relaxed whitespace-pre-line space-y-3">
                  {product.description}
                </div>
              </div>
            )}

            {activeTab === 'specifications' && (
              <div className="space-y-6 max-w-3xl">
                <h3 className="text-base font-extrabold text-slate-900">
                  Technical Specifications
                </h3>

                <div className="divide-y divide-slate-100 border border-slate-100 rounded-2xl overflow-hidden text-xs">
                  {Object.entries({
                    Brand: product.brand || 'Mega Brand',
                    SKU: product.sku,
                    Category: product.category,
                    ...(product.specifications || {}),
                    ...(product.attributes || {}),
                  }).map(([key, value]) => {
                    if (!value) return null;
                    return (
                      <div
                        key={key}
                        className="grid grid-cols-3 p-3.5 hover:bg-slate-50 transition-colors"
                      >
                        <span className="font-bold text-slate-500 capitalize">
                          {key}
                        </span>
                        <span className="col-span-2 text-slate-900 font-semibold">
                          {String(value)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-8 max-w-3xl">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <h3 className="text-base font-extrabold text-slate-900">
                    Buyer Feedback ({productReviews.length})
                  </h3>
                </div>

                {/* Submit New Review Form */}
                <form
                  onSubmit={handleReviewSubmit}
                  className="p-5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3"
                >
                  <span className="text-xs font-bold text-slate-900 block">
                    Write a Review
                  </span>

                  <div className="flex items-center gap-1">
                    <span className="text-xs text-slate-500 mr-2">Your Rating:</span>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewRating(star)}
                        className="p-1 hover:scale-110 transition-transform cursor-pointer"
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= newRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>

                  <textarea
                    rows={3}
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Share your experience regarding quality, shipping speed, packaging..."
                    required
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-blue-500 outline-hidden"
                  />

                  <div className="flex justify-between items-center">
                    {reviewSubmitted ? (
                      <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Review submitted! Thank you.
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">
                        Reviews are reviewed before public display. Purchase verification is not connected yet.
                      </span>
                    )}

                    <button
                      type="submit"
                      className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
                    >
                      Post Review
                    </button>
                  </div>
                </form>

                {/* Reviews List */}
                <div className="space-y-4">
                  {productReviews.length === 0 ? (
                    <p className="text-xs text-slate-500 italic py-4">
                      No customer reviews yet. Be the first to review this product!
                    </p>
                  ) : (
                    productReviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="p-4 rounded-2xl bg-white border border-slate-100 shadow-2xs space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">
                            {rev.customerName}
                          </span>
                          <div className="flex text-amber-400">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3.5 h-3.5 ${
                                  i < rev.rating
                                    ? 'fill-amber-400 text-amber-400'
                                    : 'text-slate-200'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {rev.comment}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related Products Carousel / Grid */}
        {relatedProducts.length > 0 && (
          <div className="space-y-5 pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">
                  Similar Products in {product.category}
                </h3>
                <p className="text-xs text-slate-500">
                  Customers who viewed this item also explored these deals.
                </p>
              </div>

              <Link
                href={`/category/${product.category.toLowerCase().replace(/\s+/g, '-')}`}
                className="text-xs font-bold text-blue-600 hover:underline"
              >
                View all &rarr;
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ========================================= */}
      {/* FULL-SCREEN ZOOM LIGHTBOX MODAL           */}
      {/* ========================================= */}
      {isZoomOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setIsZoomOpen(false)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] w-full bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 px-2 text-white border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300">
                {product.name} — Photo {selectedImageIndex + 1} of {images.length}
              </span>
              <button
                type="button"
                onClick={() => setIsZoomOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative w-full h-[70vh] flex items-center justify-center overflow-hidden rounded-2xl bg-black/60 my-2">
              <Image
                src={currentImage}
                alt={`${product.name} zoom`}
                fill
                unoptimized
                className="object-contain p-2"
                referrerPolicy="no-referrer"
              />

              {images.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={handlePrevImage}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center cursor-pointer transition-colors"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    type="button"
                    onClick={handleNextImage}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center cursor-pointer transition-colors"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </>
              )}
            </div>

            {images.length > 1 && (
              <div className="flex items-center justify-center gap-2 overflow-x-auto pt-2">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImageIndex(i)}
                    className={`w-14 h-14 relative rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                      i === selectedImageIndex
                        ? 'border-blue-500 scale-105'
                        : 'border-slate-700 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <Image
                      src={img}
                      alt="Thumbnail"
                      fill
                      unoptimized
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================= */}
      {/* REDESIGNED PROFESSIONAL SOCIAL SHARE MODAL*/}
      {/* ========================================= */}
      {isShareModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto"
          onClick={() => setIsShareModalOpen(false)}
        >
          <div
            className="relative max-w-lg w-full bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 space-y-4 sm:space-y-5 animate-scale-up my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Share Product
                  </h3>
                  <p className="text-xs text-slate-500">
                    Share this product with friends or across social media
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Social Media Card Visual Preview */}
            <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                  Social Preview Card
                </span>
                <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                  Mega Bazar
                </span>
              </div>

              {/* Card Container */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="relative aspect-16/9 w-full bg-slate-100 overflow-hidden">
                  <Image
                    src={currentImage}
                    alt={product.name}
                    fill
                    unoptimized
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2.5 right-2.5 bg-slate-900/85 backdrop-blur-xs text-white text-xs font-black px-2.5 py-1 rounded-lg shadow-sm">
                    {formattedPrice}
                  </div>
                </div>
                <div className="p-3.5 space-y-1">
                  <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                    <Globe className="w-3 h-3 text-blue-500" />
                    <span>megabazar.live</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 line-clamp-2 leading-snug">
                    {product.name}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {shareDescription}
                  </p>
                </div>
              </div>
            </div>

            {/* Primary WhatsApp Action Bar */}
            <a
              href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                whatsappShareText
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all shadow-md hover:shadow-lg cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 text-white fill-current" />
              <span>Share to WhatsApp</span>
            </a>

            {/* Social Share Grid */}
            <div className="grid grid-cols-4 gap-2">
              {/* Facebook */}
              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                  shareUrl
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-2xl bg-blue-50 hover:bg-blue-100 text-blue-700 flex flex-col items-center justify-center gap-1.5 transition-colors group cursor-pointer"
              >
                <Facebook className="w-5 h-5 text-blue-600 group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-bold">Facebook</span>
              </a>

              {/* Telegram */}
              <a
                href={`https://t.me/share/url?url=${encodeURIComponent(
                  shareUrl
                )}&text=${encodeURIComponent(
                  `🛍️ ${product.name} - ${formattedPrice}\n${shareDescription}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-2xl bg-sky-50 hover:bg-sky-100 text-sky-700 flex flex-col items-center justify-center gap-1.5 transition-colors group cursor-pointer"
              >
                <Send className="w-5 h-5 text-sky-600 group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-bold">Telegram</span>
              </a>

              {/* X / Twitter */}
              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(
                  `🛍️ ${product.name} - ${formattedPrice}\n\nShop at Mega Bazar:`
                )}&url=${encodeURIComponent(shareUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 flex flex-col items-center justify-center gap-1.5 transition-colors group cursor-pointer"
              >
                <Twitter className="w-5 h-5 text-slate-800 group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-bold">X (Twitter)</span>
              </a>

              {/* Email */}
              <a
                href={`mailto:?subject=${encodeURIComponent(
                  `🛍️ ${product.name} on Mega Bazar`
                )}&body=${encodeURIComponent(
                  `Hi,\n\nI thought you might like this product on Mega Bazar:\n\n${product.name}\nPrice: ${formattedPrice}\n\n${shareDescription}\n\nCheck it out here:\n${shareUrl}`
                )}`}
                className="p-3 rounded-2xl bg-purple-50 hover:bg-purple-100 text-purple-700 flex flex-col items-center justify-center gap-1.5 transition-colors group cursor-pointer"
              >
                <Mail className="w-5 h-5 text-purple-600 group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-bold">Email</span>
              </a>
            </div>

            {/* Native Share / More Apps Button */}
            <button
              type="button"
              onClick={handleNativeShare}
              className="w-full py-2.5 px-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-blue-600" />
              <span>More Sharing Apps (Native Share)</span>
            </button>

            {/* Direct Copy Link Input Bar */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs font-bold text-slate-700 block">
                Direct Product Page Link
              </label>
              <div className="flex items-center gap-2 p-1.5 bg-slate-50 border border-slate-200 rounded-2xl">
                <input
                  type="text"
                  readOnly
                  value={shareUrl}
                  className="flex-1 bg-transparent px-2.5 text-xs font-mono text-slate-700 outline-hidden truncate select-all"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                    copiedShare
                      ? 'bg-emerald-600 text-white shadow-emerald-200'
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                >
                  {copiedShare ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Product link copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>
              </div>
              {copiedShare && (
                <p className="text-xs text-emerald-600 font-bold pt-0.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Product link copied! Ready to paste and share.</span>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
