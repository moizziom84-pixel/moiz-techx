'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import {
  Bell,
  CheckCircle2,
  XCircle,
  Clock,
  Store,
  ShoppingBag,
  MessageSquare,
  AlertCircle,
  Check,
  X,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';

export function ShopNotifications({ className = '' }: { className?: string }) {
  const {
    user,
    isAdmin,
    notifications,
    shops,
    markNotificationAsRead,
    approveShop,
    rejectShop,
  } = useStore();

  const [isOpen, setIsOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string>('');

  if (!user) return null;

  // Find shops that need approval if admin
  const pendingShops = isAdmin ? shops.filter((s) => s.status === 'Pending') : [];

  const unreadCount = notifications.filter((n) => !n.read).length + (isAdmin ? pendingShops.length : 0);

  const displayNotifications = notifications.filter((n) => {
    if (filter === 'unread') return !n.read;
    return true;
  });

  const handleApproveShop = async (shopId: string) => {
    setProcessingId(shopId);
    setActionFeedback('');
    try {
      await approveShop(shopId);
      setActionFeedback('Shop has been approved and is now live!');
    } catch (err: any) {
      setActionFeedback(err.message || 'Approval failed.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectShop = async (shopId: string) => {
    setProcessingId(shopId);
    setActionFeedback('');
    try {
      await rejectShop(shopId, 'Application did not meet marketplace documentation guidelines.');
      setActionFeedback('Shop application was rejected.');
    } catch (err: any) {
      setActionFeedback(err.message || 'Rejection failed.');
    } finally {
      setProcessingId(null);
    }
  };

  const markAllAsRead = () => {
    notifications.forEach((n) => {
      if (!n.read) markNotificationAsRead(n.id);
    });
  };

  return (
    <div className={`relative ${className}`}>
      {/* Trigger Bell Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-slate-700 hover:text-blue-600 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer"
        aria-label="Notifications"
        title="View Notifications"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-rose-600 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-xs animate-scale">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Notifications Drawer / Dropdown */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/40 backdrop-blur-2xs">
          <div
            className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden animate-slide-left border-l border-slate-200"
            role="dialog"
            aria-modal="true"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Bell size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Notifications</h3>
                  <p className="text-[11px] text-slate-500">
                    {unreadCount > 0 ? `${unreadCount} unread alert${unreadCount > 1 ? 's' : ''}` : 'All caught up'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-xs text-blue-600 hover:underline font-bold px-2 py-1"
                  >
                    Mark all read
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="px-4 py-2 border-b border-slate-100 bg-white flex items-center gap-2 text-xs">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1 rounded-full font-bold transition-colors cursor-pointer ${
                  filter === 'all' ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter('unread')}
                className={`px-3 py-1 rounded-full font-bold transition-colors cursor-pointer ${
                  filter === 'unread' ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Unread ({unreadCount})
              </button>
            </div>

            {actionFeedback && (
              <div className="mx-4 mt-3 p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 size={15} className="text-blue-600 shrink-0" />
                <span>{actionFeedback}</span>
              </div>
            )}

            {/* Content List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 divide-y divide-slate-100">
              {/* ADMIN ONLY: Actionable Shop Approval Requests */}
              {isAdmin && pendingShops.length > 0 && (
                <div className="space-y-3 pb-3">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                    Pending Shop Applications ({pendingShops.length})
                  </span>

                  {pendingShops.map((ps) => (
                    <div
                      key={ps.id}
                      className="p-4 rounded-2xl bg-gradient-to-br from-amber-50/60 to-orange-50/60 border border-amber-200/80 shadow-2xs space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-12 h-12 rounded-xl bg-white border border-amber-200 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                          {ps.logoUrl ? (
                            <img src={ps.logoUrl} alt={ps.name} className="w-full h-full object-contain rounded-lg" />
                          ) : (
                            <Store className="w-6 h-6 text-amber-600" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="font-extrabold text-xs text-slate-900 truncate">{ps.name}</h4>
                          <p className="text-[11px] text-slate-600">
                            Merchant: <strong>{ps.ownerName}</strong>
                          </p>
                          <p className="text-[11px] text-slate-500">
                            {ps.city}{ps.area ? ` · ${ps.area}` : ''} ({ps.category})
                          </p>
                        </div>
                      </div>

                      {ps.description && (
                        <p className="text-[11px] text-slate-600 bg-white/70 p-2 rounded-xl border border-amber-100 line-clamp-2">
                          {ps.description}
                        </p>
                      )}

                      {/* Authorized Administrator Approve & Reject Buttons */}
                      <div className="pt-1 flex items-center gap-2">
                        <button
                          disabled={processingId === ps.id}
                          onClick={() => handleApproveShop(ps.id)}
                          className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
                        >
                          <Check size={14} />
                          <span>Approve Shop</span>
                        </button>
                        <button
                          disabled={processingId === ps.id}
                          onClick={() => handleRejectShop(ps.id)}
                          className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold border border-rose-200 transition-colors disabled:opacity-50 cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Standard Notifications */}
              {displayNotifications.length > 0 ? (
                displayNotifications.map((item) => {
                  const isRead = item.read;
                  return (
                    <div
                      key={item.id}
                      className={`pt-3 flex items-start gap-3 transition-colors ${
                        !isRead ? 'bg-blue-50/40 -mx-2 px-2 py-2 rounded-xl' : ''
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                          item.type === 'order'
                            ? 'bg-emerald-100 text-emerald-700'
                            : item.type === 'review'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {item.type === 'order' ? (
                          <ShoppingBag size={15} />
                        ) : item.type === 'review' ? (
                          <MessageSquare size={15} />
                        ) : (
                          <Store size={15} />
                        )}
                      </div>

                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs font-extrabold text-slate-900 truncate">
                            {item.title}
                          </h4>
                          {!isRead && (
                            <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                          )}
                        </div>

                        <p className="text-xs text-slate-600 leading-relaxed">{item.message}</p>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] text-slate-400">
                            {new Date(item.createdAt).toLocaleDateString(undefined, {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>

                          <div className="flex items-center gap-2">
                            {item.link && (
                              <Link
                                href={item.link}
                                onClick={() => {
                                  markNotificationAsRead(item.id);
                                  setIsOpen(false);
                                }}
                                className="text-xs text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                              >
                                <span>Open</span>
                                <ChevronRight size={13} />
                              </Link>
                            )}
                            {!isRead && (
                              <button
                                onClick={() => markNotificationAsRead(item.id)}
                                className="text-[11px] text-slate-500 hover:text-slate-800"
                              >
                                Mark read
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="py-16 text-center space-y-2">
                  <Bell size={36} className="mx-auto text-slate-300" />
                  <p className="text-xs font-bold text-slate-700">No notifications to display</p>
                  <p className="text-[11px] text-slate-400">
                    Important order updates and shop notices will be delivered here.
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
              Mega Bazar 2.0 Real-time Notifications
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
