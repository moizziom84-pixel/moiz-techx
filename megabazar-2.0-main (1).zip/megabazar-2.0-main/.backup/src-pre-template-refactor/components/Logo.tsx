'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ShoppingBag } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  compactOnMobile?: boolean;
  inverted?: boolean;
  className?: string;
  href?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showTagline = true,
  compactOnMobile = false,
  inverted = false,
  className = '',
  href = '/',
}) => {
  const [imageFailed, setImageFailed] = useState(false);

  const iconSizes = {
    sm: 'w-10 h-10',
    md: 'w-12 h-12',
    lg: 'w-14 h-14',
    xl: 'w-16 h-16',
  };

  const titleSizes = {
    sm: 'text-base font-extrabold tracking-tight',
    md: 'text-xl font-black tracking-tight',
    lg: 'text-2xl font-black tracking-tight',
    xl: 'text-3xl font-black tracking-tight',
  };

  const taglineSizes = {
    sm: 'text-[9px]',
    md: 'text-[11px]',
    lg: 'text-xs',
    xl: 'text-sm',
  };
  const iconSize = compactOnMobile && size === 'md' ? 'w-10 h-10 sm:w-12 sm:h-12' : iconSizes[size];
  const titleSize = compactOnMobile && size === 'md' ? 'text-base sm:text-xl font-black tracking-tight' : titleSizes[size];

  const content = (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Icon: Logo Image with Fallback Monogram */}
      <div
        className={`${iconSize} relative flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-105`}
      >
        {!imageFailed ? (
          <Image
            src="/brand-mark-v3.png"
            alt="Mega Bazar"
            width={64}
            height={64}
            className="w-full h-full object-contain drop-shadow-xs"
            priority
            unoptimized
            onError={() => setImageFailed(true)}
            referrerPolicy="no-referrer"
          />
        ) : (
          <div
            className={`w-full h-full rounded-2xl flex items-center justify-center font-black shadow-md ${
              inverted
                ? 'bg-blue-600 text-white border border-blue-400/40'
                : 'bg-gradient-to-tr from-blue-700 to-blue-500 text-white shadow-blue-500/20'
            }`}
          >
            <ShoppingBag className="w-1/2 h-1/2" />
          </div>
        )}
      </div>

      {/* Brand Text */}
      <div className="flex flex-col leading-tight">
        <span
          className={`${titleSize} ${
            inverted ? 'text-white' : 'text-slate-900'
          } uppercase tracking-wider flex items-center gap-1`}
        >
          MEGA{' '}
          <span className={inverted ? 'text-amber-300' : 'text-blue-600'}>
            BAZAR
          </span>
        </span>
        {showTagline && (
          <span
            className={`${compactOnMobile ? 'hidden sm:inline ' : ''}${taglineSizes[size]} font-medium ${
              inverted ? 'text-blue-100' : 'text-slate-500'
            } tracking-normal`}
          >
            Many shops. One marketplace.
          </span>
        )}
      </div>
    </div>
  );

  if (href) {
    return (
      <Link href={href} className="group inline-flex items-center">
        {content}
      </Link>
    );
  }

  return content;
};

