'use client';

import React, { useState, useMemo } from 'react';
import Link from '@/router/link';
import { useRouter } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { ProductCard } from '@/components/ProductCard';
import { InstallAppButton } from '@/components/InstallAppButton';
import {
  ArrowRight,
  Store,
  ShieldCheck,
  Search,
  Sparkles,
  CheckCircle2,
  MapPin,
  Star,
  Package,
  Layers,
  Truck,
  Filter,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const router = useRouter();
  const { products, shops, categories } = useStore();
  const [heroSearch, setHeroSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Active public products
  const activeProducts = useMemo(() => {
    return products.filter((p) => p.status === 'active');
  }, [products]);

  // Filtered by category
  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'All') return activeProducts;
    return activeProducts.filter(
      (p) => p.category.toLowerCase() === selectedCategory.toLowerCase()
    );
  }, [activeProducts, selectedCategory]);

  // Approved shops
  const approvedShops = useMemo(() => {
    return shops.filter((s) => s.status === 'Approved');
  }, [shops]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!heroSearch.trim()) return;
    router.push(`/search?q=${encodeURIComponent(heroSearch.trim())}`);
  };

  // Extract unique category names from products
  const productCategories = useMemo(() => {
    const set = new Set<string>();
    activeProducts.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return ['All', ...Array.from(set)];
  }, [activeProducts]);

  return (
    <main className="pb-16 space-y-8 sm:space-y-10 bg-white">
      {/* 1. CLEAN HERO BANNER WITH SEARCH BAR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 sm:pt-6">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 text-white p-6 sm:p-10 shadow-xl">
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none opacity-40" />
          
          <div className="relative z-10 max-w-2xl space-y-3.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-700/60 border border-blue-400/30 text-blue-200 text-xs font-bold">
              <Sparkles size={14} className="text-amber-300" />
              <span>Mega Bazar Pakistan</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight text-white">
              Discover &amp; Shop. <br />
              <span className="text-blue-200">Verified Pakistani Stores.</span>
            </h1>

            {/* In-Hero Search Bar */}
            <form onSubmit={handleSearchSubmit} className="pt-2 flex items-center max-w-lg relative">
              <div className="relative w-full">
                <input
                  type="text"
                  value={heroSearch}
                  onChange={(e) => setHeroSearch(e.target.value)}
                  placeholder="Search products..."
                  className="w-full pl-11 pr-24 py-3 bg-white text-slate-900 rounded-2xl text-xs sm:text-sm font-semibold focus:ring-4 focus:ring-blue-400/30 outline-hidden shadow-lg placeholder:text-slate-400"
                />
                <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-2.5 pt-2">
              <Link
                href="/open-shop"
                className="inline-flex items-center gap-1.5 rounded-xl bg-white text-blue-900 px-4 py-2.5 font-black text-xs hover:bg-blue-50 transition-colors shadow-xs"
              >
                <Store size={15} />
                <span>Open Shop</span>
              </Link>
              <Link
                href="/shops"
                className="inline-flex items-center gap-1.5 rounded-xl bg-blue-800/80 hover:bg-blue-700 border border-blue-400/40 text-white px-4 py-2.5 font-bold text-xs transition-colors"
              >
                <span>{approvedShops.length} Verified Stores</span>
                <ArrowRight size={14} />
              </Link>
              <InstallAppButton />
            </div>
          </div>
        </div>
      </section>

      {/* 2. PRODUCTS SECTION (RIGHT BELOW THE HEADER & HERO) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-blue-600">
                PRODUCTS
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
              Products
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Explore deals from verified stores across Pakistan
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            {productCategories.slice(0, 8).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-6">
            {filteredProducts.map((product, idx) => (
              <ProductCard key={product.id} product={product} priority={idx < 4} />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-12 text-center text-slate-500 space-y-2">
            <Package size={40} className="mx-auto text-slate-300" />
            <p className="font-extrabold text-base text-slate-800">No products here yet</p>
            <p className="text-xs text-slate-500">Be the first to list an item in this category!</p>
            <Link
              href="/seller/products/new"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs mt-2"
            >
              + Add Product
            </Link>
          </div>
        )}
      </section>

      {/* 3. VERIFIED SHOPS SHOWCASE (BELOW THE PRODUCTS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200/90 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-blue-600">
                  SHOPS
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-blue-800">
                  {approvedShops.length} Live
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
                Verified Shops
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Explore stores across Pakistan
              </p>
            </div>

            <Link
              href="/shops"
              className="inline-flex items-center gap-1 text-blue-600 text-xs sm:text-sm font-bold hover:underline"
            >
              <span>View All</span>
              <ArrowRight size={15} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {approvedShops.map((shop) => (
              <Link
                key={shop.id}
                href={`/shop/${shop.slug}`}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs hover:shadow-md hover:border-blue-400 transition-all flex flex-col justify-between group space-y-4"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-slate-200 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                    {shop.logoUrl ? (
                      <img
                        src={shop.logoUrl}
                        alt={shop.name}
                        className="w-full h-full object-contain rounded-xl"
                      />
                    ) : (
                      <Store size={26} className="text-blue-600" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-black text-slate-900 text-sm truncate group-hover:text-blue-600 transition-colors">
                        {shop.name}
                      </h3>
                      {shop.isVerified && (
                        <CheckCircle2 size={14} className="text-blue-600 fill-blue-600 text-white shrink-0" />
                      )}
                    </div>
                    <p className="text-[11px] text-blue-600 font-semibold">{shop.category}</p>
                    <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin size={11} /> {shop.city}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {shop.description || 'Verified merchant storefront with nationwide delivery.'}
                </p>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700 flex items-center gap-1">
                    <Star size={13} className="fill-amber-400 text-amber-500" />
                    {shop.rating || 5.0} Rating
                  </span>
                  <span className="font-bold text-blue-600 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    <span>Visit</span>
                    <ArrowRight size={13} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 4. CLEAN BOTTOM OPEN SHOP CALL TO ACTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white p-6 sm:p-9 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="max-w-xl space-y-1.5">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-[11px] font-bold">
              <Store size={13} /> Sellers
            </span>
            <h3 className="text-xl sm:text-2xl font-black">
              Sell On Mega Bazar
            </h3>
            <p className="text-blue-100 text-xs sm:text-sm leading-relaxed">
              Open your free shop and start selling to customers across Pakistan.
            </p>
          </div>

          <Link
            href="/open-shop"
            className="px-6 py-3 bg-white text-blue-900 hover:bg-blue-50 font-black text-xs sm:text-sm rounded-xl shadow-md transition-colors inline-flex items-center gap-2 shrink-0"
          >
            <span>Open Shop</span>
            <ArrowRight size={15} />
          </Link>
        </div>
      </section>
    </main>
  );
};
