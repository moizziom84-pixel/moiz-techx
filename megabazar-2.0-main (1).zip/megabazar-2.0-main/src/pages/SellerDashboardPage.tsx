'use client';

import React, { useState, useMemo } from 'react';
import { useRouter } from '@/router/navigation';
import Link from '@/router/link';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, createWhatsAppLink } from '@/lib/utils';
import { Product, Order, OrderStatus } from '@/lib/types';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { uploadImageToSupabase } from '@/lib/supabase/storage';
import { MARKETPLACE_CATEGORIES } from '@/lib/marketplace-categories';
import { ShopEditModal } from '@/components/ShopEditModal';
import {
  Store,
  Package,
  ShoppingBag,
  Plus,
  ArrowRight,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Edit2,
  Trash2,
  Phone,
  MessageCircle,
  Eye,
  EyeOff,
  DollarSign,
  TrendingUp,
  Search,
  Filter,
  BarChart3,
  Bell,
  Star,
  Check,
  X,
  ChevronRight,
  Sparkles,
  Layers,
  Share2,
  Settings,
  Menu,
  Upload,
  Camera,
  Image as ImageIcon,
  Loader2,
  MapPin,
  Tag,
} from 'lucide-react';

export const SellerDashboardPage: React.FC = () => {
  const router = useRouter();
  const {
    user,
    shops,
    products,
    orders,
    notifications,
    updateOrderStatus,
    refreshProducts,
    refreshOrders,
    deleteProduct,
    createProduct,
  } = useStore();

  // Find the current logged-in seller's shop
  const currentShop = shops.find(
    (s) =>
      (user?.uid && s.ownerId === user.uid) ||
      (user?.email && s.email.toLowerCase() === user.email.toLowerCase())
  );

  // Active view section: 'products' (default home hub), 'analytics', 'orders', 'notifications'
  const [activeSection, setActiveSection] = useState<'products' | 'analytics' | 'orders' | 'notifications'>('products');

  // 3-Lines Corner Menu Toggle (☰ Menu)
  const [isThreeLineMenuOpen, setIsThreeLineMenuOpen] = useState(false);

  // Shop Edit Modal
  const [isEditShopOpen, setIsEditShopOpen] = useState(false);

  // Products filtering & search
  const [productSearch, setProductSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  // 'all' | 'listed' (active) | 'unlisted' (draft/paused)
  const [listingFilter, setListingFilter] = useState<'all' | 'listed' | 'unlisted'>('all');

  // Deletion modal
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [actionMessage, setActionMessage] = useState('');

  // Orders filtering
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);

  // In-Page Quick Add Product Modal
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('Multi-Vendor Retail');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdOriginalPrice, setNewProdOriginalPrice] = useState('');
  const [newProdStock, setNewProdStock] = useState('10');
  const [newProdCondition, setNewProdCondition] = useState('New');
  const [newProdDescription, setNewProdDescription] = useState('');
  const [newProdStatus, setNewProdStatus] = useState<'active' | 'draft'>('active');
  const [newProdImages, setNewProdImages] = useState<File[]>([]);
  const [newProdPreviews, setNewProdPreviews] = useState<string[]>([]);
  const [isSavingProduct, setIsSavingProduct] = useState(false);
  const [productError, setProductError] = useState('');

  // Products belonging strictly to this seller
  const sellerProducts = useMemo(() => {
    if (!currentShop) return [];
    return products.filter((p) => {
      const matchShopId = p.shopId && p.shopId === currentShop.id;
      const matchShopSlug = p.shopSlug && p.shopSlug === currentShop.slug;
      const matchBrand = p.brand && p.brand.toLowerCase() === currentShop.name.toLowerCase();
      const matchPhone =
        (p.sellerWhatsapp && p.sellerWhatsapp === currentShop.phone) ||
        (p.whatsappNumber && p.whatsappNumber === currentShop.phone);
      return matchShopId || matchShopSlug || matchBrand || matchPhone;
    });
  }, [products, currentShop]);

  // Listed vs Unlisted counts
  const listedProducts = useMemo(() => {
    return sellerProducts.filter((p) => p.status === 'active');
  }, [sellerProducts]);

  const unlistedProducts = useMemo(() => {
    return sellerProducts.filter((p) => p.status !== 'active');
  }, [sellerProducts]);

  // Filtered seller products
  const filteredSellerProducts = useMemo(() => {
    return sellerProducts.filter((p) => {
      const matchesSearch =
        !productSearch.trim() ||
        p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.category.toLowerCase().includes(productSearch.toLowerCase());
      const matchesCat = categoryFilter === 'All' || p.category === categoryFilter;
      const isUnlisted = p.status === 'draft' || (p as any).status === 'paused';
      const matchesListing =
        listingFilter === 'all' ||
        (listingFilter === 'listed' && p.status === 'active') ||
        (listingFilter === 'unlisted' && isUnlisted);
      return matchesSearch && matchesCat && matchesListing;
    });
  }, [sellerProducts, productSearch, categoryFilter, listingFilter]);

  // Orders belonging to this seller
  const sellerOrders = useMemo(() => {
    if (!currentShop) return [];
    const prodIds = new Set(sellerProducts.map((p) => p.id));
    const prodNames = new Set(sellerProducts.map((p) => p.name.toLowerCase()));

    return orders.filter((o) => {
      const hasSellerItem = o.items.some(
        (item) => prodIds.has(item.productId) || prodNames.has(item.name.toLowerCase())
      );
      const hasSellerPhone = o.phone === currentShop.phone;
      return hasSellerItem || hasSellerPhone;
    });
  }, [orders, sellerProducts, currentShop]);

  const filteredSellerOrders = useMemo(() => {
    if (orderStatusFilter === 'all') return sellerOrders;
    return sellerOrders.filter((o) => o.orderStatus === orderStatusFilter);
  }, [sellerOrders, orderStatusFilter]);

  // Analytics Calculations
  const totalSalesPKR = useMemo(() => {
    return sellerOrders.reduce((sum, order) => {
      if (order.orderStatus === 'Cancelled' || order.orderStatus === 'Refunded') return sum;
      return sum + (order.grandTotal || 0);
    }, 0);
  }, [sellerOrders]);

  const totalViews = useMemo(() => {
    return sellerProducts.reduce((sum, p) => sum + (p.views || Math.floor(p.price / 30) + 18), 0);
  }, [sellerProducts]);

  const pendingOrdersCount = sellerOrders.filter(
    (o) => o.orderStatus === 'Pending' || o.orderStatus === 'Confirmed'
  ).length;
  const completedOrdersCount = sellerOrders.filter((o) => o.orderStatus === 'Delivered').length;

  // Seller notifications
  const sellerNotifications = useMemo(() => {
    return notifications.filter((n) =>
      n.link?.includes('seller') ||
      n.title.toLowerCase().includes('shop') ||
      n.title.toLowerCase().includes('order')
    );
  }, [notifications]);

  // 1-Click Toggle between Listed (Live) and Unlisted (Draft/Hidden)
  const handleToggleProductStatus = async (product: Product) => {
    setActionMessage('');
    const willUnlist = product.status === 'active';
    try {
      if (isSupabaseConfigured) {
        if (willUnlist) {
          // Pause / Unlist
          await supabase.rpc('mb_pause_product', { product_id: product.id });
        } else {
          // List Live / Publish
          await supabase
            .from('mb_products')
            .update({ status: 'approved', updated_at: new Date().toISOString() })
            .eq('id', product.id);
        }
        await refreshProducts();
        setActionMessage(
          willUnlist
            ? `Product "${product.name}" is now Unlisted (Hidden from buyers).`
            : `Product "${product.name}" is now Listed (Live on public website)!`
        );
      } else {
        setActionMessage(`Product status updated.`);
      }
    } catch (err: any) {
      setActionMessage(err.message || 'Status change failed.');
    }
  };

  // Delete product
  const handleConfirmDelete = async () => {
    if (!deletingProductId) return;
    setIsDeleting(true);
    setActionMessage('');
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase
          .from('mb_products')
          .delete()
          .eq('id', deletingProductId);
        if (error) {
          await supabase
            .from('mb_products')
            .update({ status: 'paused', updated_at: new Date().toISOString() })
            .eq('id', deletingProductId);
        }
      }
      await deleteProduct(deletingProductId);
      await refreshProducts();
      setActionMessage('Product successfully removed from your catalog.');
      setDeletingProductId(null);
    } catch (err: any) {
      setActionMessage(err.message || 'Could not delete product.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Update order status
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setUpdatingOrderId(orderId);
    try {
      await updateOrderStatus(orderId, status);
      await refreshOrders();
      setActionMessage(`Order marked as ${status}.`);
    } catch (err: any) {
      setActionMessage(err.message || 'Order update failed.');
    } finally {
      setUpdatingOrderId(null);
    }
  };

  // Handle Quick Add Product Image Pick
  const handleAddProductImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setNewProdImages((prev) => [...prev, ...files].slice(0, 8));
    const newPreviews = files.map((f) => URL.createObjectURL(f));
    setNewProdPreviews((prev) => [...prev, ...newPreviews].slice(0, 8));
    setProductError('');
  };

  const handleSaveQuickProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setProductError('');
    if (!currentShop) return;

    const nameClean = newProdName.trim();
    const priceNum = Number(newProdPrice);
    if (!nameClean) {
      setProductError('Please enter a product title.');
      return;
    }
    if (isNaN(priceNum) || priceNum <= 0) {
      setProductError('Please enter a valid price in PKR.');
      return;
    }

    setIsSavingProduct(true);
    try {
      let uploadedImageUrls: string[] = [];

      if (newProdImages.length > 0) {
        for (const file of newProdImages) {
          const res = await uploadImageToSupabase(file, {
            bucket: 'mb-product-images',
            folder: currentShop.slug,
            maxSizeMB: 5,
          });
          if (res.success && res.url) {
            uploadedImageUrls.push(res.url);
          }
        }
      }

      if (uploadedImageUrls.length === 0) {
        uploadedImageUrls = ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80'];
      }

      const origPriceNum = newProdOriginalPrice ? Number(newProdOriginalPrice) : priceNum;
      const discount = origPriceNum > priceNum ? Math.round(((origPriceNum - priceNum) / origPriceNum) * 100) : 0;

      await createProduct({
        name: nameClean,
        slug: `${nameClean.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36)}`,
        sku: `MB-${Date.now().toString(36).toUpperCase()}`,
        brand: currentShop.name,
        category: newProdCategory,
        description: newProdDescription.trim() || `${nameClean} by ${currentShop.name}`,
        price: priceNum,
        originalPrice: origPriceNum,
        discountPercentage: discount,
        stock: Number(newProdStock) || 10,
        lowStockThreshold: 2,
        images: uploadedImageUrls,
        specifications: {},
        tags: [newProdCategory, currentShop.name],
        isFeatured: false,
        isBestSeller: false,
        isFlashDeal: discount > 0,
        rating: 5,
        reviewCount: 0,
        status: newProdStatus,
        whatsappNumber: currentShop.phone,
        sellerWhatsapp: currentShop.phone,
        shopId: currentShop.id,
        shopSlug: currentShop.slug,
        shopName: currentShop.name,
        condition: newProdCondition,
      });

      await refreshProducts();
      setActionMessage(
        newProdStatus === 'active'
          ? `Product "${nameClean}" is now Listed & Live on Mega Bazar!`
          : `Product "${nameClean}" saved as Unlisted (Draft). You can list it anytime!`
      );

      // Reset
      setNewProdName('');
      setNewProdPrice('');
      setNewProdOriginalPrice('');
      setNewProdDescription('');
      setNewProdImages([]);
      setNewProdPreviews([]);
      setIsAddProductOpen(false);
    } catch (err: any) {
      setProductError(err.message || 'Failed to save product.');
    } finally {
      setIsSavingProduct(false);
    }
  };

  // State 1: User not logged in
  if (!user) {
    return (
      <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 shadow-xl border border-slate-200 text-center space-y-6">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Store size={32} />
          </div>
          <h1 className="text-2xl font-black text-slate-900">Seller Profile &amp; Workspace</h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            Please log in with your registered seller account to view your shop profile, catalog, and customer orders.
          </p>
          <div className="space-y-2.5 pt-2">
            <Link
              href="/login?next=/seller/dashboard"
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs transition-colors block text-center"
            >
              Sign In to My Profile →
            </Link>
            <Link
              href="/open-shop"
              className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors block text-center"
            >
              Open New Shop
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // State 2: User logged in but no shop registered yet
  if (!currentShop) {
    return (
      <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 shadow-xl border border-slate-200 text-center space-y-6">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Store size={32} />
          </div>
          <h1 className="text-2xl font-black text-slate-900">Open Your Shop Profile</h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            Signed in as <strong>{user.email}</strong>. You have not registered a shop on Mega Bazar yet. Open your store in 2 minutes to get your own profile, cover banner, and product catalog!
          </p>
          <Link
            href="/open-shop"
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors block text-center"
          >
            Open My Shop Now →
          </Link>
        </div>
      </div>
    );
  }

  const isPending = currentShop.status === 'Pending';
  const isApproved = currentShop.status === 'Approved';

  return (
    <div className="py-6 sm:py-10 bg-slate-50 min-h-screen pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* ACTION BANNER MESSAGE */}
        {actionMessage && (
          <div className="p-4 bg-blue-50 border border-blue-200 text-blue-900 rounded-2xl text-xs font-bold flex items-center justify-between shadow-xs animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={16} className="text-blue-600 shrink-0" />
              <span>{actionMessage}</span>
            </div>
            <button onClick={() => setActionMessage('')} className="text-blue-400 hover:text-blue-700 cursor-pointer">
              <X size={15} />
            </button>
          </div>
        )}

        {/* ========================================================= */}
        {/* 1. TOP PROFILE SECTION: COVER BANNER & LOGO */}
        {/* ========================================================= */}
        <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm relative">
          {/* Cover Banner */}
          <div className="relative h-48 sm:h-64 md:h-72 bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 overflow-hidden group">
            {currentShop.bannerUrl ? (
              <img
                src={currentShop.bannerUrl}
                alt={`${currentShop.name} Banner`}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-white/70 space-y-1">
                <Store className="w-10 h-10 opacity-40" />
                <span className="text-xs font-bold uppercase tracking-wider">Official Storefront Banner</span>
              </div>
            )}

            {/* Quick Banner Edit Button */}
            <button
              type="button"
              onClick={() => setIsEditShopOpen(true)}
              className="absolute top-4 right-16 sm:right-20 bg-slate-900/70 hover:bg-slate-900/90 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl backdrop-blur-md cursor-pointer flex items-center gap-1.5 border border-white/20 transition-all shadow-md z-20"
            >
              <Camera size={13} />
              <span className="hidden sm:inline">Change Banner</span>
            </button>

            {/* 3-LINES CORNER MENU BUTTON (☰ تین لائنیں) */}
            <div className="absolute top-4 right-4 z-30">
              <button
                type="button"
                onClick={() => setIsThreeLineMenuOpen(!isThreeLineMenuOpen)}
                className="w-10 h-10 rounded-xl bg-white/95 hover:bg-white text-slate-800 shadow-lg border border-slate-200 flex items-center justify-center transition-all cursor-pointer hover:scale-105"
                title="Shop Actions Menu · مینیو"
              >
                <Menu className="w-5 h-5 text-blue-700" />
              </button>

              {/* 3-Lines Dropdown Menu */}
              {isThreeLineMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 divide-y divide-slate-100 animate-in fade-in zoom-in-95">
                  <div className="px-4 py-2.5 bg-slate-50/80">
                    <p className="text-[10px] font-black uppercase tracking-wider text-blue-600">Shop Menu</p>
                    <p className="text-xs font-extrabold text-slate-900 truncate">{currentShop.name}</p>
                  </div>

                  <div className="p-1.5 space-y-0.5 text-xs">
                    {/* Analytics Option */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSection('analytics');
                        setIsThreeLineMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-bold transition-colors cursor-pointer ${
                        activeSection === 'analytics' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <BarChart3 className="w-4 h-4 text-blue-600" />
                        <span>Analytics</span>
                      </div>
                      <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded-md font-extrabold">Data</span>
                    </button>

                    {/* Products Option */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSection('products');
                        setIsThreeLineMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-bold transition-colors cursor-pointer ${
                        activeSection === 'products' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-emerald-600" />
                        <span>Products ({sellerProducts.length})</span>
                      </div>
                    </button>

                    {/* Add Product */}
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddProductOpen(true);
                        setIsThreeLineMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl font-extrabold text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-blue-600" />
                      <span>+ Add Product</span>
                    </button>

                    {/* Orders */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSection('orders');
                        setIsThreeLineMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-bold transition-colors cursor-pointer ${
                        activeSection === 'orders' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <ShoppingBag className="w-4 h-4 text-purple-600" />
                        <span>Orders ({sellerOrders.length})</span>
                      </div>
                    </button>

                    {/* Edit Shop */}
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditShopOpen(true);
                        setIsThreeLineMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <Edit2 className="w-4 h-4 text-slate-500" />
                      <span>Edit Shop</span>
                    </button>

                    {/* View Live Storefront */}
                    {isApproved && (
                      <Link
                        href={`/shop/${currentShop.slug}`}
                        onClick={() => setIsThreeLineMenuOpen(false)}
                        className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl font-bold text-slate-700 hover:bg-slate-100 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4 text-slate-500" />
                        <span>Storefront</span>
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Profile Identity Bar (Logo + Info) */}
          <div className="p-5 sm:p-7 flex flex-col md:flex-row items-start md:items-center justify-between gap-5 -mt-12 sm:-mt-16 relative z-10 mx-4 sm:mx-6 mb-5 rounded-2xl bg-white border border-slate-200 shadow-md">
            <div className="flex items-start sm:items-center gap-4 sm:gap-5 w-full md:w-auto">
              {/* Logo / Photo */}
              <div className="relative group shrink-0">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-white border-2 border-slate-200 shadow-md p-1.5 flex items-center justify-center overflow-hidden">
                  {currentShop.logoUrl ? (
                    <img
                      src={currentShop.logoUrl}
                      alt={currentShop.name}
                      className="w-full h-full object-contain rounded-xl"
                    />
                  ) : (
                    <Store size={36} className="text-blue-600" />
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setIsEditShopOpen(true)}
                  className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold cursor-pointer transition-opacity"
                >
                  <Camera size={16} className="mb-0.5" />
                  <span>Change</span>
                </button>
              </div>

              {/* Titles & Metadata */}
              <div className="space-y-1 min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-blue-600">
                    Shop Profile
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                      isApproved
                        ? 'bg-emerald-100 text-emerald-800'
                        : isPending
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-rose-100 text-rose-900'
                    }`}
                  >
                    {isApproved ? 'Approved' : `${currentShop.status}`}
                  </span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 truncate">
                  {currentShop.name}
                </h1>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                  <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                    {currentShop.category}
                  </span>
                  <span>Proprietor: <strong className="text-slate-700">{currentShop.ownerName}</strong></span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <MapPin size={12} /> {currentShop.city}
                  </span>
                  <span>·</span>
                  <span className="text-emerald-700 font-bold font-mono">+{currentShop.phone}</span>
                </div>
              </div>
            </div>

            {/* Quick Actions Buttons */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <button
                type="button"
                onClick={() => setIsEditShopOpen(true)}
                className="px-4 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Edit2 size={14} />
                <span>Edit Shop</span>
              </button>

              {/* Large + Add Product Button */}
              <button
                type="button"
                onClick={() => setIsAddProductOpen(true)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Plus size={16} />
                <span>+ Add Product</span>
              </button>

              {isApproved && (
                <Link
                  href={`/shop/${currentShop.slug}`}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <ExternalLink size={14} />
                  <span>Storefront</span>
                </Link>
              )}
            </div>
          </div>

          {/* Quick Section Tabs */}
          <div className="px-6 border-t border-slate-100 flex items-center gap-2 overflow-x-auto scrollbar-none pb-2 pt-2 text-xs">
            <button
              onClick={() => setActiveSection('products')}
              className={`px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeSection === 'products'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Package size={14} />
              <span>Products ({sellerProducts.length})</span>
            </button>

            <button
              onClick={() => setActiveSection('analytics')}
              className={`px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeSection === 'analytics'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <BarChart3 size={14} />
              <span>Analytics</span>
            </button>

            <button
              onClick={() => setActiveSection('orders')}
              className={`px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeSection === 'orders'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ShoppingBag size={14} />
              <span>Orders ({sellerOrders.length})</span>
            </button>

            <button
              onClick={() => setActiveSection('notifications')}
              className={`px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeSection === 'notifications'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Bell size={14} />
              <span>Alerts ({sellerNotifications.length})</span>
            </button>

            {/* Tab: id: 'settings' */}
            <button
              id="settings"
              onClick={() => setIsEditShopOpen(true)}
              className="px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer text-slate-600 hover:bg-slate-100"
            >
              <Settings size={14} />
              <span>Shop Settings</span>
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* 2. SECTION: PRODUCTS HUB (RIGHT UNDER PROFILE) */}
        {/* ========================================================= */}
        {activeSection === 'products' && (
          <div className="space-y-6">
            {/* Products Filter & Control Toolbar */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              {/* Listed vs Unlisted Pill Toggles */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl shrink-0">
                <button
                  type="button"
                  onClick={() => setListingFilter('all')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    listingFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All ({sellerProducts.length})
                </button>
                <button
                  type="button"
                  onClick={() => setListingFilter('listed')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    listingFilter === 'listed'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-emerald-700 hover:bg-white/60'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-white" />
                  <span>Listed ({listedProducts.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setListingFilter('unlisted')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    listingFilter === 'unlisted'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-amber-700 hover:bg-white/60'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-white" />
                  <span>Unlisted ({unlistedProducts.length})</span>
                </button>
              </div>

              {/* Search & Category Filter */}
              <div className="flex items-center gap-2 flex-1 max-w-md">
                <div className="relative flex-1">
                  <Search size={14} className="text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder="Search your products..."
                    className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-blue-500 outline-hidden"
                  />
                </div>

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-hidden cursor-pointer"
                >
                  <option value="All">All Categories</option>
                  {Array.from(new Set(sellerProducts.map((p) => p.category))).map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => setIsAddProductOpen(true)}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Plus size={14} />
                  <span className="hidden sm:inline">Add</span>
                </button>
              </div>
            </div>

            {/* Product Cards Grid */}
            {filteredSellerProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredSellerProducts.map((p) => {
                  const isLive = p.status === 'active';
                  return (
                    <div
                      key={p.id}
                      className="bg-white rounded-3xl p-4 border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-3"
                    >
                      <div className="space-y-3">
                        {/* Image & Status Badge */}
                        <div className="relative aspect-square rounded-2xl bg-slate-100 overflow-hidden border border-slate-100">
                          <img
                            src={p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'}
                            alt={p.name}
                            className="w-full h-full object-cover"
                          />

                          {/* Status Badge */}
                          <div className="absolute top-2.5 left-2.5">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-xs ${
                                isLive
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-amber-500 text-white'
                              }`}
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-white" />
                              <span>{isLive ? 'Active' : 'Draft'}</span>
                            </span>
                          </div>

                          <div className="absolute bottom-2.5 right-2.5 bg-black/70 backdrop-blur-xs text-white text-[11px] font-bold px-2 py-0.5 rounded-lg">
                            Stock: {p.stock}
                          </div>
                        </div>

                        {/* Title & Info */}
                        <div>
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">
                            {p.category}
                          </span>
                          <h3 className="font-black text-slate-900 text-sm line-clamp-1 mt-0.5">
                            {p.name}
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-base font-black text-slate-900">
                              {formatCurrency(p.price)}
                            </span>
                            {p.originalPrice && p.originalPrice > p.price && (
                              <span className="text-xs text-slate-400 line-through">
                                {formatCurrency(p.originalPrice)}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons: 1-Click Toggle Listed / Unlist + Delete */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                        {/* 1-Click Toggle Button */}
                        <button
                          type="button"
                          onClick={() => handleToggleProductStatus(p)}
                          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-black transition-colors flex items-center justify-center gap-1 cursor-pointer ${
                            isLive
                              ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {isLive ? (
                            <>
                              <EyeOff size={13} />
                              <span>Hide</span>
                            </>
                          ) : (
                            <>
                              <Eye size={13} />
                              <span>Publish</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeletingProductId(p.id)}
                          className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-3">
                <Package size={44} className="mx-auto text-slate-300" />
                <h3 className="text-base font-extrabold text-slate-800">
                  {listingFilter === 'unlisted'
                    ? 'No Unlisted Products'
                    : listingFilter === 'listed'
                    ? 'No Listed Products Yet'
                    : 'No Products in Your Shop Yet'}
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {listingFilter === 'unlisted'
                    ? 'You have no draft products right now. Hide any product anytime to review it later.'
                    : 'Click "+ Add Product" to publish your first item!'}
                </p>
                <button
                  type="button"
                  onClick={() => setIsAddProductOpen(true)}
                  className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors cursor-pointer mt-2"
                >
                  <Plus size={15} />
                  <span>+ Add Product</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 3. SECTION: ANALYTICS */}
        {/* ========================================================= */}
        {activeSection === 'analytics' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <span>Shop Analytics</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Overview of performance and sales for {currentShop.name}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveSection('products')}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                ← Back
              </button>
            </div>

            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {/* Total Sales */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Total Sales</span>
                  <DollarSign size={18} className="text-blue-600" />
                </div>
                <p className="text-2xl font-black text-blue-700">{formatCurrency(totalSalesPKR)}</p>
                <p className="text-[11px] text-slate-400">Gross revenue</p>
              </div>

              {/* Total Products */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Total Products</span>
                  <Package size={18} className="text-blue-600" />
                </div>
                <p className="text-2xl font-black text-slate-900">{sellerProducts.length}</p>
                <p className="text-[11px] text-slate-400">
                  {listedProducts.length} Listed · {unlistedProducts.length} Draft
                </p>
              </div>

              {/* Total Orders */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Total Orders</span>
                  <ShoppingBag size={18} className="text-purple-600" />
                </div>
                <p className="text-2xl font-black text-slate-900">{sellerOrders.length}</p>
                <p className="text-[11px] text-purple-700 font-semibold">
                  {pendingOrdersCount} Pending · {completedOrdersCount} Delivered
                </p>
              </div>

              {/* Product Views */}
              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>Views</span>
                  <Eye size={18} className="text-emerald-600" />
                </div>
                <p className="text-2xl font-black text-emerald-700">{totalViews.toLocaleString()}</p>
                <p className="text-[11px] text-slate-400">Impressions</p>
              </div>
            </div>

            {/* Performance Chart & Store Trust */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                    <TrendingUp size={18} className="text-blue-600" /> Weekly Activity
                  </h3>
                  <span className="text-xs text-slate-400 font-bold">Past 7 Days</span>
                </div>

                <div className="h-44 flex items-end justify-between gap-2 pt-6 px-2">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
                    const heights = ['40%', '65%', '50%', '85%', '70%', '95%', '60%'];
                    return (
                      <div key={day} className="flex-1 flex flex-col items-center gap-2">
                        <div className="w-full bg-slate-100 rounded-t-xl h-32 flex items-end p-1">
                          <div
                            style={{ height: heights[i] }}
                            className="w-full bg-gradient-to-t from-blue-600 to-indigo-500 rounded-lg transition-all"
                          />
                        </div>
                        <span className="text-[11px] font-bold text-slate-500">{day}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Customer Rating Card */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">Customer Rating</h3>
                  <p className="text-xs text-slate-500 mt-1">Based on verified orders</p>
                  <div className="flex items-center gap-2 mt-4">
                    <span className="text-4xl font-black text-slate-900">{currentShop.rating || 5.0}</span>
                    <div className="space-y-1">
                      <div className="flex text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} size={15} className="fill-current" />
                        ))}
                      </div>
                      <span className="text-xs text-slate-500 block">{(currentShop.reviewCount || 0) + 5} reviews</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-blue-50 rounded-2xl text-xs text-blue-900">
                  <p className="font-bold">WhatsApp Direct Orders</p>
                  <p className="text-[11px] text-blue-700 mt-0.5">Customers can initiate direct orders via your hotline.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 4. SECTION: ORDERS */}
        {/* ========================================================= */}
        {activeSection === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-purple-600" />
                  <span>Customer Orders ({sellerOrders.length})</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Orders placed by customers for your shop
                </p>
              </div>

              {/* Filter */}
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                {['all', 'Pending', 'Confirmed', 'Delivered', 'Cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setOrderStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                      orderStatusFilter === st
                        ? 'bg-purple-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {st === 'all' ? 'All Orders' : st}
                  </button>
                ))}
              </div>
            </div>

            {filteredSellerOrders.length > 0 ? (
              <div className="space-y-3">
                {filteredSellerOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div>
                        <span className="font-mono text-xs font-bold text-blue-600">
                          #{ord.orderNumber}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900 mt-0.5">
                          {ord.customerName}
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          Phone: +{ord.phone} · City: {ord.shippingAddress?.city || 'Pakistan'}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-black uppercase ${
                            ord.orderStatus === 'Delivered'
                              ? 'bg-emerald-100 text-emerald-800'
                              : ord.orderStatus === 'Cancelled'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {ord.orderStatus}
                        </span>

                        <select
                          value={ord.orderStatus}
                          disabled={updatingOrderId === ord.id}
                          onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value as OrderStatus)}
                          className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-hidden cursor-pointer"
                        >
                          <option value="Pending">Pending</option>
                          <option value="Confirmed">Confirmed</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Order Items */}
                    <div className="space-y-2">
                      {ord.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-10 h-10 rounded-xl object-cover border border-slate-100"
                            />
                            <div>
                              <span className="font-bold text-slate-800 line-clamp-1">{item.name}</span>
                              <span className="text-[11px] text-slate-400">Qty: {item.quantity}</span>
                            </div>
                          </div>
                          <span className="font-extrabold text-slate-900">
                            {formatCurrency(item.price * item.quantity)}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-slate-700">
                      <span>Total Amount:</span>
                      <span className="text-base text-blue-700 font-black">{formatCurrency(ord.grandTotal)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-2">
                <ShoppingBag size={40} className="mx-auto text-slate-300" />
                <p className="font-bold text-sm text-slate-800">No Orders in this category</p>
                <p className="text-xs text-slate-500">Orders placed by customers will appear here automatically.</p>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 5. SECTION: NOTIFICATIONS */}
        {/* ========================================================= */}
        {activeSection === 'notifications' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              <span>Notifications</span>
            </h2>

            {sellerNotifications.length > 0 ? (
              <div className="divide-y divide-slate-100">
                {sellerNotifications.map((n) => (
                  <div key={n.id} className="py-3.5 flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                      <Bell size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-slate-900">{n.title}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">{n.message}</p>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        {new Date(n.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-500">
                No notifications right now.
              </div>
            )}
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* IN-PAGE QUICK ADD PRODUCT MODAL */}
      {/* ========================================================= */}
      {isAddProductOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-2xs">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Add Product</h3>
                  <p className="text-[11px] text-slate-500">New item for {currentShop.name}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddProductOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickProduct} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              {productError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs">
                  {productError}
                </div>
              )}

              {/* Title */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Product Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Cotton Shalwar Kameez / Bluetooth Earbuds"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden"
                />
              </div>

              {/* Category & Condition */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden cursor-pointer"
                  >
                    {Object.keys(MARKETPLACE_CATEGORIES).map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Condition</label>
                  <select
                    value={newProdCondition}
                    onChange={(e) => setNewProdCondition(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden cursor-pointer"
                  >
                    <option value="New">New</option>
                    <option value="Used - Like New">Used - Like New</option>
                    <option value="Refurbished">Refurbished</option>
                  </select>
                </div>
              </div>

              {/* Price & Original Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Price (PKR) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(e.target.value)}
                    placeholder="1500"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Original Price (Optional)</label>
                  <input
                    type="number"
                    value={newProdOriginalPrice}
                    onChange={(e) => setNewProdOriginalPrice(e.target.value)}
                    placeholder="2000"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden"
                  />
                </div>
              </div>

              {/* Stock */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Stock</label>
                <input
                  type="number"
                  value={newProdStock}
                  onChange={(e) => setNewProdStock(e.target.value)}
                  placeholder="10"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold focus:bg-white focus:border-blue-500 outline-hidden"
                />
              </div>

              {/* Product Images */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Product Photos
                </label>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  multiple
                  onChange={handleAddProductImages}
                  className="block w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer"
                />

                {newProdPreviews.length > 0 && (
                  <div className="flex items-center gap-2 mt-2 overflow-x-auto pb-1">
                    {newProdPreviews.map((src, i) => (
                      <div key={i} className="w-14 h-14 rounded-xl overflow-hidden border border-slate-200 shrink-0">
                        <img src={src} alt="Preview" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newProdDescription}
                  onChange={(e) => setNewProdDescription(e.target.value)}
                  placeholder="Detail colors, size, materials, return policy..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white focus:border-blue-500 outline-hidden"
                />
              </div>

              {/* Listing Status Toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">Status:</span>
                <div className="grid grid-cols-2 gap-2">
                  <label
                    onClick={() => setNewProdStatus('active')}
                    className={`p-2.5 rounded-xl border text-center cursor-pointer font-extrabold transition-all ${
                      newProdStatus === 'active'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    🟢 Active (Live)
                  </label>
                  <label
                    onClick={() => setNewProdStatus('draft')}
                    className={`p-2.5 rounded-xl border text-center cursor-pointer font-extrabold transition-all ${
                      newProdStatus === 'draft'
                        ? 'bg-amber-500 text-white border-amber-500'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    🟡 Draft (Hidden)
                  </label>
                </div>
                <p className="text-[10px] text-slate-500">
                  Draft items stay in your profile until you publish them.
                </p>
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddProductOpen(false)}
                  disabled={isSavingProduct}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingProduct}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-xl shadow-md flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSavingProduct ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>Save Product</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {deletingProductId && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 border border-slate-200 shadow-2xl text-center">
            <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
              <Trash2 size={24} />
            </div>
            <h3 className="text-lg font-black text-slate-900">Delete Product?</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to remove this item from your catalog?
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={() => setDeletingProductId(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SHOP EDIT MODAL */}
      <ShopEditModal
        isOpen={isEditShopOpen}
        onClose={() => setIsEditShopOpen(false)}
        shop={currentShop}
        onSuccess={(updated) => {
          setActionMessage(`Shop profile for "${updated.name}" updated successfully!`);
        }}
      />
    </div>
  );
};
