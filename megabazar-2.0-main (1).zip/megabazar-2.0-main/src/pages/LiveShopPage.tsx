'use client';

import React, { useEffect, useState, useMemo } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { usePathname, useRouter } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { mapShop } from '@/lib/marketplace/shops';
import { uploadShopImage } from '@/lib/marketplace/upload';
import { uploadImageToSupabase } from '@/lib/supabase/storage';
import { formatCurrency, createWhatsAppLink } from '@/lib/utils';
import { SellerShop, Product } from '@/lib/types';
import Link from 'next/link';
import {
  Store,
  CheckCircle2,
  MapPin,
  Phone,
  Share2,
  MessageCircle,
  Star,
  Package,
  Plus,
  Edit3,
  Search,
  SlidersHorizontal,
  ArrowLeft,
  Camera,
  Image as ImageIcon,
  Check,
  ExternalLink,
  ShieldCheck,
  Clock,
  Sparkles,
  AlertCircle,
  X,
  UploadCloud,
  ChevronRight,
} from 'lucide-react';
import { ShopEditModal } from '@/components/ShopEditModal';

export function LiveShopPage() {
  const pathname = usePathname();
  const router = useRouter();
  const slug = decodeURIComponent(pathname.split('/')[2] || '');

  const { user, products: globalProducts, addToCart, setIsCartOpen } = useStore();

  const [shop, setShop] = useState<SellerShop | null>(null);
  const [shopProducts, setShopProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'newest'>('newest');

  // Share notification
  const [copiedLink, setCopiedLink] = useState(false);

  // Shop Owner Edit Modal
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editDesc, setEditDesc] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editArea, setEditArea] = useState('');
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [uploadingOwnerPic, setUploadingOwnerPic] = useState(false);
  const [editMessage, setEditMessage] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Check if current logged-in user is the owner of this shop
  const isOwner = Boolean(
    (user && shop && (
      (shop.ownerId && (shop.ownerId === user.uid || shop.ownerId === (user as any).id)) ||
      (shop.email && user.email && shop.email.toLowerCase() === user.email.toLowerCase())
    )) ||
    (user && (user.role === 'admin' || user.role === 'super_admin'))
  );

  const getMediaUrl = (path?: string) => {
    if (!path) return '';
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    return supabase.storage.from('mb-product-images').getPublicUrl(path).data.publicUrl;
  };

  const loadShopData = async () => {
    if (!slug) return;
    setLoading(true);
    setErrorMessage('');

    try {
      if (isSupabaseConfigured) {
        // 1. Fetch shop from mb_public_shops view (or mb_shops if owner)
        let shopRow: any = null;
        const pubRes = await supabase
          .from('mb_public_shops')
          .select('*')
          .eq('slug', slug)
          .maybeSingle();

        if (pubRes.data) {
          shopRow = pubRes.data;
        } else {
          // If not in public view, check mb_shops (e.g. if pending or viewing own shop)
          const ownRes = await supabase
            .from('mb_shops')
            .select('*')
            .eq('slug', slug)
            .maybeSingle();
          if (ownRes.data) shopRow = ownRes.data;
        }

        if (!shopRow) {
          throw new Error('Shop not found or storefront is currently inactive.');
        }

        const mappedShop = mapShop(shopRow);
        setShop(mappedShop);
        setEditDesc(mappedShop.description || '');
        setEditCity(mappedShop.city || '');
        setEditArea(mappedShop.area || '');

        // 2. Fetch products belonging to this shop from mb_public_products
        const { data: pData } = await supabase
          .from('mb_public_products')
          .select('*')
          .eq('shop_id', mappedShop.id);

        let mappedList: Product[] = [];
        if (pData && Array.isArray(pData)) {
          mappedList = pData.map((row: any) => {
            const d = row.details || {};
            const origPrice = Number(d.price || 0);
            const salePrice = d.salePrice ? Number(d.salePrice) : origPrice;
            const discount = origPrice > salePrice ? Math.round(((origPrice - salePrice) / origPrice) * 100) : 0;
            const images = Array.isArray(row.images) && row.images.length > 0
              ? row.images.map((img: string) => getMediaUrl(img))
              : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80'];

            return {
              id: row.id,
              name: d.name || 'Shop Product',
              slug: row.id,
              sku: `MB-${row.id.slice(0, 8)}`,
              category: d.category || 'General',
              brand: mappedShop.name,
              description: d.description || '',
              shortDescription: d.contents,
              price: salePrice,
              originalPrice: origPrice || salePrice,
              discountPercentage: discount,
              stock: Number(d.stock ?? 1),
              lowStockThreshold: 3,
              images,
              specifications: {
                Condition: d.condition || 'New',
                Dispatch: `${d.dispatch || 2} days`,
                Shop: mappedShop.name,
              },
              tags: [d.category, mappedShop.name],
              isFeatured: false,
              isBestSeller: false,
              isFlashDeal: Boolean(discount > 0),
              rating: 5,
              reviewCount: 0,
              status: 'active',
              whatsappNumber: d.whatsapp || mappedShop.phone,
              sellerWhatsapp: d.whatsapp || mappedShop.phone,
              shopId: mappedShop.id,
              shopSlug: mappedShop.slug,
              shopName: mappedShop.name,
              condition: d.condition || 'New',
              createdAt: row.created_at,
              updatedAt: row.updated_at,
            };
          });
        }

        // Also check if any global catalog products have brand matching this shop
        const matchingCatalog = globalProducts.filter(
          (p) =>
            (p.brand && p.brand.toLowerCase() === mappedShop.name.toLowerCase()) ||
            p.shopSlug === mappedShop.slug ||
            p.shopId === mappedShop.id
        );

        // Deduplicate
        const idSet = new Set(mappedList.map((p) => p.id));
        matchingCatalog.forEach((p) => {
          if (!idSet.has(p.id)) {
            mappedList.push(p);
            idSet.add(p.id);
          }
        });

        setShopProducts(mappedList);
      } else {
        // Fallback for offline/preview
        const matched = globalProducts.filter((p) => p.brand.toLowerCase().includes(slug.replace('-', ' ')));
        setShop({
          id: `shop-${slug}`,
          ownerId: 'demo-owner',
          ownerName: 'Verified Merchant',
          email: `${slug}@megabazar.pk`,
          phone: '923182204441',
          name: slug.split('-').map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
          slug,
          category: 'Multi-Vendor Retail',
          city: 'Karachi',
          area: 'Main Boulevard',
          address: 'Karachi, Pakistan',
          description: 'Official verified storefront on Mega Bazar Pakistan.',
          status: 'Approved',
          isVerified: true,
          commissionRate: '5%',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          rating: 5,
          reviewCount: 12,
        });
        setShopProducts(matched);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Could not load storefront details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadShopData();
  }, [slug]);

  // Categories available in this shop
  const shopCategories = useMemo(() => {
    const set = new Set<string>();
    shopProducts.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return ['All', ...Array.from(set)];
  }, [shopProducts]);

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return shopProducts
      .filter((p) => {
        const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
        const matchesSearch =
          !searchQuery.trim() ||
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') return a.price - b.price;
        if (sortBy === 'price-high') return b.price - a.price;
        if (sortBy === 'featured') return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [shopProducts, selectedCategory, searchQuery, sortBy]);

  const handleShareShop = () => {
    if (typeof window === 'undefined') return;
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleUploadMedia = async (file: File, type: 'logo' | 'banner' | 'owner') => {
    if (!shop || !file) return;
    if (type === 'logo') setUploadingLogo(true);
    if (type === 'banner') setUploadingBanner(true);
    if (type === 'owner') setUploadingOwnerPic(true);
    setEditMessage('');

    try {
      const uploadRes = await uploadImageToSupabase(file, {
        bucket: 'mb-product-images',
        folder: type === 'logo' ? 'logos' : type === 'banner' ? 'banners' : 'owners',
      });

      if (!uploadRes.success || !uploadRes.path) {
        throw new Error(uploadRes.error || `Failed to upload ${type}`);
      }

      const updates: any = {};
      if (type === 'logo') {
        updates.logo_path = uploadRes.path;
        updates.logo_url = uploadRes.url;
      } else if (type === 'banner') {
        updates.banner_path = uploadRes.path;
        updates.banner_url = uploadRes.url;
      }

      // Update in Supabase
      const { error } = await supabase
        .from('mb_shops')
        .update(updates)
        .eq('id', shop.id);

      if (error) throw error;

      // Also call mb_set_shop_media RPC if banner or logo
      if (type === 'logo' || type === 'banner') {
        try {
          await supabase.rpc('mb_set_shop_media', {
            logo_image: type === 'logo' ? uploadRes.path : (shop.logoPath || ''),
            banner_image: type === 'banner' ? uploadRes.path : (shop.bannerPath || ''),
          });
        } catch (e) {
          console.warn('mb_set_shop_media RPC note:', e);
        }
      }

      setShop((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          ...(type === 'logo' ? { logoUrl: uploadRes.url, logoPath: uploadRes.path } : {}),
          ...(type === 'banner' ? { bannerUrl: uploadRes.url, bannerPath: uploadRes.path } : {}),
          ...(type === 'owner' ? { ownerAvatarUrl: uploadRes.url } : {}),
        };
      });

      setEditMessage(`Shop ${type} updated successfully!`);
    } catch (err: any) {
      setEditMessage(err.message || `Failed to upload ${type}`);
    } finally {
      if (type === 'logo') setUploadingLogo(false);
      if (type === 'banner') setUploadingBanner(false);
      if (type === 'owner') setUploadingOwnerPic(false);
    }
  };

  const handleSaveProfileDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shop) return;
    setIsSavingProfile(true);
    setEditMessage('');

    try {
      const { error } = await supabase
        .from('mb_shops')
        .update({
          description: editDesc.trim(),
          city: editCity.trim(),
          address: editArea.trim() || shop.address,
          updated_at: new Date().toISOString(),
        })
        .eq('id', shop.id);

      if (error) throw error;

      setShop((prev) => prev ? {
        ...prev,
        description: editDesc.trim(),
        city: editCity.trim(),
        area: editArea.trim(),
      } : null);

      setEditMessage('Shop profile details updated successfully!');
      setTimeout(() => setIsEditModalOpen(false), 1200);
    } catch (err: any) {
      setEditMessage(err.message || 'Failed to update shop details.');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const whatsAppInquiryUrl = shop
    ? createWhatsAppLink(
        shop.phone || '923182204441',
        `Assalam-o-Alaikum! I am browsing your storefront "${shop.name}" on Mega Bazar. Are your products available for order?`
      )
    : '#';

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-4 px-4 bg-slate-50">
        <div className="w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center animate-pulse">
          <Store size={32} />
        </div>
        <p className="text-base font-bold text-slate-800">Opening Storefront...</p>
        <p className="text-xs text-slate-500">Loading catalog items and merchant profile</p>
      </div>
    );
  }

  if (errorMessage || !shop) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-4 px-4 bg-slate-50 text-center">
        <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
          <AlertCircle size={32} />
        </div>
        <h1 className="text-2xl font-black text-slate-900">Storefront Unavailable</h1>
        <p className="text-sm text-slate-600 max-w-md">
          {errorMessage || 'This shop does not exist or has not been approved by the marketplace admin yet.'}
        </p>
        <div className="pt-2 flex gap-3">
          <Link
            href="/shops"
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs"
          >
            Browse Verified Shops
          </Link>
          <Link
            href="/"
            className="px-5 py-2.5 bg-white border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50"
          >
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      {/* OWNER ACTION TOP BAR */}
      {isOwner && (
        <div className="bg-blue-600 text-white text-xs py-2.5 px-4 shadow-sm border-b border-blue-700">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            <span className="font-bold flex items-center gap-1.5">
              <Sparkles size={15} className="text-amber-300 shrink-0" />
              <span>You are viewing your own shop (<strong>{shop.name}</strong>).</span>
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsEditModalOpen(true)}
                className="bg-white text-blue-700 hover:bg-blue-50 font-extrabold px-3 py-1.5 rounded-xl text-xs cursor-pointer transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Edit3 size={13} />
                {/* Edit Shop · شاپ میں ترمیم */}
                <span>Edit Shop</span>
              </button>
              <Link
                href="/seller/dashboard"
                className="text-white/90 hover:text-white underline font-semibold text-xs ml-1"
              >
                Seller Dashboard →
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* 1. SHOP BANNER COVER */}
      <div className="relative w-full h-48 sm:h-72 md:h-80 bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 overflow-hidden">
        {shop.bannerUrl ? (
          <img
            src={shop.bannerUrl}
            alt={`${shop.name} Banner`}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />
            <div className="text-center text-white/80 space-y-2 z-10 px-4">
              <Store className="w-12 h-12 mx-auto text-blue-300 opacity-60" />
              <p className="text-xs uppercase tracking-widest font-black text-blue-200">
                Official Marketplace Storefront
              </p>
              <h2 className="text-2xl sm:text-3xl font-black text-white">{shop.name}</h2>
            </div>
          </div>
        )}

        {/* Owner Quick Banner Edit */}
        {isOwner && (
          <label className="absolute top-4 right-4 bg-black/60 hover:bg-black/80 text-white text-xs font-bold px-3.5 py-2 rounded-xl backdrop-blur-md cursor-pointer flex items-center gap-1.5 shadow-lg transition-all border border-white/20 z-20">
            <Camera size={15} />
            <span>{uploadingBanner ? 'Uploading...' : 'Change Cover Banner'}</span>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleUploadMedia(f, 'banner');
              }}
              disabled={uploadingBanner}
            />
          </label>
        )}
      </div>

      {/* 2. SHOP IDENTITY BAR */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 sm:-mt-20 relative z-20">
        <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-md border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4 sm:gap-6 w-full md:w-auto">
            {/* Logo */}
            <div className="relative group shrink-0">
              <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-2xl sm:rounded-3xl bg-white border-2 border-slate-200 shadow-md p-1.5 flex items-center justify-center overflow-hidden">
                {shop.logoUrl ? (
                  <img
                    src={shop.logoUrl}
                    alt={shop.name}
                    className="w-full h-full object-contain rounded-xl sm:rounded-2xl"
                  />
                ) : (
                  <div className="w-full h-full bg-blue-50 text-blue-600 rounded-xl sm:rounded-2xl flex items-center justify-center font-black text-3xl">
                    {shop.name.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>

              {isOwner && (
                <label className="absolute inset-0 bg-black/50 text-white rounded-2xl sm:rounded-3xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center cursor-pointer transition-opacity text-[10px] font-bold">
                  <Camera size={18} className="mb-1" />
                  <span>{uploadingLogo ? '...' : 'Change'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleUploadMedia(f, 'logo');
                    }}
                    disabled={uploadingLogo}
                  />
                </label>
              )}
            </div>

            {/* Shop Titles */}
            <div className="space-y-1.5 min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 truncate">{shop.name}</h1>
                {shop.isVerified && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                    <CheckCircle2 size={13} className="text-blue-600 fill-blue-600 text-white" /> Verified Store
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                  {shop.category}
                </span>
                <span className="flex items-center gap-1 text-slate-500">
                  <MapPin size={13} className="text-slate-400" /> {shop.city}{shop.area ? `, ${shop.area}` : ''}
                </span>
                <span className="flex items-center gap-1 text-amber-600 font-bold">
                  <Star size={13} className="fill-amber-400 text-amber-500" />
                  {shop.rating || 5.0} ({(shop.reviewCount || 0) + 5} reviews)
                </span>
              </div>

              {shop.ownerName && (
                <p className="text-[11px] text-slate-500">
                  Proprietor / Merchant: <strong className="text-slate-700">{shop.ownerName}</strong>
                </p>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
            {/* Share Shop Button */}
            <button
              onClick={handleShareShop}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedLink ? <Check size={15} className="text-emerald-600" /> : <Share2 size={15} />}
              <span>{copiedLink ? 'Link Copied!' : 'Share Shop'}</span>
            </button>

            {/* Direct WhatsApp Contact */}
            <a
              href={whatsAppInquiryUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <MessageCircle size={15} className="fill-current" />
              <span>WhatsApp Chat</span>
            </a>

            {/* If Owner: Edit Profile & Add Product */}
            {isOwner && (
              <>
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(true)}
                  className="px-4 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-blue-200 shadow-2xs"
                >
                  <Edit3 size={15} />
                  <span>Edit Shop · شاپ میں ترمیم</span>
                </button>
                <Link
                  href="/seller/products/new"
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Plus size={15} />
                  <span>Add Product</span>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 3. STORE DESCRIPTION & OWNER NOTICE */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* About the Store */}
          <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-2xs space-y-3">
            <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <Store size={18} className="text-blue-600" /> About {shop.name}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
              {shop.description || 'Welcome to our official store on Mega Bazar Pakistan! All products listed here are 100% genuine and dispatched directly to your doorstep with Cash on Delivery nationwide.'}
            </p>
          </div>

          {/* Verified Merchant Trust Box */}
          <div className="bg-blue-50/70 border border-blue-100 rounded-3xl p-6 space-y-3.5 text-xs text-slate-700">
            <h4 className="font-extrabold text-sm text-blue-950 flex items-center gap-2">
              <ShieldCheck size={18} className="text-blue-600" /> Buyer Protection Guarantee
            </h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                <span>Verified seller on Mega Bazar Pakistan</span>
              </li>
              <li className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                <span>Cash on Delivery (COD) accepted nationwide</span>
              </li>
              <li className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                <span>7-Day Return / Replacement window for damaged items</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 4. SHOP PRODUCTS CATALOG */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        {/* Catalog Header, Category Filters & Search */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                Products by {shop.name}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Showing {filteredProducts.length} of {shopProducts.length} items
              </p>
            </div>

            {/* In-Shop Search */}
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search this shop's items..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          </div>

          {/* Category Tabs */}
          {shopCategories.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 no-scrollbar">
              {shopCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((p) => {
              const coverImg = p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';
              return (
                <div
                  key={p.id}
                  className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col group"
                >
                  {/* Image container */}
                  <Link href={`/product/${p.id}`} className="relative block aspect-square bg-slate-100 overflow-hidden">
                    <img
                      src={coverImg}
                      alt={p.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {p.discountPercentage > 0 && (
                      <span className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs">
                        -{p.discountPercentage}% OFF
                      </span>
                    )}
                    {p.condition && (
                      <span className="absolute top-2.5 right-2.5 bg-slate-900/80 backdrop-blur-xs text-white text-[9px] font-bold px-2 py-0.5 rounded-md capitalize">
                        {p.condition}
                      </span>
                    )}
                  </Link>

                  {/* Body */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                        {p.category}
                      </p>
                      <Link href={`/product/${p.id}`} className="block mt-1">
                        <h3 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-2 hover:text-blue-600 transition-colors">
                          {p.name}
                        </h3>
                      </Link>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                      <div>
                        <p className="text-sm sm:text-base font-black text-slate-900">
                          {formatCurrency(p.price)}
                        </p>
                        {p.originalPrice > p.price && (
                          <p className="text-[10px] text-slate-400 line-through">
                            {formatCurrency(p.originalPrice)}
                          </p>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          addToCart(p, 1);
                          setIsCartOpen(true);
                        }}
                        className="p-2 sm:px-3 sm:py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                        title="Add to Cart"
                      >
                        <Package size={14} />
                        <span className="hidden sm:inline">Add</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
            <Package size={40} className="mx-auto text-slate-300" />
            <h3 className="text-base font-bold text-slate-800">No Products Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {searchQuery
                ? `No products matched "${searchQuery}". Try a different search term or category.`
                : 'This shop has not published any public products yet.'}
            </p>
            {isOwner && (
              <Link
                href="/seller/products/new"
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs mt-2"
              >
                <Plus size={14} /> Add First Product
              </Link>
            )}
          </div>
        )}
      </div>

      {/* 5. SHOP EDIT MODAL */}
      <ShopEditModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        shop={shop}
        onSuccess={(updated) => {
          setShop(updated);
        }}
      />
    </div>
  );
}
