'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useParams } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { demoShops } from '@/lib/demo-shops';
import { createWhatsAppLink, formatPakistaniWhatsAppNumber } from '@/lib/utils';
import { ProductCard } from '@/components/ProductCard';
import { ShopEditModal } from '@/components/ShopEditModal';
import {
  ArrowLeft,
  MessageCircle,
  Store,
  ShieldCheck,
  Sparkles,
  MapPin,
  Clock,
  Phone,
  Edit2,
} from 'lucide-react';

export const DemoShopDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { shops, products, user, isAdmin } = useStore();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const currentSlug = slug || 'rang-boutique';

  // Check if it's a registered seller shop in StoreContext
  const registeredShop = shops.find((s) => s.slug === currentSlug);

  const isOwner = Boolean(
    registeredShop &&
    ((user && (registeredShop.ownerId === user.uid || (registeredShop.email && user.email && registeredShop.email.toLowerCase() === user.email.toLowerCase()))) || isAdmin)
  );

  // Check if it's a demo fixture shop
  const demoShop = demoShops.find((s) => s.slug === currentSlug);

  // If it is a registered shop that is still Pending
  if (registeredShop && registeredShop.status === 'Pending') {
    return (
      <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 shadow-lg border border-slate-200 text-center space-y-5">
          <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Clock size={32} />
          </div>
          <div className="inline-block px-3 py-1 bg-amber-100 text-amber-900 text-xs font-black uppercase rounded-full">
            Under Verification
          </div>
          <h1 className="text-2xl font-black text-slate-900">{registeredShop.name}</h1>
          <p className="text-xs text-slate-600 leading-relaxed">
            This seller storefront has been submitted and is currently undergoing verification by Mega Bazar Platform Owner Muhammad Moiz. Once approved, this shop will be live for orders.
          </p>
          <div className="pt-3">
            <Link
              href="/shops"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Browse Active Shops →
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Active storefront: either approved registered shop or demo shop
  const shopName = registeredShop?.name || demoShop?.name || 'Mega Bazar Storefront';
  const shopCity = registeredShop?.city || demoShop?.city || 'Pakistan';
  const shopCategory = registeredShop?.category || demoShop?.category || 'General Marketplace';
  const shopDescription =
    registeredShop?.description ||
    demoShop?.description ||
    'Discover genuine products with fast courier dispatch across Pakistan.';
  const shopPhone = registeredShop?.phone || '923182204441';
  const shopBanner =
    registeredShop?.logoUrl ||
    demoShop?.image ||
    '/demo-shops/fashion.webp';

  // Products belonging to this shop
  const shopProducts = products.filter((p) => {
    if (registeredShop) {
      return (
        (p.brand && p.brand.toLowerCase() === registeredShop.name.toLowerCase()) ||
        (p.sellerWhatsapp && p.sellerWhatsapp === registeredShop.phone) ||
        (p.whatsappNumber && p.whatsappNumber === registeredShop.phone)
      );
    }
    return false;
  });

  const waMessage = `Hello! I am viewing your shop *${shopName}* on Mega Bazar. Please share your catalog and ordering information. Thank you!`;
  const waLink = createWhatsAppLink(shopPhone, waMessage);

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Top Breadcrumb */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <Link href="/shops" className="hover:text-blue-600 font-bold flex items-center gap-1">
            <ArrowLeft size={14} /> Back to All Shops
          </Link>
          <span className="font-mono text-slate-400">megabazaar.com/shop/{currentSlug}</span>
        </div>

        {/* Storefront Hero Card */}
        <div className="rounded-[2.5rem] overflow-hidden border border-slate-200 bg-white shadow-md">
          <div className="relative h-56 sm:h-72 md:h-80 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900">
            {shopBanner && (
              <img
                src={shopBanner}
                alt={`${shopName} banner`}
                className="w-full h-full object-cover opacity-60"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/40 to-transparent" />
            <div className="absolute bottom-6 sm:bottom-8 left-6 sm:left-10 text-white">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md text-[10px] uppercase font-black tracking-widest rounded-full mb-3">
                <MapPin size={12} /> {shopCity} · {shopCategory}
              </span>
              <h1 className="text-3xl sm:text-5xl font-black tracking-tight">{shopName}</h1>
              <p className="mt-2 text-xs sm:text-sm text-white/90 max-w-lg">{shopDescription}</p>
            </div>
          </div>

          <div className="p-6 sm:p-10 flex flex-wrap items-start justify-between gap-6">
            <div className="flex gap-4 max-w-xl">
              <div className="w-16 h-16 shrink-0 rounded-2xl grid place-items-center bg-blue-600 text-white text-xl font-black shadow-md border-2 border-white">
                <Store size={28} />
              </div>
              <div>
                <h2 className="font-extrabold text-base sm:text-lg text-slate-900">Welcome to {shopName}</h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-1">{shopDescription}</p>
                <div className="flex items-center gap-3 mt-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1 text-emerald-600 font-bold">
                    <ShieldCheck size={14} /> Verified Mega Bazar Seller
                  </span>
                  <span>·</span>
                  <span>Direct WhatsApp Inquiries Enabled</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              {isOwner && registeredShop && (
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(true)}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-xs transition-all cursor-pointer"
                >
                  <Edit2 size={16} /> Edit Shop · شاپ میں ترمیم
                </button>
              )}
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition-all"
              >
                <MessageCircle size={16} className="fill-current" /> WhatsApp Seller
              </a>
              <Link
                href="/open-shop"
                className="px-5 py-3 bg-slate-950 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all"
              >
                Open Your Own Shop →
              </Link>
            </div>
          </div>
        </div>

        {/* Products Collection */}
        <div>
          <div className="flex justify-between items-end mb-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-blue-600">STOREFRONT CATALOGUE</p>
              <h2 className="text-2xl font-black text-slate-900 mt-1">Products from {shopName}</h2>
            </div>
            <span className="text-xs text-slate-400 font-semibold">
              {shopProducts.length > 0 ? `${shopProducts.length} items available` : 'Curated collection'}
            </span>
          </div>

          {shopProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {shopProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          ) : demoShop?.products ? (
            <div className="grid sm:grid-cols-3 gap-5">
              {demoShop.products.map((p, i) => (
                <article key={p.name} className="group rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-2xs hover:shadow-xl transition-all">
                  <div className="aspect-[4/3] overflow-hidden bg-slate-100 relative">
                    <img
                      src={demoShop.image}
                      alt={p.name}
                      style={{ objectPosition: ['25% center', '50% center', '75% center'][i] }}
                      className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-500"
                    />
                    <span className="absolute top-3 left-3 bg-white/90 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-2xs">
                      CATALOGUE ITEM
                    </span>
                  </div>
                  <div className="p-5">
                    <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{demoShop.category}</span>
                    <h3 className="font-extrabold text-sm text-slate-900 mt-1">{p.name}</h3>
                    <div className="flex items-baseline justify-between mt-3 pt-3 border-t border-slate-100">
                      <span className="text-base font-black text-blue-600">
                        PKR {p.price.toLocaleString('en-PK')}
                      </span>
                      <a
                        href={waLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-emerald-600 hover:underline flex items-center gap-1"
                      >
                        <MessageCircle size={13} /> Order on WhatsApp
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="p-8 bg-white rounded-3xl border border-slate-200 text-center text-xs text-slate-500">
              This shop is preparing their latest stock. In the meantime, contact the merchant on WhatsApp for inquiries.
            </div>
          )}
        </div>
      </div>

      {registeredShop && (
        <ShopEditModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          shop={registeredShop}
        />
      )}
    </div>
  );
};
