'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { uploadImageToSupabase } from '@/lib/supabase/storage';
import { formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
import { MARKETPLACE_CATEGORIES } from '@/lib/marketplace-categories';
import { SellerShop } from '@/lib/types';
import {
  X,
  Store,
  Camera,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Upload,
  Sparkles,
  MapPin,
  Phone,
  User,
  Tag,
  FileText,
  Building,
} from 'lucide-react';

interface ShopEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  shop: SellerShop;
  onSuccess?: (updated: SellerShop) => void;
}

const PAKISTANI_CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Gujranwala',
  'Sialkot',
  'Hyderabad',
  'Quetta',
  'Abbottabad',
  'Bahawalpur',
  'Sargodha',
  'Sahiwal',
  'Sukkur',
  'Larkana',
  'Gujrat',
  'Mardan',
  'Kasur',
  'Rahim Yar Khan',
  'Sheikhupura',
  'Jhelum',
  'Wah Cantt',
  'Other',
];

export const ShopEditModal: React.FC<ShopEditModalProps> = ({
  isOpen,
  onClose,
  shop,
  onSuccess,
}) => {
  const { updateShop } = useStore();

  const [shopName, setShopName] = useState(shop.name || '');
  const [ownerName, setOwnerName] = useState(shop.ownerName || '');
  const [category, setCategory] = useState(shop.category || 'Multi-Vendor Retail');
  const [city, setCity] = useState(shop.city || 'Karachi');
  const [area, setArea] = useState(shop.area || '');
  const [address, setAddress] = useState(shop.address || '');
  const [phone, setPhone] = useState(shop.phone || '');
  const [description, setDescription] = useState(shop.description || '');

  // Files & Previews
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>(shop.logoUrl || '');
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string>(shop.bannerUrl || '');

  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setShopName(shop.name || '');
      setOwnerName(shop.ownerName || '');
      setCategory(shop.category || 'Multi-Vendor Retail');
      setCity(shop.city || 'Karachi');
      setArea(shop.area || '');
      setAddress(shop.address || '');
      setPhone(shop.phone || '');
      setDescription(shop.description || '');
      setLogoPreview(shop.logoUrl || '');
      setBannerPreview(shop.bannerUrl || '');
      setLogoFile(null);
      setBannerFile(null);
      setErrorMessage('');
      setSuccessMessage('');
      setUploadStatus('');
    }
  }, [isOpen, shop]);

  if (!isOpen) return null;

  const categoryOptions = [
    'Multi-Vendor Retail',
    ...Object.keys(MARKETPLACE_CATEGORIES).filter((c) => c !== 'Other'),
    'General',
    'Other',
  ];

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      setErrorMessage('Shop logo picture should be under 8 MB.');
      return;
    }
    setLogoFile(file);
    setLogoPreview(URL.createObjectURL(file));
    setErrorMessage('');
  };

  const handleBannerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) {
      setErrorMessage('Cover banner image should be under 12 MB.');
      return;
    }
    setBannerFile(file);
    setBannerPreview(URL.createObjectURL(file));
    setErrorMessage('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const cleanShopName = shopName.trim();
    const cleanOwner = ownerName.trim();
    const cleanCity = city.trim();
    const cleanAddress = address.trim();
    const cleanPhone = phone.trim();

    if (!cleanShopName) {
      setErrorMessage('Please enter your shop name.');
      return;
    }
    if (!cleanCity) {
      setErrorMessage('Please select or specify your city.');
      return;
    }
    if (!cleanPhone) {
      setErrorMessage('Please enter your WhatsApp contact number.');
      return;
    }

    const phoneValidation = formatPakistaniWhatsAppNumber(cleanPhone);
    if (!phoneValidation.isValid) {
      setErrorMessage(phoneValidation.error || 'Please enter a valid Pakistani mobile number (e.g. 03001234567).');
      return;
    }

    setIsSubmitting(true);

    try {
      let finalLogoUrl = shop.logoUrl;
      let finalLogoPath = shop.logoPath;
      let finalBannerUrl = shop.bannerUrl;
      let finalBannerPath = shop.bannerPath;

      // 1. Upload logo if changed
      if (logoFile) {
        setUploadStatus('Uploading shop logo...');
        const logoRes = await uploadImageToSupabase(logoFile, {
          bucket: 'mb-product-images',
          folder: 'logos',
          maxSizeMB: 5,
        });
        if (logoRes.success && logoRes.url) {
          finalLogoUrl = logoRes.url;
          finalLogoPath = logoRes.path;
        } else if (logoRes.error) {
          throw new Error(`Logo upload: ${logoRes.error}`);
        }
      }

      // 2. Upload banner if changed
      if (bannerFile) {
        setUploadStatus('Uploading cover banner...');
        const bannerRes = await uploadImageToSupabase(bannerFile, {
          bucket: 'mb-product-images',
          folder: 'banners',
          maxSizeMB: 8,
        });
        if (bannerRes.success && bannerRes.url) {
          finalBannerUrl = bannerRes.url;
          finalBannerPath = bannerRes.path;
        } else if (bannerRes.error) {
          throw new Error(`Banner upload: ${bannerRes.error}`);
        }
      }

      // 3. Save shop updates to database
      setUploadStatus('Saving changes to Supabase database...');
      const res = await updateShop({
        shopId: shop.id,
        name: cleanShopName,
        shopName: cleanShopName,
        ownerName: cleanOwner || shop.ownerName,
        category: category.trim(),
        city: cleanCity,
        area: area.trim(),
        address: cleanAddress || cleanCity,
        phone: phoneValidation.formatted,
        description: description.trim(),
        logoUrl: finalLogoUrl,
        logoPath: finalLogoPath,
        bannerUrl: finalBannerUrl,
        bannerPath: finalBannerPath,
      });

      setSuccessMessage('Shop details, images, and category updated successfully!');
      if (onSuccess && res.shop) {
        onSuccess(res.shop);
      }

      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error('Shop update error:', err);
      setErrorMessage(err.message || 'Failed to save shop updates. Please try again.');
    } finally {
      setIsSubmitting(false);
      setUploadStatus('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-2xs">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Edit Shop
              </h2>
              <p className="text-xs text-slate-500">
                Update your shop photo, banner, and details.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Status Alerts */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* 1. MEDIA PICKERS: BANNER & LOGO */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-800">
              Shop Logo &amp; Banner
            </label>

            {/* Banner Cover with Logo Overlay */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-gradient-to-r from-blue-900 to-indigo-900 h-36 sm:h-44 group">
              {bannerPreview ? (
                <img
                  src={bannerPreview}
                  alt="Shop Banner Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-white/70 space-y-1">
                  <ImageIcon className="w-8 h-8 opacity-40" />
                  <span className="text-xs font-bold">No banner</span>
                </div>
              )}

              {/* Banner Upload Button Overlay */}
              <label className="absolute top-3 right-3 bg-slate-900/70 hover:bg-slate-900/90 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl backdrop-blur-md cursor-pointer flex items-center gap-1.5 border border-white/20 transition-all shadow-md">
                <Camera className="w-3.5 h-3.5" />
                <span>{bannerFile ? 'Change Banner' : 'Upload Banner'}</span>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleBannerChange}
                  className="hidden"
                />
              </label>

              {/* Logo Overlay at bottom left */}
              <div className="absolute bottom-3 left-4 flex items-end gap-3 z-10">
                <div className="relative group/logo">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white border-2 border-white shadow-lg p-1 overflow-hidden flex items-center justify-center">
                    {logoPreview ? (
                      <img
                        src={logoPreview}
                        alt="Shop Logo Preview"
                        className="w-full h-full object-contain rounded-xl"
                      />
                    ) : (
                      <Store className="w-8 h-8 text-blue-600" />
                    )}
                  </div>

                  <label className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover/logo:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold cursor-pointer transition-opacity">
                    <Camera className="w-4 h-4 mb-0.5" />
                    <span>Change</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleLogoChange}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/20 text-white text-xs">
                  <p className="font-extrabold truncate max-w-[160px] sm:max-w-xs">{shopName || shop.name}</p>
                  <label className="text-[10px] text-blue-300 underline cursor-pointer hover:text-white">
                    Change Logo
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleLogoChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-500">
              Recommended: Square for logo, wide for banner.
            </p>
          </div>

          {/* 2. SHOP NAME & CATEGORY */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Shop Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Store className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="e.g. Al-Madina Store"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Shop Category <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Tag className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all appearance-none cursor-pointer"
                >
                  {categoryOptions.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 3. PROPRIETOR NAME & WHATSAPP PHONE */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Owner Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Usman"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                WhatsApp Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="03001234567"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all"
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">Used for customer orders.</p>
            </div>
          </div>

          {/* 4. CITY & AREA / LOCATION */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                City <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all appearance-none cursor-pointer"
                >
                  {PAKISTANI_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Area / Market
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  placeholder="e.g. Saddar"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all"
                />
              </div>
            </div>
          </div>

          {/* 5. FULL ADDRESS */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Shop Address
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Shop #12, Commercial Plaza, Main Boulevard"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all"
            />
          </div>

          {/* 6. DESCRIPTION / BIO */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your products, warranty, delivery time..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:border-blue-500 outline-hidden transition-all leading-relaxed"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
            <span className="text-[11px] text-slate-500">
              {uploadStatus || 'Updates live instantly'}
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
