'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Logo } from './Logo';
import { InstallAppButton } from './InstallAppButton';
import { ShopNotifications } from './ShopNotifications';
import { useStore } from '@/context/StoreContext';
import { createWhatsAppLink, formatDisplayPakistaniPhone } from '@/lib/whatsapp';
import {
  Search,
  Heart,
  ShoppingCart,
  User,
  Menu,
  X,
  ChevronDown,
  Shield,
  Package,
  LogOut,
  Flame,
  HelpCircle,
  Phone,
  MessageCircle,
  Sparkles,
  ArrowRight,
  Crown,
  Store,
} from 'lucide-react';
import Image from 'next/image';
import { formatCurrency } from '@/lib/utils';

export const Navbar: React.FC = () => {
  const router = useRouter();
  const {
    cartCount,
    wishlist,
    user,
    isAdmin,
    setIsCartOpen,
    products,
    categories,
    settings,
    logout,
    switchDemoAccount,
    shops,
  } = useStore();

  const userShop = shops.find(
    (s) =>
      (user?.uid && s.ownerId === user.uid) ||
      (user?.email && s.email.toLowerCase() === user.email.toLowerCase())
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
      if (accountRef.current && !accountRef.current.contains(event.target as Node)) {
        setIsAccountMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter search suggestions
  const searchResults = searchQuery.trim()
    ? products
        .filter(
          (p) =>
            p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
        )
        .slice(0, 5)
    : [];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearchOpen(false);
    router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white shadow-xs">
      {/* Top Promotional Announcement Bar */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white text-xs font-semibold py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <Link
            href="/shops"
            className="flex items-center gap-1.5 hover:underline hidden sm:flex group tracking-wide"
          >
            <span>Discover products. Build your own shop.</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <div className="flex items-center gap-2 text-[11px] shrink-0">
            <InstallAppButton />
            <Link href="/open-shop" className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 font-bold text-blue-700 hover:bg-blue-50">Open Shop <ArrowRight className="w-3.5 h-3.5" /></Link>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20 gap-0 sm:gap-4">
          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
            aria-label="Toggle navigation menu"
            suppressHydrationWarning
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Mega Bazar Logo */}
          <div className="shrink-0">
            <Logo size="md" showTagline={true} compactOnMobile />
          </div>

          {/* Search Bar - Desktop & Tablet */}
          <div ref={searchRef} className="hidden md:flex flex-1 max-w-xl mx-4 relative" suppressHydrationWarning>
            <form onSubmit={handleSearchSubmit} className="w-full relative flex items-center" suppressHydrationWarning>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                onFocus={() => setIsSearchOpen(true)}
                placeholder="Search for products, brands and more..."
                suppressHydrationWarning
                className="w-full pl-10 pr-24 py-2.5 bg-slate-100/80 hover:bg-slate-100 focus:bg-white text-xs sm:text-sm rounded-full border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-hidden transition-all text-slate-800"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
              <button
                type="submit"
                suppressHydrationWarning
                className="absolute right-1.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-full transition-colors flex items-center gap-1 shadow-xs"
              >
                Search
              </button>
            </form>

            {/* Live Search Suggestion Dropdown */}
            {isSearchOpen && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden z-50">
                <div className="p-2 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3">
                  Matching Products
                </div>
                <div className="divide-y divide-slate-50">
                  {searchResults.map((item) => (
                    <Link
                      key={item.id}
                      href={`/product/${item.id}`}
                      onClick={() => setIsSearchOpen(false)}
                      className="p-3 flex items-center gap-3 hover:bg-blue-50/50 transition-colors"
                    >
                      <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                        <Image
                          src={item.images[0] || ''}
                          alt={item.name}
                          fill
                          sizes="40px"
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold text-slate-900 truncate">{item.name}</h4>
                        <span className="text-[11px] text-blue-600 font-medium">{item.category}</span>
                      </div>
                      <span className="text-xs font-bold text-slate-900">
                        {formatCurrency(item.price, settings.currency)}
                      </span>
                    </Link>
                  ))}
                </div>
                <div className="p-2.5 bg-slate-50 text-center border-t border-slate-100">
                  <Link
                    href={`/search?q=${encodeURIComponent(searchQuery)}`}
                    onClick={() => setIsSearchOpen(false)}
                    className="text-xs font-bold text-blue-600 hover:underline flex items-center justify-center gap-1"
                  >
                    View all matching results ({searchResults.length}+)
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* Quick Action Icons: Account, Wishlist, Cart */}
          <div className="flex items-center gap-0 sm:gap-4">
            {/* Account Dropdown */}
            <div ref={accountRef} className="relative" suppressHydrationWarning>
              <button
                onClick={() => setIsAccountMenuOpen(!isAccountMenuOpen)}
                className="flex items-center gap-1.5 p-2 rounded-xl text-slate-700 hover:text-blue-600 hover:bg-slate-100 transition-colors"
                aria-label="User Account"
                suppressHydrationWarning
              >
                <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs border border-slate-200">
                  {user ? user.displayName.charAt(0).toUpperCase() : <User className="w-4 h-4" />}
                </div>
                <span className="hidden xl:inline text-xs font-semibold text-slate-800 max-w-[100px] truncate">
                  {user ? user.displayName : 'Account'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden xl:inline" />
              </button>

              {/* Account Dropdown Menu */}
              {isAccountMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 divide-y divide-slate-100">
                  {/* User Header with Gmail */}
                  <div className="px-4 py-3 bg-slate-50/70">
                    <p className="text-xs font-black text-slate-900 truncate">
                      {user ? user.displayName : 'Guest User'}
                    </p>
                    <p className="text-[11px] text-blue-600 font-semibold truncate mt-0.5">
                      {user ? user.email : 'Sign in to access your shop & profile'}
                    </p>
                    {userShop && (
                      <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                        <Store className="w-3 h-3 text-emerald-600 shrink-0" />
                        <span className="truncate">Shop: {userShop.name}</span>
                      </div>
                    )}
                  </div>

                  {/* Main Action: My Profile */}
                  <div className="p-2 space-y-1">
                    {user ? (
                      <Link
                        href="/seller/dashboard"
                        onClick={() => setIsAccountMenuOpen(false)}
                        className="flex items-center justify-between w-full px-3.5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-xs transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>My Profile</span>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    ) : (
                      <Link
                        href="/login?next=/seller/dashboard"
                        onClick={() => setIsAccountMenuOpen(false)}
                        className="flex items-center justify-between w-full px-3.5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-xs transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>Sign In</span>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    )}

                    {/* Admin Access if applicable */}
                    {user && (isAdmin || user.role === 'admin' || user.role === 'super_admin' || user.email === 'moizziom84@gmail.com') && (
                      <Link
                        href="/admin"
                        onClick={() => setIsAccountMenuOpen(false)}
                        className="flex items-center gap-2 px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-950 font-bold text-xs rounded-xl transition-colors"
                      >
                        <Shield className="w-3.5 h-3.5 text-amber-600" />
                        <span>Super Admin Panel 🔒</span>
                      </Link>
                    )}
                  </div>

                  {/* Logout / Login */}
                  <div className="py-1">
                    {user ? (
                      <button
                        onClick={() => {
                          logout();
                          setIsAccountMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 transition-colors"
                      >
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    ) : (
                      <Link
                        href="/login"
                        onClick={() => setIsAccountMenuOpen(false)}
                        className="flex items-center gap-2.5 px-4 py-2 text-xs font-bold text-blue-600 hover:bg-blue-50 transition-colors"
                      >
                        <User className="w-4 h-4" /> Sign In / Register
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Notifications Bell */}
            <ShopNotifications />

            {/* Wishlist Button */}
            <Link
              href="/account/wishlist"
              className="relative hidden sm:inline-flex p-2.5 rounded-xl border border-transparent hover:border-slate-200 hover:bg-slate-50 text-slate-700 hover:text-rose-600 transition-all"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-extrabold rounded-full flex items-center justify-center shadow-xs">
                  {wishlist.length}
                </span>
              )}
            </Link>

            {/* Shopping Cart Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative px-3 py-2 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 text-slate-800 transition-all flex items-center gap-2 cursor-pointer group"
              aria-label="Shopping Cart"
              suppressHydrationWarning
            >
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-slate-700 group-hover:text-blue-600 transition-colors" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 min-w-5 h-5 px-1 bg-blue-600 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-xs">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline text-xs font-bold text-slate-800 group-hover:text-blue-600 transition-colors">
                Cart
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="md:hidden pb-3">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for products, brands and more..."
              className="w-full pl-10 pr-20 py-2 bg-slate-100 focus:bg-white text-xs rounded-xl border border-slate-200 focus:border-blue-500 outline-hidden"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <button
              type="submit"
              className="absolute right-1 px-3 py-1 bg-blue-600 text-white font-bold text-[11px] rounded-lg"
            >
              Search
            </button>
          </form>
        </div>
      </div>

      {/* Primary Category Navigation Bar */}
      <nav className="hidden lg:block border-t border-slate-100 bg-white shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center gap-7 py-2.5 text-xs font-bold tracking-tight text-slate-700">
            <li>
              <Link href="/" className="hover:text-blue-600 transition-colors py-1">
                Home
              </Link>
            </li>
            <li>
              <Link href="/products" className="hover:text-blue-600 transition-colors py-1">
                All Products
              </Link>
            </li>
            <li>
              <Link href="/shops" className="inline-flex items-center gap-1.5 text-blue-700 hover:text-blue-800 font-extrabold transition-colors py-1">
                <Store className="w-3.5 h-3.5 text-blue-600" />
                Verified Shops
              </Link>
            </li>
            {categories.slice(0, 5).map((cat) => (
              <li key={cat.id}>
                <Link
                  href={`/category/${cat.slug}`}
                  className="hover:text-blue-600 transition-colors py-1"
                >
                  {cat.name}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/categories" className="hover:text-blue-600 transition-colors py-1 text-slate-500">
                All Categories
              </Link>
            </li>
            <li className="ml-auto flex items-center gap-3">
              <Link
                href="/seller/dashboard"
                className="text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors"
              >
                Seller Dashboard
              </Link>
              <Link
                href="/open-shop"
                className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition-all flex items-center gap-1.5 shadow-xs"
              >
                <Store className="w-3.5 h-3.5" /> Open Shop
              </Link>
            </li>
          </ul>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs">
          <div className="fixed inset-y-0 left-0 w-4/5 max-w-sm bg-white shadow-2xl p-5 flex flex-col justify-between">
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <Logo size="sm" />
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Mobile Navigation Links */}
              <ul className="space-y-3 text-sm font-semibold text-slate-800">
                <li>
                  <Link
                    href="/"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block py-2 hover:text-blue-600"
                  >
                    Home
                  </Link>
                </li>
                <li>
                  <Link
                    href="/products"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block py-2 hover:text-blue-600"
                  >
                    All Products
                  </Link>
                </li>
                <li>
                  <Link
                    href="/open-shop"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center gap-2 py-2 text-blue-600 font-bold"
                  >
                    <Store className="w-4 h-4" /> Open Shop
                  </Link>
                </li>
                <li>
                  <Link
                    href="/shops"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center gap-1.5 py-2 text-rose-600 font-bold"
                  >
                    <Flame className="w-4 h-4 fill-rose-500" /> Flash Shops
                  </Link>
                </li>
                <li className="pt-2 border-t border-slate-100">
                  <span className="text-xs text-slate-400 uppercase font-bold tracking-wider block mb-2">
                    Popular Categories
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {categories.map((c) => (
                      <Link
                        key={c.id}
                        href={`/category/${c.slug}`}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="py-1.5 px-2.5 bg-slate-50 hover:bg-blue-50 rounded-lg text-slate-700 hover:text-blue-600"
                      >
                        {c.name}
                      </Link>
                    ))}
                  </div>
                </li>
                <li className="pt-2 border-t border-slate-100 space-y-1">
                  <Link
                    href="/account/orders"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block py-1.5 text-xs text-slate-600 hover:text-blue-600"
                  >
                    Track Orders
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

