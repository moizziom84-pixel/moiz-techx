import React from 'react';
import Link from 'next/link';
import SafeImage from '@/components/SafeImage';
import { Product } from '@/lib/types';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, calculateDiscount } from '@/lib/utils';
import { createWhatsAppLink, formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
import { Heart, ShoppingCart, Star, Eye, MessageCircle, Store, CheckCircle2 } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  priority?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, priority = false }) => {
  const { addToCart, toggleWishlist, isInWishlist, settings } = useStore();
  const inWishlist = isInWishlist(product.id);
  const discount = product.discountPercentage || calculateDiscount(product.originalPrice, product.price);

  const productSize =
    product.size ||
    product.attributes?.size ||
    product.specifications?.Size ||
    product.specifications?.size ||
    (product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined);

  const fallbackImage = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';
  const rawImage = product.images && product.images.length > 0 && product.images[0] ? product.images[0] : fallbackImage;

  const sellerPhone = product.whatsappNumber || product.sellerWhatsapp || '';
  const cardWhatsAppUrl = createWhatsAppLink(
    sellerPhone,
    `Product Link: ${typeof window !== "undefined" ? window.location.origin : "https://megabazar.pk"}/product/${product.id}\nHello! I would like to order this item on Mega Bazar:\n\n📦 *${product.name}*\n💰 *Price:* ${formatCurrency(product.price, settings.currency)}\n🔢 *SKU:* ${product.sku || product.id}\n\nPlease share delivery and cash on delivery details.`
  );

  const shopSlug = product.shopSlug || (product.shopName ? product.shopName.toLowerCase().replace(/[^a-z0-9]+/g, '-') : undefined);
  const shopName = product.shopName || product.brand;

  return (
    <div className="group relative bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-blue-200 transition-all duration-300 flex flex-col overflow-hidden">
      {/* Product Image & Badges Container */}
      <div className="relative w-full aspect-square bg-slate-50 overflow-hidden">
        {/* Badges on Top Left */}
        <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
          {discount > 0 && (
            <span className="px-2 py-0.5 bg-rose-600 text-white text-[11px] font-extrabold rounded-md shadow-xs tracking-tight">
              -{discount}%
            </span>
          )}
          {product.stock <= 0 && (
            <span className="px-2 py-0.5 bg-slate-800 text-white text-[10px] font-bold rounded-md shadow-xs">
              Out of stock
            </span>
          )}
        </div>

        {/* Wishlist Heart Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          suppressHydrationWarning
          className={`absolute top-2.5 right-2.5 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
            inWishlist
              ? 'bg-rose-50 text-rose-500 shadow-xs ring-1 ring-rose-200'
              : 'bg-white/90 backdrop-blur-xs text-slate-400 hover:text-rose-500 hover:bg-white shadow-xs'
          }`}
          aria-label={inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 transition-transform active:scale-125 ${inWishlist ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Main Product Image with subtle zoom */}
        <Link href={`/product/${product.id}`} className="block w-full h-full">
          <SafeImage
            src={rawImage}
            fallbackSrc={fallbackImage}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            priority={priority}
            className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          />
        </Link>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-x-0 bottom-2.5 px-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex justify-center gap-1.5 pointer-events-none group-hover:pointer-events-auto">
          <Link
            href={`/product/${product.id}`}
            className="px-3.5 py-1.5 bg-white/95 backdrop-blur-xs hover:bg-blue-600 text-slate-800 hover:text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all"
          >
            <Eye className="w-3.5 h-3.5" /> Quick View
          </Link>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Shop / Category Header */}
          <div className="flex items-center justify-between gap-1 mb-1.5 text-[11px]">
            <span className="font-semibold text-blue-600 uppercase tracking-wider truncate">
              {product.category}
            </span>
            {shopName && (
              <Link
                href={shopSlug ? `/shop/${shopSlug}` : '/shops'}
                onClick={(e) => e.stopPropagation()}
                className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-blue-600 truncate max-w-[120px]"
                title={`Visit ${shopName}`}
              >
                <Store className="w-3 h-3 shrink-0 text-slate-400" />
                <span className="truncate">{shopName}</span>
              </Link>
            )}
          </div>

          {/* Product Title */}
          <Link
            href={`/product/${product.id}`}
            className="text-xs sm:text-sm font-semibold text-slate-900 line-clamp-2 hover:text-blue-600 transition-colors leading-snug"
            title={product.name}
          >
            {product.name}
          </Link>

          {/* Rating & Size Indicator */}
          <div className="flex items-center justify-between gap-2 mt-1.5">
            <div className="flex items-center gap-1">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3 h-3 ${
                      product.reviewCount > 0 && i < Math.floor(product.rating || 0)
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-slate-200 fill-slate-200'
                    }`}
                  />
                ))}
              </div>
              <span className="text-[11px] text-slate-400 font-medium">
                {product.reviewCount > 0 ? `(${product.reviewCount})` : ''}
              </span>
            </div>

            {productSize && (
              <span className="text-[10px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                {productSize}
              </span>
            )}
          </div>
        </div>

        {/* Price & Add to Cart Footer */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <span className="text-sm sm:text-base font-black text-slate-900 leading-none">
              {formatCurrency(product.price, settings.currency)}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-[11px] text-slate-400 line-through mt-0.5">
                {formatCurrency(product.originalPrice, settings.currency)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {/* Direct WhatsApp Inquiry */}
            {formatPakistaniWhatsAppNumber(sellerPhone).isValid && (
              <a
                href={cardWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="w-8 h-8 rounded-xl bg-emerald-50 hover:bg-[#25D366] text-[#25D366] hover:text-white flex items-center justify-center transition-all duration-200 shadow-2xs active:scale-95 group/wa"
                title="Direct WhatsApp Order"
                aria-label="Order on WhatsApp"
              >
                <MessageCircle className="w-4 h-4 fill-current transition-transform group-hover/wa:scale-110" />
              </a>
            )}

            {/* Add to Cart CTA */}
            <button
              onClick={() => addToCart(product, 1, productSize)}
              disabled={product.stock <= 0}
              suppressHydrationWarning
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center transition-all duration-200 shadow-2xs ${
                product.stock <= 0
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white active:scale-95'
              }`}
              title={product.stock <= 0 ? 'Out of stock' : 'Add to cart'}
              aria-label="Add to cart"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

