import { apiFetch } from '@/lib/api';
'use client';

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useMemo,
  useCallback,
} from 'react';
import {
  Product,
  Category,
  CartItem,
  Order,
  Coupon,
  Banner,
  Review,
  StoreSettings,
  UserProfile,
  NotificationItem,
  OrderStatus,
  PaymentStatus,
  PaymentMethod,
  SellerShop,
  ShopStatus,
  Complaint,
} from '@/lib/types';
import {
  INITIAL_SETTINGS,
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_BANNERS,
  INITIAL_COUPONS,
  INITIAL_REVIEWS,
  INITIAL_ORDERS,
} from '@/lib/demo-data';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { mapShop, submitShop, reviewShop, updateShopProfile } from '@/lib/marketplace/shops';
import { marketplaceEnabled } from '@/lib/marketplace/browser';
import { formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
import { generateShopSlug } from '@/lib/utils';

interface StoreContextType {
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  coupons: Coupon[];
  banners: Banner[];
  reviews: Review[];
  settings: StoreSettings;
  notifications: NotificationItem[];
  user: UserProfile | null;
  isAdmin: boolean;
  isAdminAuthenticated: boolean;
  verifyAdminPassword: (password: string) => boolean | Promise<boolean>;
  verifyAdminCredentials: (identifier: string, password: string) => Promise<boolean> | boolean;
  logoutAdmin: () => void;
  updateAdminPassword: (newPassword: string) => Promise<void>;
  updateAdminCredentials: (newEmail: string, newPassword?: string, newUsername?: string) => Promise<void>;
  isCartOpen: boolean;
  activeCoupon: Coupon | null;
  cartSubtotal: number;
  cartDiscount: number;
  cartShipping: number;
  cartTax: number;
  cartGrandTotal: number;
  cartCount: number;

  // Actions
  setIsCartOpen: (open: boolean) => void;
  addToCart: (product: Product, quantity?: number, selectedSize?: string) => void;
  removeFromCart: (productId: string, selectedSize?: string) => void;
  updateCartQuantity: (productId: string, quantity: number, selectedSize?: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  applyCoupon: (code: string) => { success: boolean; message: string; discount: number };
  removeCoupon: () => void;
  placeOrder: (orderData: Partial<Order>) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: OrderStatus, trackingNumber?: string) => Promise<void>;
  updateOrderPaymentStatus: (orderId: string, paymentStatus: PaymentStatus, transactionId?: string) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  refreshOrders: () => Promise<void>;
  refreshProducts: () => Promise<void>;
  refreshShops: () => Promise<void>;

  // Marketplace Shops & Complaints
  shops: SellerShop[];
  complaints: Complaint[];
  registerShop: (data: {
    fullName: string;
    phone: string;
    email: string;
    shopName: string;
    city: string;
    address: string;
    logoUrl?: string;
    acceptedTerms?: boolean;
    description?: string;
  }) => Promise<{ success: boolean; shop: SellerShop; message: string }>;
  updateShop: (data: {
    shopId?: string;
    shopName?: string;
    name?: string;
    ownerName?: string;
    category?: string;
    city?: string;
    area?: string;
    address?: string;
    phone?: string;
    description?: string;
    logoUrl?: string;
    logoPath?: string;
    bannerUrl?: string;
    bannerPath?: string;
    ownerAvatarUrl?: string;
  }) => Promise<{ success: boolean; shop: SellerShop; message: string }>;
  approveShop: (shopId: string) => Promise<void>;
  rejectShop: (shopId: string, reason: string) => Promise<void>;
  suspendShop: (shopId: string) => Promise<void>;
  reactivateShop: (shopId: string) => Promise<void>;
  addComplaint: (data: Omit<Complaint, 'id' | 'ticketNumber' | 'createdAt' | 'status'>) => Promise<void>;
  updateComplaintStatus: (id: string, status: Complaint['status'], resolutionNotes?: string) => Promise<void>;

  // Admin Actions
  createProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Product>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<{ success: boolean; message: string }>;
  createCategory: (cat: Omit<Category, 'id'>) => Promise<Category>;
  updateCategory: (id: string, updates: Partial<Category>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  createCoupon: (coupon: Omit<Coupon, 'id'>) => Promise<Coupon>;
  updateCoupon: (id: string, updates: Partial<Coupon>) => Promise<void>;
  deleteCoupon: (id: string) => Promise<void>;
  updateSettings: (updates: Partial<StoreSettings>) => Promise<void>;
  createReview: (review: Omit<Review, 'id' | 'createdAt'>) => Promise<Review>;
  moderateReview: (id: string, status: 'approved' | 'rejected') => Promise<void>;
  resetDemoData: () => Promise<void>;
  deleteDemoProducts: () => void;

  // Auth & Notifications
  login: (email: string, role?: 'customer' | 'admin' | 'super_admin' | 'seller', name?: string) => void;
  logout: () => void;
  switchDemoAccount: (role: 'admin' | 'customer') => void;
  markNotificationAsRead: (id: string) => void;
  addNotification: (title: string, message: string, type?: NotificationItem['type']) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

const STORAGE_KEYS = {
  PRODUCTS: 'mb_products_v1',
  CATEGORIES: 'mb_categories_v1',
  ORDERS: 'mb_orders_v1',
  SETTINGS: 'mb_settings_v1',
  COUPONS: 'mb_coupons_v1',
  BANNERS: 'mb_banners_v1',
  REVIEWS: 'mb_reviews_v1',
  CART: 'mb_cart_v1',
  WISHLIST: 'mb_wishlist_v1',
  USER: 'mb_user_v1',
  NOTIFICATIONS: 'mb_notifications_v1',
  ADMIN_AUTH: 'mb_admin_auth_v1',
  SHOPS: 'mb_seller_shops_v1',
  COMPLAINTS: 'mb_complaints_v1',
};

const INITIAL_SHOPS: SellerShop[] = [
  {
    id: 'shop-demo-1',
    ownerId: 'seller-zainab',
    ownerName: 'Zainab Bibi',
    email: 'zainab@rangboutique.pk',
    phone: '03001234567',
    name: 'Rang Boutique',
    slug: 'rang-boutique',
    category: 'Fashion & Clothing',
    city: 'Karachi',
    address: 'Shop 14, Tariq Road, PECHS, Karachi',
    logoUrl: '/demo-shops/fashion.webp',
    description: 'A warm, modern boutique for embroidered essentials and colourful everyday wardrobes.',
    status: 'Approved',
    isVerified: true,
    commissionRate: '5%',
    createdAt: '2026-10-15T10:00:00.000Z',
    updatedAt: '2026-10-15T10:00:00.000Z',
  },
  {
    id: 'shop-demo-2',
    ownerId: 'seller-ali',
    ownerName: 'Ali Raza',
    email: 'ali@pixeltech.pk',
    phone: '03129876543',
    name: 'Pixel Tech',
    slug: 'pixel-tech',
    category: 'Electronics & Audio',
    city: 'Lahore',
    address: 'Plaza 4B, Hafeez Centre, Gulberg III, Lahore',
    logoUrl: '/demo-shops/electronics.webp',
    description: 'Clean collection of audio, phone accessories and everyday tech essentials.',
    status: 'Approved',
    isVerified: true,
    commissionRate: '4%',
    createdAt: '2026-10-18T10:00:00.000Z',
    updatedAt: '2026-10-18T10:00:00.000Z',
  },
  {
    id: 'shop-demo-3',
    ownerId: 'seller-fatima',
    ownerName: 'Fatima Noor',
    email: 'fatima@gharstudio.pk',
    phone: '03335551234',
    name: 'Ghar Studio',
    slug: 'ghar-studio',
    category: 'Home & Living',
    city: 'Islamabad',
    address: 'Studio 9, Beverly Centre, Blue Area, Islamabad',
    logoUrl: '/demo-shops/home.webp',
    description: 'Thoughtful ceramics, soft textures and natural details for a comfortable home.',
    status: 'Approved',
    isVerified: true,
    commissionRate: '5%',
    createdAt: '2026-10-20T10:00:00.000Z',
    updatedAt: '2026-10-20T10:00:00.000Z',
  },
  {
    id: 'shop-demo-4',
    ownerId: 'seller-maryam',
    ownerName: 'Maryam Siddiqui',
    email: 'maryam@botanicalcare.pk',
    phone: '03214449876',
    name: 'Botanical Care',
    slug: 'botanical-care',
    category: 'Beauty & Personal Care',
    city: 'Karachi',
    address: 'Suite 201, Clifton Block 4, Karachi',
    logoUrl: '/demo-shops/beauty.webp',
    description: 'Botanical-inspired personal care and herbal wellness collection.',
    status: 'Approved',
    isVerified: true,
    commissionRate: '5%',
    createdAt: '2026-10-22T10:00:00.000Z',
    updatedAt: '2026-10-22T10:00:00.000Z',
  },
  {
    id: 'shop-demo-5',
    ownerId: 'seller-tariq',
    ownerName: 'Tariq Mehmood',
    email: 'tariq@playgroundsports.pk',
    phone: '03457778899',
    name: 'Playground Sports',
    slug: 'playground-sports',
    category: 'Sports & Outdoors',
    city: 'Faisalabad',
    address: 'Market 12, Kotwali Road, Faisalabad',
    logoUrl: '/demo-shops/sports.webp',
    description: 'Cricket starter kits, footballs, and active sports equipment.',
    status: 'Approved',
    isVerified: true,
    commissionRate: '4%',
    createdAt: '2026-10-25T10:00:00.000Z',
    updatedAt: '2026-10-25T10:00:00.000Z',
  },
];

const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'comp-101',
    ticketNumber: 'MB-CMP-101',
    customerName: 'Asad Malik',
    customerEmail: 'asad@example.com',
    customerPhone: '03019876543',
    shopName: 'Pixel Tech',
    orderNumber: 'MB-3372',
    subject: 'Delayed courier delivery update',
    description: 'Tracking status was not updated for 3 days by rider.',
    status: 'Investigating',
    priority: 'medium',
    createdAt: '2026-10-28T14:30:00.000Z',
    resolutionNotes: 'Contacted rider dispatch desk in Lahore; package out for delivery today.',
  },
  {
    id: 'comp-102',
    ticketNumber: 'MB-CMP-102',
    customerName: 'Sana Farooq',
    customerEmail: 'sana.f@example.com',
    customerPhone: '03221234567',
    shopName: 'Rang Boutique',
    orderNumber: 'MB-2980',
    subject: 'Size exchange inquiry',
    description: 'Customer requested medium size instead of large kurta.',
    status: 'Resolved',
    priority: 'low',
    createdAt: '2026-10-24T09:15:00.000Z',
    resolutionNotes: 'Boutique agreed to size exchange via Trax courier.',
  },
];

const DEMO_CUSTOMER: UserProfile = {
  uid: 'cust-demo-1',
  email: 'customer@megabazar.pk',
  displayName: 'Emily Johnson',
  phone: '03182204441',
  role: 'customer',
  addresses: [
    {
      fullName: 'Emily Johnson',
      phone: '03182204441',
      address: 'House 14, Main Boulevard, Gulberg III',
      city: 'Lahore',
      province: 'Punjab',
      postalCode: '54000',
      country: 'Pakistan',
    },
  ],
  createdAt: '2026-10-01T00:00:00.000Z',
};

const DEMO_ADMIN: UserProfile = {
  uid: 'admin-1',
  email: 'admin@megabazar.pk',
  displayName: 'Mega Bazar Admin',
  phone: '03182204441',
  role: 'admin',
  addresses: [],
  createdAt: '2026-10-01T00:00:00.000Z',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Core Application State
  const [products, setProducts] = useState<Product[]>(isSupabaseConfigured ? [] : INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [banners, setBanners] = useState<Banner[]>(INITIAL_BANNERS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [shops, setShops] = useState<SellerShop[]>(() => {
    return isSupabaseConfigured ? [] : loadFromStorage<SellerShop[]>(STORAGE_KEYS.SHOPS, INITIAL_SHOPS);
  });
  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    return loadFromStorage<Complaint[]>(STORAGE_KEYS.COMPLAINTS, INITIAL_COMPLAINTS);
  });
  const [settings, setSettings] = useState<StoreSettings>(() => {
    const cached = { ...loadFromStorage<StoreSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS) };
    delete cached.adminPassword;
    return cached;
  });
  const [user, setUser] = useState<UserProfile | null>(() => {
    return isSupabaseConfigured ? null : loadFromStorage<UserProfile | null>(STORAGE_KEYS.USER, null);
  });

  useEffect(() => {
    if (!marketplaceEnabled) return;
    let mounted = true;
    const apply = (session: import('@supabase/supabase-js').Session | null) => {
      if (!mounted) return;
      if (!session) {
        setUser(null);
        setIsAdminAuthenticated(false);
        setShops([]);
        setOrders([]);
        return;
      }
      const isOwner = session.user.app_metadata?.role === 'super_admin';
      const appRole = session.user.app_metadata?.role as string;
      const userRole = session.user.user_metadata?.role as string;
      const effectiveRole: 'customer' | 'admin' | 'super_admin' | 'seller' =
        isOwner || appRole === 'super_admin'
          ? 'super_admin'
          : appRole === 'admin'
          ? 'admin'
          : appRole === 'seller' || userRole === 'seller'
          ? 'seller'
          : 'customer';

      setIsAdminAuthenticated(effectiveRole === 'super_admin');
      setUser({
        uid: session.user.id,
        email: session.user.email || '',
        displayName:
          session.user.user_metadata?.display_name ||
          (isOwner ? 'Muhammad Moiz (Platform Owner)' : session.user.email?.split('@')[0] || 'Customer'),
        role: effectiveRole,
        phone: session.user.user_metadata?.phone,
        addresses: [],
        createdAt: session.user.created_at,
      });
    };
    supabase.auth.getSession().then(({ data }) => apply(data.session));
    const { data } = supabase.auth.onAuthStateChange((_event, session) => apply(session));
    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, []);


  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    if (isSupabaseConfigured) return false;
    if (typeof window !== 'undefined') {
      try {
        return (
          sessionStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true' ||
          localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true'
        );
      } catch {
        return false;
      }
    }
    return false;
  });
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'Welcome to Mega Bazar!',
      message: 'Use code MEGA10 to save 10% on your first order.',
      type: 'promo',
      read: false,
      createdAt: '2026-10-01T00:00:00.000Z',
    },
  ]);

  // Sync state helper to local storage
  const saveToStorage = (key: string, data: unknown) => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(key, JSON.stringify(data));
      } catch (err) {
        console.warn('Could not save to localStorage:', err);
      }
    }
  };

  // Dedicated server synchronization function for shared multi-device storage
  const refreshOrders = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setOrders([]); return; }
    try { const r = await apiFetch('/api/orders', { cache: 'no-store' }); const data = await r.json(); setOrders(data.orders || []); }
    catch (error) { console.warn('Order refresh failed:', error); }
  }, []);

  const refreshShops = useCallback(async () => {
    if (!isSupabaseConfigured) return;
    try {
      // 1. Fetch public approved shops so visitors and search can discover all live shops
      const { data: pubData } = await supabase.from('mb_public_shops').select('*');
      const publicList = (pubData || []).map(mapShop);

      // 2. Fetch authenticated seller/admin shops
      const { data: { user: account } } = await supabase.auth.getUser();
      if (!account) {
        setShops(publicList);
        return;
      }

      const owner = account.app_metadata?.role === 'super_admin';
      let query = supabase.from('mb_shops').select('*').order('created_at', { ascending: false });
      if (!owner) query = query.eq('owner_id', account.id);
      const { data: ownData, error } = await query;
      if (error && !publicList.length) throw new Error(`Could not load shops: ${error.message}`);

      const ownMapped = (ownData || []).map(mapShop);
      const mergedMap = new Map<string, SellerShop>();
      publicList.forEach((s) => mergedMap.set(s.id, s));
      ownMapped.forEach((s) => mergedMap.set(s.id, s));
      setShops(Array.from(mergedMap.values()));

      // 3. Load notifications
      const { data: notices } = await supabase
        .from('mb_notifications')
        .select('*')
        .eq('recipient_id', account.id)
        .order('created_at', { ascending: false })
        .limit(100);

      if (notices) {
        setNotifications((prev) => [
          ...notices.map((n) => ({
            id: `db-notice-${n.id}`,
            title: n.title,
            message: n.message,
            type: 'system' as const,
            read: !!n.read_at,
            createdAt: n.created_at,
            link: n.link,
          })),
          ...prev.filter((n) => !n.id.startsWith('db-')),
        ]);
      }
    } catch (err) {
      console.warn('Shop refresh error:', err);
    }
  }, []);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    let active = true;
    const refresh = () => {
      if (active) void refreshShops().catch((error) => console.warn(error.message));
    };
    refresh();

    if (user?.uid) {
      void supabase.from('complaints').select('*').then(({ data, error }) => {
        if (!error && active) {
          setComplaints(
            (data || []).map((r) => ({
              ...r.data,
              id: r.id,
              ticketNumber: `MB-CMP-${r.id.slice(-8)}`,
              status: r.status,
              resolutionNotes: r.resolution_notes,
              createdAt: r.created_at,
            }))
          );
        }
      });

      const channel = supabase
        .channel(`shops-${user.uid}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'mb_shops' }, refresh)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'mb_notifications', filter: `recipient_id=eq.${user.uid}` },
          refresh
        )
        .subscribe();
      const timer = window.setInterval(refresh, 15000);
      window.addEventListener('focus', refresh);
      return () => {
        active = false;
        clearInterval(timer);
        window.removeEventListener('focus', refresh);
        void supabase.removeChannel(channel);
      };
    }
  }, [user?.uid, refreshShops]);

  const refreshProducts = useCallback(async () => {
    if (typeof window === 'undefined') return;
    try {
      if (isSupabaseConfigured) {
        // 1. Fetch catalog products
        let query = supabase.from('products').select('*');
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user.app_metadata?.role !== 'super_admin') query = query.eq('status', 'active');
        const { data: catalogData } = await query;

        const catalogMapped: Product[] = (catalogData || []).map((item: any) => ({
          ...(item.client_data || {}),
          id: String(item.id || `prod-${Date.now()}`),
          name: String(item.name || 'Unnamed Product'),
          slug: String(item.slug || item.id || `prod-${Date.now()}`),
          sku: String(item.sku || `MB-${item.id?.slice(0, 5) || '100'}`),
          description: String(item.description || ''),
          shortDescription: item.short_description || undefined,
          seoTitle: item.meta_title || undefined,
          metaDescription: item.meta_description || undefined,
          imageAltText: item.image_alt_text || undefined,
          price: Number(item.price || 0),
          originalPrice: item.original_price ? Number(item.original_price) : Number(item.price || 0),
          discountPercentage: item.discount_percentage ? Number(item.discount_percentage) : 0,
          stock: Number(item.stock ?? 0),
          lowStockThreshold: Number(item.low_stock_threshold || 5),
          images: Array.isArray(item.images) && item.images.length > 0 ? item.images : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80'],
          specifications: (item.specifications && typeof item.specifications === 'object') ? item.specifications : {},
          category: String(item.category || 'General'),
          brand: String(item.brand || 'Mega Bazar'),
          rating: Number(item.rating ?? 5),
          reviewCount: Number(item.review_count || 0),
          isFeatured: Boolean(item.is_featured),
          isBestSeller: Boolean(item.is_trending || item.is_featured),
          isFlashDeal: Boolean(item.is_flash_deal),
          status: (item.status === 'active' || item.status === 'draft' || item.status === 'archived') ? item.status : 'active',
          tags: Array.isArray(item.keywords) ? item.keywords : [],
          whatsappNumber: item.client_data?.whatsappNumber || item.whatsapp_number || undefined,
          sellerWhatsapp: item.client_data?.sellerWhatsapp || item.seller_whatsapp || undefined,
          createdAt: item.created_at || new Date().toISOString(),
          updatedAt: item.updated_at || new Date().toISOString(),
        }));

        // 2. Fetch multi-vendor seller approved products
        let marketplaceMapped: Product[] = [];
        try {
          const { data: mpData, error: mpErr } = await supabase.from('mb_public_products').select('*');
          if (!mpErr && Array.isArray(mpData)) {
            marketplaceMapped = mpData.map((row: any) => {
              const d = row.details || {};
              const origPrice = Number(d.price || 0);
              const salePrice = d.salePrice ? Number(d.salePrice) : origPrice;
              const discount = origPrice > salePrice ? Math.round(((origPrice - salePrice) / origPrice) * 100) : 0;
              const images = Array.isArray(row.images) && row.images.length > 0
                ? row.images.map((img: string) =>
                    img.startsWith('http://') || img.startsWith('https://')
                      ? img
                      : supabase.storage.from('mb-product-images').getPublicUrl(img).data.publicUrl
                  )
                : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80'];

              return {
                id: row.id,
                name: d.name || 'Marketplace Product',
                slug: row.id,
                sku: `MB-${row.id.slice(0, 8)}`,
                category: d.category || 'General',
                brand: row.shop_name || 'Verified Merchant',
                description: d.description || '',
                shortDescription: d.contents || (d.description ? d.description.slice(0, 120) : undefined),
                price: salePrice,
                originalPrice: origPrice || salePrice,
                discountPercentage: discount,
                stock: Number(d.stock ?? 1),
                lowStockThreshold: 3,
                images,
                specifications: {
                  Condition: d.condition || 'New',
                  Dispatch: `${d.dispatch || 2} days`,
                  Location: row.city || 'Pakistan',
                  Shop: row.shop_name || 'Marketplace Store',
                },
                tags: [d.category, row.shop_name, 'Seller Product'].filter(Boolean),
                isFeatured: false,
                isBestSeller: false,
                isFlashDeal: Boolean(discount > 0),
                rating: 5,
                reviewCount: 0,
                status: 'active' as const,
                whatsappNumber: d.whatsapp || undefined,
                sellerWhatsapp: d.whatsapp || undefined,
                shopId: row.shop_id,
                shopSlug: row.shop_slug,
                shopName: row.shop_name,
                condition: d.condition || 'New',
                createdAt: row.created_at || new Date().toISOString(),
                updatedAt: row.updated_at || new Date().toISOString(),
              };
            });
          }
        } catch (mpCatch) {
          console.warn('Marketplace products fetch error:', mpCatch);
        }

        const combined = [...catalogMapped, ...marketplaceMapped];
        if (combined.length > 0) {
          setProducts(combined);
          saveToStorage(STORAGE_KEYS.PRODUCTS, combined);
          return;
        } else {
          // If both database tables have no active items yet, preserve demo data so store is never empty
          setProducts(INITIAL_PRODUCTS);
          return;
        }
      }

      const res = await apiFetch('/api/products', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
          saveToStorage(STORAGE_KEYS.PRODUCTS, data.products);
        }
      }
    } catch (err) {
      console.warn('Server products sync unavailable:', err);
    }
  }, []);

  const refreshSettings = useCallback(async () => {
    try {
      const results = await Promise.all(['/api/settings','/api/categories','/api/banners','/api/coupons','/api/reviews'].map(async url => (await apiFetch(url)).json()));
      setSettings({ ...INITIAL_SETTINGS, ...results[0].settings });
      setCategories(results[1].categories || []); setBanners(results[2].banners || []);
      setCoupons(results[3].coupons || []); setReviews(results[4].reviews || []);
    } catch (error) { console.warn('Store refresh failed:', error); }
  }, []);

  // Initial client hydration from local storage and background server fetch
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const storedProds = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
        if (!isSupabaseConfigured && storedProds) setProducts(JSON.parse(storedProds));

        const storedCats = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
        if (storedCats) setCategories(JSON.parse(storedCats));

        const storedCart = localStorage.getItem(STORAGE_KEYS.CART);
        if (storedCart) setCart(JSON.parse(storedCart));

        const storedWishlist = localStorage.getItem(STORAGE_KEYS.WISHLIST);
        if (storedWishlist) setWishlist(JSON.parse(storedWishlist));

        // Orders are loaded only from the authenticated, scoped API, never a shared browser cache.

        const storedCoupons = localStorage.getItem(STORAGE_KEYS.COUPONS);
        if (storedCoupons) setCoupons(JSON.parse(storedCoupons));

        const storedBanners = localStorage.getItem(STORAGE_KEYS.BANNERS);
        if (storedBanners) setBanners(JSON.parse(storedBanners));

        const storedReviews = localStorage.getItem(STORAGE_KEYS.REVIEWS);
        if (storedReviews) setReviews(JSON.parse(storedReviews));

        const storedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
        if (storedSettings) {
          const safeSettings = JSON.parse(storedSettings);
          delete safeSettings.adminPassword;
          setSettings(safeSettings);
          saveToStorage(STORAGE_KEYS.SETTINGS, safeSettings);
        }

        const storedUser = localStorage.getItem(STORAGE_KEYS.USER);
        if (storedUser && !isSupabaseConfigured) {
          try {
            const parsedUser = JSON.parse(storedUser);
            setUser(parsedUser);
            if (
              parsedUser.role === 'admin' ||
              parsedUser.role === 'super_admin' ||
              parsedUser.email?.toLowerCase() === 'moizziom84@gmail.com'
            ) {
              setIsAdminAuthenticated(true);
            }
          } catch {
            // ignore
          }
        }

        const storedNotifs = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
        if (storedNotifs) setNotifications(JSON.parse(storedNotifs));

        if (typeof window !== 'undefined') {
          const storedAdminAuth =
            localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) ||
            sessionStorage.getItem(STORAGE_KEYS.ADMIN_AUTH);
          if (!isSupabaseConfigured && storedAdminAuth === 'true') {
            setIsAdminAuthenticated(true);
          }
        }
      } catch (err) {
        console.warn('Error reading from storage:', err);
      }

      // Immediately sync with persistent server database
      refreshOrders();
      refreshProducts();
      refreshSettings();
    }, 0);

    // Setup periodic sync so Admin and multi-device updates reflect automatically
    const interval = setInterval(() => {
      refreshOrders();
    }, 8000);

    const handleFocus = () => {
      refreshOrders();
      refreshProducts();
      refreshSettings();
    };

    window.addEventListener('focus', handleFocus);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
    };
  }, [refreshOrders, refreshProducts, refreshSettings]);

  const addNotification = useCallback(
    (
      title: string,
      message: string,
      type: NotificationItem['type'] = 'system'
    ) => {
      const newNotif: NotificationItem = {
        id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        title,
        message,
        type,
        read: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => {
        const updated = [newNotif, ...prev];
        saveToStorage(STORAGE_KEYS.NOTIFICATIONS, updated);
        return updated;
      });
    },
    []
  );

  const markNotificationAsRead = useCallback((id: string) => {
    void (async () => {
      if (id.startsWith('db-notice-')) {
        const { error } = await supabase.from('mb_notifications').update({ read_at: new Date().toISOString() })
          .eq('id', id.slice('db-notice-'.length)).select('id').single();
        if (error) { alert(`Could not mark notification as read: ${error.message}`); return; }
      }
      setNotifications(prev => {
        const updated = prev.map(n => n.id === id ? { ...n, read: true } : n);
        saveToStorage(STORAGE_KEYS.NOTIFICATIONS, updated.filter(n => !n.id.startsWith('db-')));
        return updated;
      });
    })();
  }, []);

  // Cart operations
  const addToCart = useCallback(
    (product: Product, quantity: number = 1, selectedSize?: string) => {
      const targetSize =
        selectedSize ||
        product.size ||
        product.attributes?.size ||
        product.specifications?.Size ||
        product.specifications?.size ||
        (product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined);

      setCart((prev) => {
        const existing = prev.find(
          (item) => item.productId === product.id && item.selectedSize === targetSize
        );
        let updated: CartItem[];
        if (existing) {
          updated = prev.map((item) =>
            item.productId === product.id && item.selectedSize === targetSize
              ? { ...item, quantity: item.quantity + quantity }
              : item
          );
        } else {
          const newItem: CartItem = {
            productId: product.id,
            product,
            quantity,
            selectedSize: targetSize,
          };
          updated = [...prev, newItem];
        }
        saveToStorage(STORAGE_KEYS.CART, updated);
        return updated;
      });
      setIsCartOpen(true);
      addNotification(
        'Added to Cart',
        `${product.name}${targetSize ? ` (Size: ${targetSize})` : ''} (${quantity}x) has been added to your shopping bag.`,
        'order'
      );
    },
    [addNotification]
  );

  const removeFromCart = useCallback((productId: string, selectedSize?: string) => {
    setCart((prev) => {
      const updated = prev.filter((item) => {
        if (selectedSize !== undefined) {
          return !(item.productId === productId && item.selectedSize === selectedSize);
        }
        return item.productId !== productId;
      });
      saveToStorage(STORAGE_KEYS.CART, updated);
      return updated;
    });
  }, []);

  const updateCartQuantity = useCallback((productId: string, quantity: number, selectedSize?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, selectedSize);
      return;
    }
    setCart((prev) => {
      const updated = prev.map((item) => {
        const matches =
          item.productId === productId &&
          (selectedSize === undefined || item.selectedSize === selectedSize);
        return matches ? { ...item, quantity } : item;
      });
      saveToStorage(STORAGE_KEYS.CART, updated);
      return updated;
    });
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCart([]);
    setActiveCoupon(null);
    saveToStorage(STORAGE_KEYS.CART, []);
  }, []);

  // Wishlist operations
  const toggleWishlist = useCallback((productId: string) => {
    setWishlist((prev) => {
      let updated: string[];
      if (prev.includes(productId)) {
        updated = prev.filter((id) => id !== productId);
        addNotification('Removed from Wishlist', 'Product removed from your saved items.');
      } else {
        updated = [...prev, productId];
        addNotification('Saved to Wishlist', 'Product added to your wishlist.', 'promo');
      }
      saveToStorage(STORAGE_KEYS.WISHLIST, updated);
      return updated;
    });
  }, [addNotification]);

  const isInWishlist = useCallback(
    (productId: string) => wishlist.includes(productId),
    [wishlist]
  );

  // Cart financial calculations
  const cartSubtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }, [cart]);

  const cartDiscount = useMemo(() => {
    if (!activeCoupon) return 0;
    if (cartSubtotal < activeCoupon.minOrder) return 0;
    if (activeCoupon.discountType === 'percentage') {
      const discount = (cartSubtotal * activeCoupon.value) / 100;
      return activeCoupon.maxDiscount
        ? Math.min(discount, activeCoupon.maxDiscount)
        : discount;
    }
    return Math.min(activeCoupon.value, cartSubtotal);
  }, [cartSubtotal, activeCoupon]);

  const cartShipping = useMemo(() => {
    if (cartSubtotal === 0) return 0;
    const threshold = settings.freeShippingThreshold || 5000;
    if (cartSubtotal >= threshold) return 0;
    return settings.standardShippingFee || 250;
  }, [cartSubtotal, settings]);

  const cartTax = useMemo(() => {
    if (!settings.taxPercentage) return 0;
    return Math.round(((cartSubtotal - cartDiscount) * settings.taxPercentage) / 100);
  }, [cartSubtotal, cartDiscount, settings.taxPercentage]);

  const cartGrandTotal = useMemo(() => {
    return Math.max(0, cartSubtotal - cartDiscount + cartShipping + cartTax);
  }, [cartSubtotal, cartDiscount, cartShipping, cartTax]);

  const cartCount = useMemo(() => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  }, [cart]);

  // Coupon operations
  const applyCoupon = useCallback(
    (code: string) => {
      const found = coupons.find(
        (c) =>
          c.code.toUpperCase() === code.toUpperCase() && c.status === 'active'
      );
      if (!found) {
        return { success: false, message: 'Invalid or expired coupon code.', discount: 0 };
      }
      if (cartSubtotal < found.minOrder) {
        return {
          success: false,
          message: `Minimum order of ${settings.currency} ${found.minOrder} required for this coupon.`,
          discount: 0,
        };
      }
      setActiveCoupon(found);
      addNotification(
        'Coupon Applied',
        `Discount code "${found.code}" applied successfully!`,
        'promo'
      );
      return { success: true, message: 'Coupon applied successfully!', discount: 0 };
    },
    [coupons, cartSubtotal, settings.currency, addNotification]
  );

  const removeCoupon = useCallback(() => {
    setActiveCoupon(null);
    addNotification('Coupon Removed', 'Promo code has been removed from your cart.');
  }, [addNotification]);

  // ==========================================
  // REAL MULTI-DEVICE PERSISTENT ORDER CREATION
  // ==========================================
  const placeOrder = useCallback(
    async (orderData: Partial<Order>): Promise<Order> => {
      const orderItems =
        orderData.items ||
        cart.map((i) => ({
          productId: i.productId,
          name: i.product.name,
          image: i.product.images[0] || '',
          price: i.product.price,
          originalPrice: i.product.originalPrice,
          quantity: i.quantity,
          selectedSize:
            i.selectedSize ||
            i.product.size ||
            i.product.attributes?.size ||
            i.product.specifications?.Size,
          sku: i.product.sku,
        }));

      if (!orderItems || orderItems.length === 0) {
        throw new Error('Your cart is empty. Please add items to place an order.');
      }

      const orderPayload = {
        userId: user?.uid,
        customerName: orderData.customerName || user?.displayName || 'Customer',
        email: orderData.email || user?.email || 'customer@megabazar.pk',
        phone: orderData.phone || user?.phone || '',
        shippingAddress: orderData.shippingAddress,
        items: orderItems,
        subtotal: orderData.subtotal ?? cartSubtotal,
        discount: orderData.discount ?? cartDiscount,
        shippingFee: orderData.shippingFee ?? cartShipping,
        tax: orderData.tax ?? cartTax,
        grandTotal: orderData.grandTotal ?? cartGrandTotal,
        paymentMethod: orderData.paymentMethod || 'cod',
        transactionId: orderData.transactionId,
        paymentProofUrl: orderData.paymentProofUrl,
        notes: orderData.notes,
        deliveryMethod: orderData.deliveryMethod || 'Standard Delivery (2-4 Days)',
        appliedCoupon: activeCoupon?.code,
      };

      try {
        const { data: { session: orderSession } } = await supabase.auth.getSession();
        const response = await apiFetch('/api/orders', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(orderSession ? { Authorization: `Bearer ${orderSession.access_token}` } : {}),
          },
          body: JSON.stringify(orderPayload),
        });

        const result = await response.json();

        if (!response.ok || !result.success || !result.order) {
          throw new Error(result.message || 'Failed to create order on server');
        }

        const savedOrder: Order = result.order;

        // Update local orders state
        setOrders((prev) => {
          const updated = [savedOrder, ...prev.filter((o) => o.id !== savedOrder.id)];
          saveToStorage(STORAGE_KEYS.ORDERS, updated);
          return updated;
        });

        // Decrement local product stock
        setProducts((prev) => {
          const updated = prev.map((p) => {
            const match = savedOrder.items.find((item) => item.productId === p.id);
            if (match) {
              return { ...p, stock: Math.max(0, p.stock - match.quantity) };
            }
            return p;
          });
          saveToStorage(STORAGE_KEYS.PRODUCTS, updated);
          return updated;
        });

        // Clear local cart
        clearCart();

        addNotification(
          'Order Placed Successfully!',
          `Order #${savedOrder.orderNumber} for ${settings.currency} ${savedOrder.grandTotal} is received and recorded.`,
          'order'
        );

        return savedOrder;
      } catch (error: unknown) {
        console.error('Checkout error in placeOrder:', error);
        const errMessage =
          error instanceof Error
            ? error.message
            : 'Unable to connect to order server. Please check your internet connection.';
        throw new Error(errMessage);
      }
    },
    [
      user,
      cart,
      cartSubtotal,
      cartDiscount,
      cartShipping,
      cartTax,
      cartGrandTotal,
      activeCoupon,
      settings.currency,
      clearCart,
      addNotification,
    ]
  );

  // ==========================================
  // ORDER STATUS & PAYMENT UPDATES (ADMIN)
  // ==========================================
  const updateOrderStatus = useCallback(async (id: string, status: OrderStatus, trackingNumber?: string) => {
    await apiFetch(`/api/orders/${id}`, {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({orderStatus:status,trackingNumber})});
    await refreshOrders(); addNotification('Order updated','Database confirmed the new order status.','order');
  }, [refreshOrders,addNotification]);
  const updateOrderPaymentStatus = useCallback(async (id: string, paymentStatus: PaymentStatus, transactionId?: string) => {
    await apiFetch(`/api/orders/${id}`, {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({paymentStatus,transactionId})});
    await refreshOrders();
  }, [refreshOrders]);
  const deleteOrder = useCallback(async (id: string) => { await apiFetch(`/api/orders/${id}`,{method:'DELETE'}); await refreshOrders(); },[refreshOrders]);
  const createProduct = useCallback(async (details: Omit<Product,'id'|'createdAt'|'updatedAt'>): Promise<Product> => {
    const r=await apiFetch('/api/products',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(details)});
    const data=await r.json(); await refreshProducts(); return data.product;
  },[refreshProducts]);
  const updateProduct = useCallback(async (id: string, updates: Partial<Product>) => {
    const current=products.find(p=>p.id===id);
    await apiFetch('/api/products',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({...current,...updates,id,updatedAt:new Date().toISOString()})});
    await refreshProducts();
  },[products,refreshProducts]);
  const deleteProduct = useCallback(async (id: string): Promise<{success:boolean;message:string}> => {
    const r=await apiFetch(`/api/products/${id}`,{method:'DELETE'});await refreshProducts();return r.json();
  },[refreshProducts]);

  // Save shared catalogue changes before updating the browser view.
  const createCategory = useCallback(async (details: Omit<Category,'id'>): Promise<Category> => {const r=await apiFetch('/api/categories',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(details)});const data=await r.json();await refreshSettings();return data.category;},[refreshSettings]);
  const updateCategory = useCallback(async (id:string,updates:Partial<Category>) => {await apiFetch('/api/categories',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({...updates,id})});await refreshSettings();},[refreshSettings]);
  const deleteCategory = useCallback(async (id:string)=>{await apiFetch(`/api/categories/${id}`,{method:'DELETE'});await refreshSettings();},[refreshSettings]);
  const createCoupon = useCallback(async (details:Omit<Coupon,'id'>):Promise<Coupon>=>{const r=await apiFetch('/api/coupons',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(details)});const data=await r.json();await refreshSettings();return data.coupon;},[refreshSettings]);
  const updateCoupon = useCallback(async(id:string,updates:Partial<Coupon>)=>{await apiFetch('/api/coupons',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({...updates,id})});await refreshSettings();},[refreshSettings]);
  const deleteCoupon = useCallback(async(id:string)=>{await apiFetch(`/api/coupons/${id}`,{method:'DELETE'});await refreshSettings();},[refreshSettings]);

  // Settings
  const updateSettings = useCallback(async (updates:Partial<StoreSettings>)=>{
    const safe={...updates};delete safe.adminPassword;delete safe.adminEmail;delete safe.adminUsername;
    await apiFetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(safe)});
    await refreshSettings();addNotification('Settings saved','Database confirmed your settings.','system');
  },[refreshSettings,addNotification]);

  // Reviews
  const createReview = useCallback(async(details:Omit<Review,'id'|'createdAt'>):Promise<Review>=>{
    const {data,error}=await supabase.rpc('mb_submit_review',{target_product:details.productId,stars:details.rating,review_comment:details.comment});
    if(error)throw new Error(error.message);if(!data?.id)throw new Error('Review was not saved.');
    await refreshSettings();return {...details,id:data.id,createdAt:data.created_at,status:'pending'};
  },[refreshSettings]);
  const moderateReview = useCallback(async(id:string,status:'approved'|'rejected')=>{
    await apiFetch('/api/reviews',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,status})});await refreshSettings();
  },[refreshSettings]);

  // Demo Controls
  const resetDemoData = useCallback(async () => {
    if(isSupabaseConfigured) throw new Error('Demo reset is unavailable on the live database.');
    setProducts(INITIAL_PRODUCTS);
    setCategories(INITIAL_CATEGORIES);
    setOrders(INITIAL_ORDERS);
    setCoupons(INITIAL_COUPONS);
    setBanners(INITIAL_BANNERS);
    setReviews(INITIAL_REVIEWS);
    setSettings(INITIAL_SETTINGS);

    saveToStorage(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    saveToStorage(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
    saveToStorage(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    saveToStorage(STORAGE_KEYS.COUPONS, INITIAL_COUPONS);
    saveToStorage(STORAGE_KEYS.BANNERS, INITIAL_BANNERS);
    saveToStorage(STORAGE_KEYS.REVIEWS, INITIAL_REVIEWS);
    saveToStorage(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);

    try {
      await apiFetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(INITIAL_PRODUCTS),
      });
    } catch {
      // ignore
    }

    addNotification(
      'Demo Data Reset',
      'Store has been repopulated with initial products and data.',
      'system'
    );
  }, [addNotification]);

  const deleteDemoProducts = useCallback(() => {
    if(isSupabaseConfigured) throw new Error('Demo controls are unavailable on the live database.');
    setProducts([]);
    saveToStorage(STORAGE_KEYS.PRODUCTS, []);
    addNotification(
      'Demo Products Cleared',
      'All products removed. You can add new products anytime.',
      'system'
    );
  }, [addNotification]);

  // Supabase onAuthStateChange above owns session state. A static SPA has no
  // /api/admin/auth endpoint; its HTML fallback must not grant or revoke access.

  // Auth
  const login = useCallback(
    (
      email: string,
      role: 'customer' | 'admin' | 'super_admin' | 'seller' = 'customer',
      name?: string
    ) => {
      if (isSupabaseConfigured) return; // Supabase auth listener supplies verified identity and roles.
      const isOwner =
        email.toLowerCase() === 'moizziom84@gmail.com' ||
        email.toLowerCase() === (settings.adminEmail || '').toLowerCase();

      const effectiveRole: 'customer' | 'admin' | 'super_admin' | 'seller' = isOwner
        ? 'super_admin'
        : role;

      const profile: UserProfile = {
        uid: isOwner
          ? 'owner-moiz'
          : effectiveRole === 'admin' || effectiveRole === 'super_admin'
          ? 'admin-root'
          : `cust-${Date.now()}`,
        email,
        displayName:
          name ||
          (isOwner
            ? 'Muhammad Moiz (Platform Owner)'
            : effectiveRole === 'super_admin' || effectiveRole === 'admin'
            ? 'Mega Bazar Administrator'
            : email.split('@')[0]),
        role: effectiveRole,
        addresses: [],
        createdAt: new Date().toISOString(),
      };
      setUser(profile);
      saveToStorage(STORAGE_KEYS.USER, profile);

      if (isOwner || effectiveRole === 'admin' || effectiveRole === 'super_admin') {
        setIsAdminAuthenticated(true);
        if (typeof window !== 'undefined') {
          try {
            sessionStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
            localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
            document.cookie = 'mb_admin_auth=true; path=/; max-age=86400; SameSite=Lax';
          } catch {
            // ignore
          }
        }
      } else {
        setIsAdminAuthenticated(false);
        if (typeof window !== 'undefined') {
          try {
            sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
            localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
            document.cookie = 'mb_admin_auth=; path=/; max-age=0; SameSite=Lax';
          } catch {
            // ignore
          }
        }
      }

      addNotification('Signed In', `Welcome back, ${profile.displayName}!`, 'system');
    },
    [addNotification, settings.adminEmail]
  );

  const logout = useCallback(() => {
    if (marketplaceEnabled) void supabase.auth.signOut();
    void fetch('/api/admin/auth', { method: 'DELETE' });
    setUser(null);
    setOrders([]);
    setIsAdminAuthenticated(false);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEYS.USER);
      try {
        sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        document.cookie = 'mb_admin_auth=; path=/; max-age=0; SameSite=Lax';
      } catch {
        // ignore
      }
    }
    addNotification('Signed Out', 'You have been safely signed out.', 'system');
  }, [addNotification]);

  const switchDemoAccount = useCallback(
    (role: 'admin' | 'customer') => {
      if (role === 'admin') {
        setUser(DEMO_ADMIN);
        setIsAdminAuthenticated(true);
        if (typeof window !== 'undefined') {
          try {
            sessionStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
            localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
            document.cookie = 'mb_admin_auth=true; path=/; max-age=86400; SameSite=Lax';
          } catch {
            // ignore
          }
        }
        saveToStorage(STORAGE_KEYS.USER, DEMO_ADMIN);
        addNotification(
          'Switched to Admin',
          'You are now signed in as Administrator.',
          'system'
        );
      } else {
        setUser(DEMO_CUSTOMER);
        setIsAdminAuthenticated(false);
        if (typeof window !== 'undefined') {
          try {
            sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
            localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
            document.cookie =
              'mb_admin_auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; max-age=0; SameSite=Lax';
          } catch {
            // ignore
          }
        }
        saveToStorage(STORAGE_KEYS.USER, DEMO_CUSTOMER);
        addNotification(
          'Switched to Customer',
          'You are now signed in as Customer Emily Johnson.',
          'system'
        );
      }
    },
    [addNotification]
  );

  const verifyAdminCredentials = useCallback(async (identifier: string, inputPassword: string): Promise<boolean> => {
    if (!isSupabaseConfigured || !identifier.trim() || !inputPassword) return false;
    const { data, error } = await supabase.auth.signInWithPassword({ email: identifier.trim(), password: inputPassword });
    return !error && data.user?.app_metadata?.role === 'super_admin';
  }, []);

  const verifyAdminPassword = useCallback(
    async (inputPassword: string): Promise<boolean> => {
      return verifyAdminCredentials('admin@megabazar.pk', inputPassword);
    },
    [verifyAdminCredentials]
  );

  const logoutAdmin = useCallback(() => {
    if (marketplaceEnabled) void supabase.auth.signOut();
    setUser(null);
    setIsAdminAuthenticated(false);
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        document.cookie =
          'mb_admin_auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; max-age=0; SameSite=Lax';
      } catch {
        // ignore
      }
    }
    // Also notify server to clear auth cookie
    try {
      fetch('/api/admin/auth', { method: 'DELETE' }).catch(() => {});
    } catch {
      // ignore
    }
  }, []);

  // Passwords belong to Supabase Auth, never store settings or browser storage.
  const updateAdminPassword = useCallback(async (_password: string) => {
    throw new Error('Use the secure Change account password page to enter and confirm your password.');
  }, []);
  const updateAdminCredentials = useCallback(async (_email: string, _password?: string, _username?: string) => {
    throw new Error('Account credentials must be changed through Supabase Auth, not store settings.');
  }, []);

  const registerShop = useCallback(
    async (data: {
      fullName: string;
      phone: string;
      email: string;
      shopName: string;
      city: string;
      address: string;
      logoUrl?: string;
      acceptedTerms?: boolean;
      description?: string;
    }): Promise<{ success: boolean; shop: SellerShop; message: string }> => {
      const cleanSlug = generateShopSlug(data.shopName);
      const newShop: SellerShop = {
        id: `shop-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        ownerId: user?.uid || `owner-${Date.now()}`,
        ownerName: data.fullName.trim(),
        email: data.email.trim().toLowerCase(),
        phone: data.phone.trim(),
        name: data.shopName.trim(),
        slug: cleanSlug,
        category: 'Multi-Vendor Retail',
        city: data.city.trim(),
        address: data.address.trim(),
        logoUrl: data.logoUrl || undefined,
        description: data.description?.trim() || `${data.shopName} - Verified Pakistani merchant on Mega Bazar.`,
        status: 'Pending',
        isVerified: false,
        commissionRate: '5%',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (!isSupabaseConfigured) throw new Error('Live database is not configured. Your shop has not been submitted.');
      if (!data.acceptedTerms) throw new Error('Accept the seller terms before submitting.');
      const saved = await submitShop({
        owner: newShop.ownerName, name: newShop.name, phone: newShop.phone,
        category: newShop.category, city: newShop.city, area: newShop.city,
        address: newShop.address, sameReturn: true,
        description: newShop.description, acceptedTerms: data.acceptedTerms,
      });
      if (data.logoUrl) {
        const imagePath = decodeURIComponent(new URL(data.logoUrl).pathname.split('/mb-product-images/')[1] || '');
        if (!imagePath) throw new Error('Shop saved, but the uploaded logo path is missing.');
        const { error } = await supabase.rpc('mb_set_shop_media', { logo_image: imagePath, banner_image: null });
        if (error) throw new Error(`Shop saved, but logo was not attached: ${error.message}`);
        saved.logo_path = imagePath;
      }
      const savedShop = mapShop(saved);
      await refreshShops();
      return { success: true, shop: savedShop, message: 'Shop saved to the database and pending owner review.' };
    },
    [user?.uid, refreshShops]
  );

  const updateShop = useCallback(
    async (data: {
      shopId?: string;
      shopName?: string;
      name?: string;
      ownerName?: string;
      category?: string;
      city?: string;
      area?: string;
      address?: string;
      phone?: string;
      description?: string;
      logoUrl?: string;
      logoPath?: string;
      bannerUrl?: string;
      bannerPath?: string;
      ownerAvatarUrl?: string;
    }): Promise<{ success: boolean; shop: SellerShop; message: string }> => {
      if (!isSupabaseConfigured) throw new Error('Live database is not configured.');
      const updatedShop = await updateShopProfile(data);
      if (!updatedShop) throw new Error('Shop profile update could not be confirmed.');
      await refreshShops();
      addNotification('Shop details updated', `Your shop "${updatedShop.name}" details have been successfully saved.`, 'system');
      return { success: true, shop: updatedShop, message: 'Shop details saved and updated successfully.' };
    },
    [refreshShops, addNotification]
  );

  const persistShopReview = useCallback(async (id: string, decision: string, reason = '') => {
    if (!isSupabaseConfigured) throw new Error('Live database is not configured.');
    await reviewShop(id, decision, reason);
    await refreshShops();
    addNotification('Shop review saved', `Shop status: ${decision}.`, 'system');
  }, [refreshShops, addNotification]);
  const approveShop = useCallback((id: string) => persistShopReview(id, 'approved'), [persistShopReview]);
  const rejectShop = useCallback((id: string, reason: string) => persistShopReview(id, 'rejected', reason), [persistShopReview]);
  const suspendShop = useCallback((id: string) => persistShopReview(id, 'suspended', 'Suspended by platform owner.'), [persistShopReview]);
  const reactivateShop = useCallback((id: string) => persistShopReview(id, 'approved'), [persistShopReview]);

  const addComplaint = useCallback(async(data:Omit<Complaint,'id'|'ticketNumber'|'createdAt'|'status'>)=>{
    const {data:{user:account}}=await supabase.auth.getUser();if(!account)throw new Error('Sign in first.');
    const {data:row,error}=await supabase.from('complaints').insert({customer_id:account.id,data}).select().single();
    if(error)throw new Error(error.message);
    const complaint={...data,id:row.id,ticketNumber:`MB-CMP-${row.id.slice(-8)}`,status:'Open' as const,createdAt:row.created_at};
    setComplaints(prev=>[complaint,...prev]);addNotification('Complaint saved','Your complaint was saved for owner review.','system');
  },[addNotification]);
  const updateComplaintStatus = useCallback(async(id:string,status:Complaint['status'],resolutionNotes?:string)=>{
    const {error}=await supabase.from('complaints').update({status,resolution_notes:resolutionNotes||'',updated_at:new Date().toISOString()}).eq('id',id).select('id').single();
    if(error)throw new Error(error.message);setComplaints(prev=>prev.map(c=>c.id===id?{...c,status,resolutionNotes}:c));
  },[]);

  // Admin status strictly requires active password-authenticated session
  const isAdmin = isAdminAuthenticated;

  const value = useMemo(
    () => ({
      products,
      categories,
      cart,
      wishlist,
      orders,
      coupons,
      banners,
      reviews,
      shops,
      complaints,
      settings,
      notifications,
      user,
      isAdmin,
      isAdminAuthenticated,
      verifyAdminPassword,
      verifyAdminCredentials,
      logoutAdmin,
      updateAdminPassword,
      updateAdminCredentials,
      isCartOpen,
      activeCoupon,
      cartSubtotal,
      cartDiscount,
      cartShipping,
      cartTax,
      cartGrandTotal,
      cartCount,
      setIsCartOpen,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      toggleWishlist,
      isInWishlist,
      applyCoupon,
      removeCoupon,
      placeOrder,
      updateOrderStatus,
      updateOrderPaymentStatus,
      deleteOrder,
      refreshOrders,
      refreshProducts,
      refreshShops,
      registerShop,
      updateShop,
      approveShop,
      rejectShop,
      suspendShop,
      reactivateShop,
      addComplaint,
      updateComplaintStatus,
      createProduct,
      updateProduct,
      deleteProduct,
      createCategory,
      updateCategory,
      deleteCategory,
      createCoupon,
      updateCoupon,
      deleteCoupon,
      updateSettings,
      createReview,
      moderateReview,
      resetDemoData,
      deleteDemoProducts,
      login,
      logout,
      switchDemoAccount,
      markNotificationAsRead,
      addNotification,
    }),
    [
      products,
      categories,
      cart,
      wishlist,
      orders,
      coupons,
      banners,
      reviews,
      shops,
      complaints,
      settings,
      notifications,
      user,
      isAdmin,
      isAdminAuthenticated,
      isCartOpen,
      activeCoupon,
      cartSubtotal,
      cartDiscount,
      cartShipping,
      cartTax,
      cartGrandTotal,
      cartCount,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      toggleWishlist,
      isInWishlist,
      applyCoupon,
      removeCoupon,
      placeOrder,
      updateOrderStatus,
      updateOrderPaymentStatus,
      deleteOrder,
      refreshOrders,
      refreshProducts,
      refreshShops,
      registerShop,
      updateShop,
      approveShop,
      rejectShop,
      suspendShop,
      reactivateShop,
      addComplaint,
      updateComplaintStatus,
      createProduct,
      updateProduct,
      deleteProduct,
      createCategory,
      updateCategory,
      deleteCategory,
      createCoupon,
      updateCoupon,
      deleteCoupon,
      updateSettings,
      createReview,
      moderateReview,
      resetDemoData,
      deleteDemoProducts,
      login,
      logout,
      switchDemoAccount,
      verifyAdminPassword,
      verifyAdminCredentials,
      logoutAdmin,
      updateAdminPassword,
      updateAdminCredentials,
      markNotificationAsRead,
      addNotification,
    ]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
};

export const useStore = (): StoreContextType => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};

