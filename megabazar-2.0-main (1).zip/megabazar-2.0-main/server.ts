import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

import { installApi } from './server-api.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '1mb' }));

// Health check endpoint for Cloud Run / deployment orchestrators
app.get('/api/health', (_req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Install full-stack backend API routes
installApi(app);

const PORT = process.env.PORT && process.env.PORT !== '8080' ? parseInt(process.env.PORT, 10) : 3000;
const DIST_DIR = path.resolve(__dirname, 'dist');

// Serve static assets from Vite build output directory
app.use(express.static(DIST_DIR, {
  maxAge: '1d',
  etag: true,
}));

// SPA Fallback: Serve index.html for all client routes (products, checkout, admin, etc.)
app.get('*', (_req, res) => {
  res.sendFile(path.join(DIST_DIR, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Mega Bazar production server running on http://0.0.0.0:${PORT}`);
});

export default app;

